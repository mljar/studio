"use strict";
(self["webpackChunkpieceofcode"] = self["webpackChunkpieceofcode"] || []).push([["lib_index_js"],{

/***/ "./lib/commands/index.js":
/*!*******************************!*\
  !*** ./lib/commands/index.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   commandsPlugin: () => (/* binding */ commandsPlugin),
/* harmony export */   runCell: () => (/* binding */ runCell)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../icons */ "./lib/icons.js");
/* harmony import */ var _flags__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../flags */ "./lib/flags.js");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);



const CommandIds = {
    openPieceOfCode: '@mljar/pieceofcode:open',
    hidePieceOfCode: '@mljar/pieceofcode:hide',
    runFirstCell: '@mljar/pieceofcode:runfirstcell',
    runCurrentCell: '@mljar/pieceofcode:runcurrentcell',
};
const showButton = (title = 'open') => {
    const elements = document.querySelectorAll(`[data-command="@mljar/pieceofcode:${title}"]`);
    elements.forEach((e) => {
        e.classList.remove('lm-mod-hidden');
    });
};
const hideButton = (title = 'open') => {
    const elements = document.querySelectorAll(`[data-command="@mljar/pieceofcode:${title}"]`);
    elements.forEach((e) => {
        e.classList.add('lm-mod-hidden');
    });
};
const commandsPlugin = {
    id: '@mljar/pieceofcode:commands',
    description: 'Commands used in Piece of Code',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, tracker) => {
        const { commands } = app;
        commands.addCommand(CommandIds.openPieceOfCode, {
            icon: _icons__WEBPACK_IMPORTED_MODULE_1__.cakeIcon,
            caption: 'Open Piece of Code',
            execute: () => {
                (0,_flags__WEBPACK_IMPORTED_MODULE_2__.setAlwaysOpen)(true);
                showButton('hide');
                hideButton('open');
            },
            isVisible: () => !(0,_flags__WEBPACK_IMPORTED_MODULE_2__.getAlwaysOpen)()
        });
        commands.addCommand(CommandIds.hidePieceOfCode, {
            icon: _icons__WEBPACK_IMPORTED_MODULE_1__.cakeOffIcon,
            caption: 'Hide Piece of Code',
            execute: () => {
                (0,_flags__WEBPACK_IMPORTED_MODULE_2__.setAlwaysOpen)(false);
                showButton('open');
                hideButton('hide');
            },
            isVisible: () => (0,_flags__WEBPACK_IMPORTED_MODULE_2__.getAlwaysOpen)()
        });
        app.commands.addCommand(CommandIds.runFirstCell, {
            label: 'Execute first cell',
            execute: () => {
                const nb = tracker.currentWidget;
                if (nb) {
                    return runCell(nb.content, nb.context.sessionContext, 0);
                }
            }
        });
        app.commands.addCommand(CommandIds.runCurrentCell, {
            label: 'Execute current cell',
            execute: () => {
                const nb = tracker.currentWidget;
                if (nb) {
                    return runCell(nb.content, nb.context.sessionContext);
                }
            }
        });
    }
};
function runCell(notebook, sessionContext, cellIndex, sessionDialogs, translator) {
    if (!notebook.model || !notebook.activeCell) {
        return Promise.resolve(false);
    }
    if (cellIndex === undefined) {
        cellIndex = notebook.activeCellIndex;
    }
    const cells = [notebook.widgets[cellIndex]];
    const promise = _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookActions.runCells(notebook, cells, sessionContext, sessionDialogs, translator);
    return promise;
}


/***/ }),

/***/ "./lib/contexts/activeCell.js":
/*!************************************!*\
  !*** ./lib/contexts/activeCell.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActiveCellContextProvider: () => (/* binding */ ActiveCellContextProvider),
/* harmony export */   ActiveCellManager: () => (/* binding */ ActiveCellManager),
/* harmony export */   useActiveCellContext: () => (/* binding */ useActiveCellContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_3__);
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.
// code from https://github.com/jupyterlab/jupyter-ai
//




function getNotebook(widget) {
    if (!(widget instanceof _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_1__.DocumentWidget)) {
        return null;
    }
    const { content } = widget;
    if (!(content instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.Notebook)) {
        return null;
    }
    return content;
}
function getActiveCell(widget) {
    const notebook = getNotebook(widget);
    if (!notebook) {
        return null;
    }
    return notebook.activeCell;
}
function getFirstCodeCellSource(widget) {
    var _a;
    const notebook = getNotebook(widget);
    if (!notebook) {
        return '';
    }
    const cells = (_a = notebook.model) === null || _a === void 0 ? void 0 : _a.cells;
    if (cells) {
        for (let i = 0; i < cells.length; i++) {
            const cell = cells.get(i);
            if (cell.type === 'code') {
                return cell.sharedModel.source;
            }
        }
    }
    return '';
}
/**
 * A manager that maintains a reference to the current active notebook cell in
 * the main panel (if any), and provides methods for inserting or appending
 * content to the active cell.
 *
 * The current active cell should be obtained by listening to the
 * `activeCellChanged` signal.
 */
class ActiveCellManager {
    constructor(shell) {
        var _a;
        this._mainAreaWidget = null;
        /**
         * The active cell.
         */
        this._activeCell = null;
        /**
         * The execution count of the active cell. This is the number shown on the
         * left in square brackets after running a cell. Changes to this indicate that
         * the error output may have changed.
         */
        this._activeCellExecutionCount = null;
        /**
         * The `CellError` output within the active cell, if any.
         */
        this._activeCellError = null;
        this._activeCellChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this._activeCellErrorChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this._shell = shell;
        (_a = this._shell.currentChanged) === null || _a === void 0 ? void 0 : _a.connect((sender, args) => {
            this._mainAreaWidget = args.newValue;
        });
        setInterval(() => {
            this._pollActiveCell();
        }, 200);
    }
    get activeCellChanged() {
        return this._activeCellChanged;
    }
    get activeCellErrorChanged() {
        return this._activeCellErrorChanged;
    }
    getContent(withError = false) {
        var _a;
        const sharedModel = (_a = this._activeCell) === null || _a === void 0 ? void 0 : _a.model.sharedModel;
        if (!sharedModel) {
            return null;
        }
        // case where withError = false
        if (!withError) {
            return {
                type: sharedModel.cell_type,
                source: sharedModel.getSource()
            };
        }
        // case where withError = true
        const error = this._activeCellError;
        if (error) {
            return {
                type: 'code',
                source: sharedModel.getSource(),
                error: {
                    name: error.ename,
                    value: error.evalue,
                    traceback: error.traceback
                }
            };
        }
        return null;
    }
    notebook() {
        const notebook = getNotebook(this._mainAreaWidget);
        if (!notebook) {
            return null;
        }
        return notebook;
    }
    notebookPanel() {
        const notebook = getNotebook(this._mainAreaWidget);
        if (!notebook) {
            return null;
        }
        return notebook.parent instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookPanel ? notebook.parent : null;
    }
    firstCodeCellSource() {
        const notebook = getNotebook(this._mainAreaWidget);
        if (!notebook) {
            return '';
        }
        return getFirstCodeCellSource(notebook);
    }
    setContent(content) {
        const notebook = getNotebook(this._mainAreaWidget);
        if (!notebook) {
            return;
        }
        this._pollActiveCell();
        // replace content of active cell
        this.replace(content);
    }
    /**
     * Inserts `content` in a new cell above the active cell.
     */
    insertAbove(content) {
        const notebook = getNotebook(this._mainAreaWidget);
        if (!notebook) {
            return;
        }
        // create a new cell above the active cell and mark new cell as active
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookActions.insertAbove(notebook);
        // emit activeCellChanged event to consumers
        this._pollActiveCell();
        // replace content of this new active cell
        this.replace(content);
    }
    /**
     * Inserts `content` in a new cell below the active cell.
     */
    insertBelow(content) {
        const notebook = getNotebook(this._mainAreaWidget);
        if (!notebook) {
            return;
        }
        // create a new cell below the active cell and mark new cell as active
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookActions.insertBelow(notebook);
        // emit activeCellChanged event to consumers
        this._pollActiveCell();
        // replace content of this new active cell
        this.replace(content);
    }
    /**
     * Replaces the contents of the active cell.
     */
    async replace(content) {
        var _a, _b;
        // get reference to active cell directly from Notebook API. this avoids the
        // possibility of acting on an out-of-date reference.
        const activeCell = (_a = getNotebook(this._mainAreaWidget)) === null || _a === void 0 ? void 0 : _a.activeCell;
        if (!activeCell) {
            return;
        }
        // wait for editor to be ready
        await activeCell.ready;
        // replace the content of the active cell
        /**
         * NOTE: calling this method sometimes emits an error to the browser console:
         *
         * ```
         * Error: Calls to EditorView.update are not allowed while an update is in progress
         * ```
         *
         * However, there seems to be no impact on the behavior/stability of the
         * JupyterLab application after this error is logged. Furthermore, this is
         * the official API for setting the content of a cell in JupyterLab 4,
         * meaning that this is likely unavoidable.
         */
        (_b = activeCell.editor) === null || _b === void 0 ? void 0 : _b.model.sharedModel.setSource(content);
    }
    _pollActiveCell() {
        const prevActiveCell = this._activeCell;
        const currActiveCell = getActiveCell(this._mainAreaWidget);
        // emit activeCellChanged when active cell changes
        if (prevActiveCell !== currActiveCell) {
            this._activeCell = currActiveCell;
            this._activeCellChanged.emit(currActiveCell);
        }
        const currSharedModel = currActiveCell === null || currActiveCell === void 0 ? void 0 : currActiveCell.model.sharedModel;
        const prevExecutionCount = this._activeCellExecutionCount;
        const currExecutionCount = currSharedModel && 'execution_count' in currSharedModel
            ? currSharedModel === null || currSharedModel === void 0 ? void 0 : currSharedModel.execution_count
            : null;
        this._activeCellExecutionCount = currExecutionCount;
        // emit activeCellErrorChanged when active cell changes or when the
        // execution count changes
        if (prevActiveCell !== currActiveCell ||
            prevExecutionCount !== currExecutionCount) {
            const prevActiveCellError = this._activeCellError;
            let currActiveCellError = null;
            if (currSharedModel && 'outputs' in currSharedModel) {
                currActiveCellError =
                    currSharedModel.outputs.find((output) => output.output_type === 'error') || null;
            }
            // for some reason, the `CellError` object is not referentially stable,
            // meaning that this condition always evaluates to `true` and the
            // `activeCellErrorChanged` signal is emitted every 200ms, even when the
            // error output is unchanged. this is why we have to rely on
            // `execution_count` to track changes to the error output.
            if (prevActiveCellError !== currActiveCellError) {
                this._activeCellError = currActiveCellError;
                this._activeCellErrorChanged.emit(this._activeCellError);
            }
        }
    }
}
const defaultActiveCellContext = {
    exists: false,
    hasError: false,
    manager: null
};
const ActiveCellContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(defaultActiveCellContext);
function ActiveCellContextProvider(props) {
    const [exists, setExists] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [hasError, setHasError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const manager = props.activeCellManager;
        manager.activeCellChanged.connect((_, newActiveCell) => {
            console.log('active cell changed');
            setExists(!!newActiveCell);
        });
        manager.activeCellErrorChanged.connect((_, newActiveCellError) => {
            setHasError(!!newActiveCellError);
        });
    }, [props.activeCellManager]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ActiveCellContext.Provider, { value: {
            exists,
            hasError,
            manager: props.activeCellManager
        } }, props.children));
}
/**
 * Usage: `const activeCell = useActiveCellContext()`
 *
 * Returns an object `activeCell` with the following properties:
 * - `activeCell.exists`: whether an active cell exists
 * - `activeCell.hasError`: whether an active cell exists with an error output
 * - `activeCell.manager`: the `ActiveCellManager` singleton
 */
function useActiveCellContext() {
    const { exists, hasError, manager } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(ActiveCellContext);
    if (!manager) {
        throw new Error('useActiveCellContext() cannot be called outside ActiveCellContextProvider.');
    }
    return {
        exists,
        hasError,
        manager
    };
}


/***/ }),

/***/ "./lib/contexts/codeCell.js":
/*!**********************************!*\
  !*** ./lib/contexts/codeCell.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeCellComponent: () => (/* binding */ CodeCellComponent)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/codeeditor */ "webpack/sharing/consume/default/@jupyterlab/codeeditor");
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _codemirror_view__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @codemirror/view */ "webpack/sharing/consume/default/@codemirror/view");
/* harmony import */ var _codemirror_view__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_codemirror_view__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _language__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./language */ "./lib/contexts/language.js");
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.
// https://github.com/jupyterlab-contrib/jupyterlab-code-toc





/**
 * Functional component rendering a code component.
 */
const CodeCellComponent = props => {
    const containerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const container = containerRef.current;
        if (container) {
            // clear the rendered HTML
            container.innerHTML = '';
            const model = new _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2__.CodeEditor.Model();
            model.mimeType = props.languageMimetype;
            model.sharedModel.setSource(props.cellInput);
            // binds the editor to the host HTML element
            new _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1__.CodeMirrorEditor({
                host: container,
                model: model,
                extensions: [
                    _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1__.jupyterTheme,
                    _codemirror_view__WEBPACK_IMPORTED_MODULE_3__.EditorView.lineWrapping,
                    _codemirror_view__WEBPACK_IMPORTED_MODULE_3__.EditorView.editable.of(false)
                ],
                languages: _language__WEBPACK_IMPORTED_MODULE_4__.editorDefaultLanguages
            });
        }
    }, [props.cellInput, props.languageMimetype]);
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: containerRef, className: "jpcodetoc-toc-cell-input" });
};
/**
 * Exports.
 */



/***/ }),

/***/ "./lib/contexts/language.js":
/*!**********************************!*\
  !*** ./lib/contexts/language.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   editorDefaultLanguages: () => (/* binding */ editorDefaultLanguages)
/* harmony export */ });
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _codemirror_language__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @codemirror/language */ "webpack/sharing/consume/default/@codemirror/language");
/* harmony import */ var _codemirror_language__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_codemirror_language__WEBPACK_IMPORTED_MODULE_1__);
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.
// code from https://github.com/jupyter/jupyter-ai
//


const editorDefaultLanguages = new _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__.EditorLanguageRegistry();
// register all the JupyterLab default languages
_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__.EditorLanguageRegistry.getDefaultLanguages().forEach(language => {
    editorDefaultLanguages.addLanguage(language);
});
editorDefaultLanguages.addLanguage({
    name: 'ipythongfm',
    mime: 'text/x-ipythongfm',
    load: async () => {
        const [m, tex] = await Promise.all([
            Promise.all(/*! import() */[__webpack_require__.e("vendors-node_modules_codemirror_lang-markdown_dist_index_js"), __webpack_require__.e("webpack_sharing_consume_default_codemirror_state-webpack_sharing_consume_default_lezer_common-d06d70")]).then(__webpack_require__.bind(__webpack_require__, /*! @codemirror/lang-markdown */ "./node_modules/@codemirror/lang-markdown/dist/index.js")),
            __webpack_require__.e(/*! import() */ "node_modules_codemirror_legacy-modes_mode_stex_js").then(__webpack_require__.bind(__webpack_require__, /*! @codemirror/legacy-modes/mode/stex */ "./node_modules/@codemirror/legacy-modes/mode/stex.js"))
        ]);
        return m.markdown({
            base: m.markdownLanguage,
            codeLanguages: (info) => editorDefaultLanguages.findBest(info),
            extensions: [(0,_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__.parseMathIPython)(_codemirror_language__WEBPACK_IMPORTED_MODULE_1__.StreamLanguage.define(tex.stexMath).parser)]
        });
    }
});


/***/ }),

/***/ "./lib/contexts/packages.js":
/*!**********************************!*\
  !*** ./lib/contexts/packages.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PackagesContextProvider: () => (/* binding */ PackagesContextProvider),
/* harmony export */   usePackagesContext: () => (/* binding */ usePackagesContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _inspector_packagesInspector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../inspector/packagesInspector */ "./lib/inspector/packagesInspector.js");


const defaultPackagesContext = {
    packages: {},
    installLog: '',
    checkPackage: (pkgInstallName, pkgImportName) => { },
    installPackage: (pkgInstallName, pkgImportName) => { }
};
const PackagesContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(defaultPackagesContext);
var inspectors = {}; // panelId -> PackagesInspector
function PackagesContextProvider(props) {
    const [panelId, setPanelId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [packages, setPackages] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [installLog, setInstallLogState] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const checkPackage = (pkgInstallName, pkgImportName) => {
        if (!(pkgImportName in packages)) {
            if (panelId !== '' && panelId in inspectors) {
                const inspector = inspectors[panelId];
                inspector.checkPackage(pkgInstallName, pkgImportName);
            }
        }
    };
    const installPackage = (pkgInstallName, pkgImportName) => {
        if (panelId !== '' && panelId in inspectors) {
            const inspector = inspectors[panelId];
            inspector.installPackage(pkgInstallName, pkgImportName);
        }
    };
    const setAvailablePackages = (pkgs) => {
        setPackages(pkgs);
        props.updateWidget();
    };
    const setInstallLog = (log) => {
        setInstallLogState(log);
        props.updateWidget();
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const manager = props.activeCellManager;
        manager.activeCellChanged.connect((_, newActiveCell) => {
            const nbPanel = manager.notebookPanel();
            if (nbPanel) {
                setPanelId(nbPanel.id);
                if (!(nbPanel.id in inspectors)) {
                    const inspector = new _inspector_packagesInspector__WEBPACK_IMPORTED_MODULE_1__.PackagesInspector(nbPanel, setAvailablePackages, setInstallLog);
                    inspectors[nbPanel.id] = inspector;
                }
            }
        });
    }, [props.activeCellManager]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setPackages({});
        setInstallLog('');
    }, [panelId]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(PackagesContext.Provider, { value: {
            packages,
            installLog,
            checkPackage,
            installPackage
        } }, props.children));
}
function usePackagesContext() {
    const { packages, installLog, checkPackage, installPackage } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(PackagesContext);
    return {
        packages,
        installLog,
        checkPackage,
        installPackage
    };
}


/***/ }),

/***/ "./lib/contexts/variables.js":
/*!***********************************!*\
  !*** ./lib/contexts/variables.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VariablesContextProvider: () => (/* binding */ VariablesContextProvider),
/* harmony export */   useVariablesContext: () => (/* binding */ useVariablesContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _inspector_variablesInspector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../inspector/variablesInspector */ "./lib/inspector/variablesInspector.js");


const defaultVariablesContext = {
    status: 'unknown',
    variables: []
};
const VariablesContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(defaultVariablesContext);
function VariablesContextProvider(props) {
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('unknown');
    const [variables, setVariables] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const manager = props.activeCellManager;
        manager.activeCellChanged.connect((_, newActiveCell) => {
            console.log('active cell changed 2');
            const nb = manager.notebook();
            const nbPanel = manager.notebookPanel();
            console.log('title', nb === null || nb === void 0 ? void 0 : nb.id);
            console.log('panel title', nbPanel === null || nbPanel === void 0 ? void 0 : nbPanel.id);
            //setExists(!!newActiveCell);
            if (nbPanel) {
                const inspector = new _inspector_variablesInspector__WEBPACK_IMPORTED_MODULE_1__.VariablesInspector(nbPanel, setStatus, setVariables);
                console.log(inspector.getVariables());
            }
        });
        setStatus('unknown');
        setVariables([]);
        // manager.activeCellErrorChanged.connect((_, newActiveCellError) => {
        //   setHasError(!!newActiveCellError);
        // });
    }, [props.activeCellManager]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        console.log(status);
        console.log(variables);
    }, [status, variables]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(VariablesContext.Provider, { value: {
            status,
            variables
        } }, props.children));
}
function useVariablesContext() {
    const { status, variables } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(VariablesContext);
    return {
        status,
        variables
    };
}


/***/ }),

/***/ "./lib/extendedcell/header.js":
/*!************************************!*\
  !*** ./lib/extendedcell/header.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExtendedCellHeader: () => (/* binding */ ExtendedCellHeader),
/* harmony export */   RecipeWidgetsRegistry: () => (/* binding */ RecipeWidgetsRegistry)
/* harmony export */ });
/* harmony import */ var _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/cells */ "webpack/sharing/consume/default/@jupyterlab/cells");
/* harmony import */ var _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_cells__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _recipes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./recipes */ "./lib/extendedcell/recipes.js");
/* harmony import */ var _flags__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../flags */ "./lib/flags.js");
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mljar/recipes */ "webpack/sharing/consume/default/@mljar/recipes/@mljar/recipes");
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mljar_recipes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icons */ "./lib/icons.js");
/* harmony import */ var _setEnv__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./setEnv */ "./lib/extendedcell/setEnv.js");








const STATUSBAR_PLUGIN_ID = '@jupyterlab/statusbar-extension:plugin';
// import { NotebookActions } from '@jupyterlab/notebook';
// import { nbformat } from '@jupyterlab/coreutils';
class RecipeWidgetsRegistry {
    constructor() {
        this._widgets = {};
        this._lastSelectedCellId = '';
        this._labShell = null;
        this._labShellSet = false;
        this._settingRegistry = null;
    }
    static getInstance() {
        if (!RecipeWidgetsRegistry._instance) {
            RecipeWidgetsRegistry._instance = new RecipeWidgetsRegistry();
        }
        return RecipeWidgetsRegistry._instance;
    }
    setCommandRegistry(commands) {
        this._commands = commands;
    }
    setLabShell(labShell) {
        this._labShell = labShell;
        if (this._labShell) {
            this._labShell.layoutModified.connect(() => {
                this.checkLabShell();
            });
        }
    }
    setSettingRegistry(settingRegistry) {
        this._settingRegistry = settingRegistry;
    }
    checkLabShell() {
        if (this._labShellSet)
            return;
        if (this._labShell) {
            if (this._labShell.isSideTabBarVisible('right')) {
                this._labShell.toggleSideTabBarVisibility('right');
                this._labShellSet = true;
            }
            if (this._settingRegistry) {
                this._settingRegistry
                    .load(STATUSBAR_PLUGIN_ID)
                    .then(settings => {
                    var _a;
                    const isVisible = settings.get('visible').composite;
                    if (isVisible) {
                        (_a = this._commands) === null || _a === void 0 ? void 0 : _a.execute('statusbar:toggle');
                    }
                })
                    .catch(reason => {
                    console.error('Failed to hide status bar', reason);
                });
            }
            const element = document.getElementById('jp-MainLogo');
            if (element) {
                element.innerHTML = _icons__WEBPACK_IMPORTED_MODULE_4__.mIcon.svgstr;
            }
        }
    }
    deleteCell() {
        if (this._commands) {
            this._commands.execute('notebook:delete-cell');
        }
    }
    addCell() {
        if (this._commands) {
            const promise = this._commands.execute('notebook:insert-cell-below');
            promise.then(() => {
                var _a;
                (_a = this._commands) === null || _a === void 0 ? void 0 : _a.execute('notebook:enter-edit-mode');
            });
        }
    }
    addCellAbove() {
        if (this._commands) {
            const promise = this._commands.execute('notebook:insert-cell-above');
            promise.then(() => {
                var _a;
                (_a = this._commands) === null || _a === void 0 ? void 0 : _a.execute('notebook:enter-edit-mode');
            });
        }
    }
    runCell(addStep, checkOutput) {
        if (this._commands) {
            addStep('Run code', _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Wait);
            const promise = this._commands.execute('@mljar/pieceofcode:runcurrentcell');
            promise.then(() => {
                checkOutput();
            });
        }
    }
    runFirstCell() {
        if (this._commands) {
            const promise = this._commands.execute('@mljar/pieceofcode:runfirstcell');
            return promise;
        }
        return undefined;
    }
    saveNotebook() {
        if (this._commands) {
            const promise = this._commands.execute('docmanager:save');
            promise.then(() => {
            });
        }
    }
    renderMarkdown() {
        if (this._commands) {
            const promise = this._commands.execute('notebook:change-cell-to-markdown');
            promise.then(() => {
                if (this._commands) {
                    const promise = this._commands.execute('notebook:enter-edit-mode');
                    promise.then(() => {
                        var _a;
                        (_a = this._commands) === null || _a === void 0 ? void 0 : _a.execute('@mljar/pieceofcode:runcurrentcell');
                    });
                }
            });
        }
    }
    // public changeCellToCode() {
    //   if (this._commands) {
    //     const promise = this._commands.execute(
    //       'notebook:change-cell-to-code'
    //     );
    //     promise.then(() => {
    //       if (this._commands) {
    //         this._commands.execute(
    //           "notebook:enter-edit-mode"
    //         );
    //       }
    //     });
    //   }
    // }
    addWidget(cellId, widget) {
        this._widgets[cellId] = widget;
    }
    removeWidget(cellId) {
        delete this._widgets[cellId];
    }
    hideAll() {
        Object.values(this._widgets).forEach(w => w.hideWidget());
    }
    setSelectedCellId(cellId) {
        this._lastSelectedCellId = cellId;
    }
    getSelectedCellId() {
        return this._lastSelectedCellId;
    }
    showLastSelectedCellId() {
        if (this._lastSelectedCellId in this._widgets) {
            this._widgets[this._lastSelectedCellId].showWidget();
        }
    }
}
// export const run = 'notebook:run-cell';
// export const runAndAdvance = 'notebook:run-cell-and-select-next';
// export const runAndInsert = 'notebook:run-cell-and-insert-below';
class ExtendedCellHeader extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget {
    constructor() {
        super();
        this._packages = [];
        this._executionSteps = [];
        // private _variableInspector: VariableInspector | undefined;
        this._meta = {};
        this._envVariables = [];
        this._renderMarkdown = false;
        this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout();
        if (this.layout instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout) {
            this.removeClass('lm-Widget');
            this.removeClass('jp-Cell-header');
            this.addClass('recipe-panel-layout');
        }
    }
    dispose() {
        if (this._cellId) {
            RecipeWidgetsRegistry.getInstance().removeWidget(this._cellId);
        }
        super.dispose();
    }
    setCode(src) {
        const cell = this.parent;
        cell.model.sharedModel.setSource(src);
    }
    setPackages(packages) {
        this._packages = packages;
    }
    clearExecutionSteps() {
        var _a;
        this._executionSteps = [];
        (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setExecutionSteps(this._executionSteps);
    }
    addExecutionStep(label, status) {
        var _a;
        let found = false;
        this._executionSteps = this._executionSteps.map((step) => {
            if (step[0] == label) {
                found = true;
                return [step[0], status];
            }
            return [step[0], step[1]];
        });
        if (!found) {
            this._executionSteps.push([label, status]);
        }
        (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setExecutionSteps(this._executionSteps);
    }
    runCell() {
        var _a;
        if (this._renderMarkdown) {
            RecipeWidgetsRegistry.getInstance().renderMarkdown();
            this.addExecutionStep("Render", _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Success);
            return;
        }
        if (this._envVariables.length > 0) {
            const envManager = new _setEnv__WEBPACK_IMPORTED_MODULE_5__.SetEnv(this.notebook);
            envManager.run(this._envVariables);
            this._envVariables = [];
        }
        (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setPreviousError('', '');
        this.clearExecutionSteps();
        this.insertCellAtTop();
        this.supplementPackages();
        if (this._packages.length) {
            //
            // import packages and run code
            //
            this.addExecutionStep('Import packages', _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Wait);
            const promise = RecipeWidgetsRegistry.getInstance().runFirstCell();
            promise === null || promise === void 0 ? void 0 : promise.then(() => {
                const errorName = this.checkFirstCellOutput();
                if (errorName === '') {
                    // no error with package import let's run code
                    RecipeWidgetsRegistry.getInstance().runCell(this.addExecutionStep.bind(this), this.checkOutput.bind(this));
                }
                else {
                    this.addExecutionStep('Code not executed', _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Warning);
                }
            });
            // clear packages
            this._packages = [];
        }
        else {
            //
            // just run current cell
            //
            RecipeWidgetsRegistry.getInstance().runCell(this.addExecutionStep.bind(this), this.checkOutput.bind(this));
        }
        // save metadata 
        if (this.cell) {
            if (this._meta) {
                let meta = this.cell.model.sharedModel.getMetadata();
                meta["mljar"] = this._meta;
                this.cell.model.sharedModel.setMetadata(meta);
            }
        }
    }
    changeCellToMarkdown() {
        this._renderMarkdown = true;
    }
    setEnv(envVariables) {
        this._envVariables = envVariables;
    }
    changeCellToCode() {
        this._renderMarkdown = false;
    }
    setMeta(m) {
        if (m) {
            this._meta = m;
        }
    }
    checkOutput() {
        if (this.cell) {
            RecipeWidgetsRegistry.getInstance().saveNotebook();
            return this.checkCellOutput(this.cell.model.sharedModel.toJSON(), 'Run code');
        }
        return '';
    }
    checkFirstCellOutput() {
        var _a;
        const nb = this.notebook;
        if (nb) {
            const cells = (_a = nb === null || nb === void 0 ? void 0 : nb.model) === null || _a === void 0 ? void 0 : _a.cells;
            if (cells) {
                return this.checkCellOutput(cells.get(0).sharedModel.toJSON(), 'Import packages');
            }
        }
        return '';
    }
    checkCellOutput(output, stepName) {
        var _a, _b;
        if (output) {
            const [errorName, errorValue] = this.getErrorNameAndValue(output);
            (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setPreviousError(errorName, errorValue);
            (_b = this.selectRecipe) === null || _b === void 0 ? void 0 : _b.updateWidget();
            if (errorName === '') {
                setTimeout(() => this.addExecutionStep(stepName, _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Success), 500);
            }
            else {
                setTimeout(() => this.addExecutionStep(stepName, _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Error), 500);
            }
            return errorName;
        }
        return '';
    }
    deleteCell() {
        RecipeWidgetsRegistry.getInstance().deleteCell();
    }
    addCell() {
        RecipeWidgetsRegistry.getInstance().addCell();
    }
    insertCellAtTop() {
        var _a, _b, _c;
        // insert cell at the top of the notebook
        // if there is only one cell in the notebook
        if (this._packages.length === 0) {
            return;
        }
        const nb = this.notebook;
        if (nb) {
            const cells = (_a = nb === null || nb === void 0 ? void 0 : nb.model) === null || _a === void 0 ? void 0 : _a.cells;
            if (cells) {
                if (cells.length == 1) {
                    (_b = nb === null || nb === void 0 ? void 0 : nb.model) === null || _b === void 0 ? void 0 : _b.sharedModel.insertCell(0, { cell_type: 'code', source: '# import packages' });
                }
                else {
                    // check if there are any imports in the first cell
                    // if not then we need to insert cell above for imports
                    let firstCellSrc = cells.get(0).sharedModel.getSource();
                    if (!firstCellSrc.includes("import")) {
                        (_c = nb === null || nb === void 0 ? void 0 : nb.model) === null || _c === void 0 ? void 0 : _c.sharedModel.insertCell(0, { cell_type: 'code', source: '# import packages' });
                    }
                }
            }
        }
    }
    supplementPackages() {
        var _a;
        if (!this._packages) {
            return;
        }
        if (this._packages.length === 0) {
            return;
        }
        if (this._packages.length === 1 && this._packages[0] === "") {
            return;
        }
        const nb = this.notebook;
        if (nb) {
            const cells = (_a = nb === null || nb === void 0 ? void 0 : nb.model) === null || _a === void 0 ? void 0 : _a.cells;
            if (cells) {
                let firstCellSrc = cells.get(0).sharedModel.getSource();
                this._packages.forEach((packageImport) => {
                    const packageImported = firstCellSrc.includes(packageImport);
                    if (!packageImported) {
                        if (firstCellSrc.length > 0) {
                            firstCellSrc += '\n';
                        }
                        firstCellSrc += `${packageImport}`;
                    }
                });
                cells.get(0).sharedModel.setSource(firstCellSrc);
            }
        }
    }
    // private _onIOPub = (msg: KernelMessage.IIOPubMessage): void => {
    //   const msgType = msg.header.msg_type;
    //   // console.log(msg);
    //   switch (msgType) {
    //     case 'execute_result':
    //     case 'display_data':
    //     case 'update_display_data':
    //       // console.log(msg.content);
    //       break;
    //     default:
    //       break;
    //   }
    //   return;
    // };
    getErrorNameAndValue(output) {
        if (output) {
            if (output.cell_type === 'code') {
                let outputs = output.outputs;
                if (outputs !== null && outputs !== undefined) {
                    for (let i = 0; i < outputs.length; i += 1) {
                        const { output_type, ename, evalue } = outputs[i];
                        if (output_type === 'error') {
                            return [ename, evalue];
                        }
                    }
                }
            }
        }
        return ['', ''];
    }
    getExecutionCount(cell) {
        const output = cell.model.sharedModel.toJSON();
        if (output) {
            if (output.cell_type === 'code') {
                const execution_count = output.execution_count;
                if (execution_count) {
                    return execution_count;
                }
            }
        }
        return 0;
    }
    onAfterAttach(msg) {
        var _a, _b;
        RecipeWidgetsRegistry.getInstance().checkLabShell();
        const cell = this.parent;
        if (cell) {
            if (this.selectRecipe === undefined) {
                let meta = cell.model.sharedModel.getMetadata();
                const executionCount = this.getExecutionCount(cell);
                this.selectRecipe = new _recipes__WEBPACK_IMPORTED_MODULE_6__.SelectRecipeWidget(cell, this.setCode.bind(this), this.setPackages.bind(this), this.runCell.bind(this), this.deleteCell.bind(this), this.addCell.bind(this), executionCount, meta["mljar"], this.setMeta.bind(this), this.changeCellToMarkdown.bind(this), this.changeCellToCode.bind(this), this.setEnv.bind(this));
                this.selectRecipe.hideWidget();
                if (this.layout instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout) {
                    (_a = this.layout) === null || _a === void 0 ? void 0 : _a.addWidget(this.selectRecipe);
                }
            }
            /*
            if (this._variableInspector === undefined && this.selectRecipe !== undefined) {
              this._variableInspector = new VariableInspector(this.notebook,
                this.selectRecipe.setVariablesStatus.bind(this.selectRecipe),
                this.selectRecipe.setVariables.bind(this.selectRecipe),
                this.selectRecipe.setCheckedPackages.bind(this.selectRecipe),
                this.selectRecipe.setInstallationLog.bind(this.selectRecipe)
              );
      
              this.selectRecipe.setCheckPackage(this._variableInspector.checkPackage.bind(this._variableInspector));
              this.selectRecipe.setInstallPackage(this._variableInspector.installPackage.bind(this._variableInspector));
      
              this.selectRecipe.updateWidget();
            }*/
            //console.log('try add focus');
            // cell.inputArea?.node.addEventListener('focusout', () => {
            //   console.log('focusin is here2', cell);
            //   this.a?.hide();
            // });
            this._cellId = cell.model.id;
            if (this.selectRecipe) {
                RecipeWidgetsRegistry.getInstance().addWidget(this._cellId, this.selectRecipe);
            }
            // cell.model.contentChanged.connect(() => {
            //   console.log('content changed');
            // }, cell);
            // cell.model.metadataChanged.connect(() => {
            //   console.log('metadata changed');
            // }, cell);
            // cell.model.stateChanged.connect((model: ICellModel, args: IChangedArgs<any>) => {
            //   // console.log('state changed', args, model);
            //   // if (args.name === 'executionCount' && args.newValue) {
            //   //   console.log('go for it');
            //   //   const [errorName, errorValue] = this.getErrorNameAndValue(cell.model.sharedModel.toJSON());
            //   //   this.selectRecipe?.setPreviousError(errorName, errorValue);
            //   //   const executionCount = this.getExecutionCount(cell);
            //   //   this.selectRecipe?.setPreviousExecutionCount(executionCount);
            //   //   this.selectRecipe?.updateWidget();
            //   // }
            // }, cell);
            // cell.node.addEventListener('focusin', () => {
            //   console.log('cell node focusin');
            // });
            // cell.node.addEventListener('focusout', () => {
            //   console.log('cell node focus-out');
            //   // this.selectRecipe?.setExecutionSteps([]);
            // });
            if (cell.model.sharedModel.cell_type === "markdown") {
                cell.node.addEventListener('focusin', () => {
                    var _a;
                    RecipeWidgetsRegistry.getInstance().hideAll();
                    (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.showWidget();
                });
            }
            if (cell.model.sharedModel.cell_type === "code") {
                (_b = cell.inputArea) === null || _b === void 0 ? void 0 : _b.node.addEventListener('focusin', () => {
                    var _a, _b, _c, _d, _e;
                    let clearPackages = true;
                    if (this._cellId) {
                        if (RecipeWidgetsRegistry.getInstance().getSelectedCellId() === this._cellId) {
                            // it is the same cell, no need to clear packages
                            clearPackages = false;
                        }
                        else {
                            RecipeWidgetsRegistry.getInstance().setSelectedCellId(this._cellId);
                        }
                    }
                    RecipeWidgetsRegistry.getInstance().hideAll();
                    // clear packages
                    if (clearPackages) {
                        this._packages = [];
                    }
                    if ((0,_flags__WEBPACK_IMPORTED_MODULE_7__.getAlwaysOpen)()) {
                        (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setPreviousCode(cell.model.sharedModel.getSource());
                        const [errorName, errorValue] = this.getErrorNameAndValue(cell.model.sharedModel.toJSON());
                        (_b = this.selectRecipe) === null || _b === void 0 ? void 0 : _b.setPreviousError(errorName, errorValue);
                        const executionCount = this.getExecutionCount(cell);
                        (_c = this.selectRecipe) === null || _c === void 0 ? void 0 : _c.setPreviousExecutionCount(executionCount);
                        //this.selectRecipe?.updateWidget();
                        //this._variableInspector?.getVariables();
                        (_d = this.selectRecipe) === null || _d === void 0 ? void 0 : _d.showWidget();
                        (_e = this.selectRecipe) === null || _e === void 0 ? void 0 : _e.updateWidget();
                    }
                    // console.log(cell.model.sharedModel.toJSON());
                    // this.setCode("hejka");
                    // const nb = this.notebook;
                    // // let future = nb?.sessionContext.session?.kernel?.requestExecute({
                    // //   code: "2+2",
                    // //   store_history: false,
                    // // });
                    // // if (future) {
                    // //   future.onIOPub = this._onIOPub;
                    // // }
                    // //nb?.sessionContext.
                    // const cells = nb?.model?.cells;
                    // // const sharedModel = nb?.model?.sharedModel;
                    // // sharedModel?.insertCell(0, {
                    // //   cell_type: "code",
                    // //   source: "hejka"
                    // // });
                    // if (cells) {
                    //   // cells.get(0).sharedModel.setSource("hejka");
                    //   for (let i = 0; i < cells?.length; i++) {
                    //     // console.log(cells.get(i).sharedModel.source)
                    //     //console.log(cells.get(i).id);
                    //     //console.log(cells.get(i).sharedModel.getMetadata());
                    //     //let m = cells.get(i).sharedModel.getMetadata();
                    //     //m['showPoC'] = true;
                    //     //cells.get(i).sharedModel.setMetadata(m);
                    //   }
                    // }
                });
            }
        }
    }
    //https://github.com/jupyterlab/extension-examples/tree/main/signals
    //private _stateChanged = new Signal<ButtonWidget, ICount>(this);
    get cell() {
        return this.parent instanceof _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_0__.Cell ? this.parent : null;
    }
    get notebook() {
        var _a, _b;
        return ((_b = (_a = this.cell) === null || _a === void 0 ? void 0 : _a.parent) === null || _b === void 0 ? void 0 : _b.parent) instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.NotebookPanel
            ? this.cell.parent.parent
            : null;
    }
}


/***/ }),

/***/ "./lib/extendedcell/recipes.js":
/*!*************************************!*\
  !*** ./lib/extendedcell/recipes.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExecutionStatus: () => (/* binding */ ExecutionStatus),
/* harmony export */   SelectRecipeWidget: () => (/* binding */ SelectRecipeWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mljar/recipes */ "webpack/sharing/consume/default/@mljar/recipes/@mljar/recipes");
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mljar_recipes__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_3__);




var ExecutionStatus;
(function (ExecutionStatus) {
    ExecutionStatus["Wait"] = "Wait";
    ExecutionStatus["Success"] = "Success";
    ExecutionStatus["Error"] = "Error";
    ExecutionStatus["Warning"] = "Warning";
})(ExecutionStatus || (ExecutionStatus = {}));
const SelectRecipeComponent = ({ previousCode, previousErrorName, previousErrorValue, previousExecutionCount, cell, setCode, setPackages, runCell, executionSteps, deleteCell, addCell, variablesStatus, variables, checkPackage, checkedPackages, installPackage, installLog, clearExecutionSteps, meta, setMeta, changeCellToMarkdown, changeCellToCode, setEnv }) => {
    // useEffect(() => {
    //   console.log('cell changed');
    // }, [cell]);
    var _a;
    // cell.model.contentChanged.connect(() => {
    //   setPreviousCode(cell.model.sharedModel.getSource());
    // }, cell);
    let initialIsDark = false;
    const t = (_a = document.body.dataset) === null || _a === void 0 ? void 0 : _a.jpThemeName;
    if (t !== undefined && t.includes('Dark')) {
        initialIsDark = true;
    }
    else {
        initialIsDark = false;
    }
    const [isDark, setIsDark] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialIsDark);
    const getCellCode = () => {
        return cell.model.sharedModel.getSource();
    };
    var observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
            var _a;
            if (mutation.type === 'attributes') {
                if ((_a = document.body.attributes
                    .getNamedItem('data-jp-theme-name')) === null || _a === void 0 ? void 0 : _a.value.includes('Dark')) {
                    setIsDark(true);
                }
                else {
                    setIsDark(false);
                }
            }
        });
    });
    observer.observe(document.body, {
        attributes: true,
        attributeFilter: ['data-jp-theme-name']
    });
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: isDark ? 'poc-dark' : '' },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mljar_recipes__WEBPACK_IMPORTED_MODULE_1__.SelectRecipe, { previousCode: previousCode, previousErrorName: previousErrorName, previousErrorValue: previousErrorValue, previousExecutionCount: previousExecutionCount, setCode: setCode, setPackages: setPackages, runCell: runCell, executionSteps: executionSteps, deleteCell: deleteCell, addCell: addCell, variablesStatus: variablesStatus, variables: variables, checkPackage: checkPackage, checkedPackages: checkedPackages, installPackage: installPackage, installLog: installLog, clearExecutionSteps: clearExecutionSteps, metadata: meta, setMetadata: setMeta, changeCellToMarkdown: changeCellToMarkdown, changeCellToCode: changeCellToCode, cellType: cell.model.sharedModel.cell_type, getCellCode: getCellCode, setEnv: setEnv })));
};
class SelectRecipeWidget extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.ReactWidget {
    constructor(cell, setCode, setPackages, runCell, deleteCell, addCell, executionCount, meta, setMeta, changeCellToMarkdown, changeCellToCode, setEnv) {
        super();
        this._signal = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this._previousCode = '';
        this._previousErrorName = '';
        this._previousErrorValue = '';
        this._previousExecutionCount = 0;
        this._executionSteps = [];
        this._variablesStatus = 'unknown';
        this._variables = [];
        this._show = false;
        this.addClass('jp-react-widget');
        this._cell = cell;
        this._setCodeCallback = setCode;
        this._setPackagesCallback = setPackages;
        this._runCellCallback = runCell;
        this._deleteCell = deleteCell;
        this._addCell = addCell;
        this._previousExecutionCount = executionCount;
        this._checkPackage = (pkgInstallName, pkgImportName) => { };
        this._checkedPackages = {};
        this._installPackage = (installationName, importName) => { };
        this._installLog = '';
        this._meta = meta;
        this._setMeta = setMeta;
        this._changeCellToMarkdown = changeCellToMarkdown;
        this._changeCellToCode = changeCellToCode;
        this._setEnv = setEnv;
    }
    setExecutionSteps(steps) {
        this._executionSteps = steps;
        this.updateWidget();
    }
    setPreviousCode(src) {
        this._previousCode = src;
    }
    setPreviousExecutionCount(cnt) {
        this._previousExecutionCount = cnt;
    }
    setPreviousError(name, value) {
        this._previousErrorName = name;
        this._previousErrorValue = value;
    }
    updateWidget() {
        this._signal.emit();
    }
    setVariablesStatus(status) {
        this._variablesStatus = status;
    }
    setVariables(variables) {
        this._variables = variables;
        this.updateWidget();
    }
    setCheckPackage(checkPackage) {
        this._checkPackage = checkPackage;
    }
    setCheckedPackages(pkgs) {
        //console.log('set checked packages');
        //console.log({ pkgs });
        this._checkedPackages = pkgs;
        this.updateWidget();
    }
    setInstallPackage(installPackage) {
        this._installPackage = installPackage;
    }
    setInstallationLog(installLog) {
        this._installLog = installLog;
        this.updateWidget();
    }
    showWidget() {
        this._show = true;
        //this.show();
        this.updateWidget();
    }
    hideWidget() {
        this._show = false;
        //this.hide();
        this.updateWidget();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.UseSignal, { signal: this._signal }, () => {
                if (!this._show) {
                    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null);
                }
                else {
                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SelectRecipeComponent, { previousCode: this._previousCode, previousErrorName: this._previousErrorName, previousErrorValue: this._previousErrorValue, previousExecutionCount: this._previousExecutionCount, cell: this._cell, setCode: this._setCodeCallback, setPackages: this._setPackagesCallback, runCell: this._runCellCallback, executionSteps: this._executionSteps, deleteCell: this._deleteCell, addCell: this._addCell, variablesStatus: this._variablesStatus, variables: this._variables, checkPackage: this._checkPackage, checkedPackages: this._checkedPackages, installPackage: this._installPackage, installLog: this._installLog, clearExecutionSteps: () => this.setExecutionSteps([]), meta: this._meta, setMeta: this._setMeta, changeCellToMarkdown: this._changeCellToMarkdown, changeCellToCode: this._changeCellToCode, setEnv: this._setEnv }));
                }
            })));
    }
}


/***/ }),

/***/ "./lib/extendedcell/setEnv.js":
/*!************************************!*\
  !*** ./lib/extendedcell/setEnv.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SetEnv: () => (/* binding */ SetEnv)
/* harmony export */ });
class SetEnv {
    constructor(nb) {
        this._onIOPub = (msg) => {
            //console.log(msg);
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    // interface ContentData {
                    //   data: {
                    //     'text/plain': string;
                    //   }
                    // }
                    // const content = msg.content as ContentData;
                    // //console.log(content);
                    // try {
                    //   let contentDisplay: string = content.data["text/plain"] as string;
                    //   console.log(contentDisplay);
                    // } catch (e) {
                    //   console.log(e);
                    // }
                    break;
                default:
                    break;
            }
            return;
        };
        this._notebook = nb;
    }
    async run(envVariables) {
        var _a, _b, _c, _d;
        try {
            let newVars = [];
            envVariables.forEach(vs => {
                const k = vs[0];
                const v = vs[1];
                newVars.push(`"${k}":"${v}"`);
            });
            let code = `
__newVars = {${newVars.join(",")}}
__content = ""
try:
    with open(".env", "r") as __fin:
        __content = __fin.readlines()
except Exception as e:
    pass
__vars = {}
for __line in __content:
    if len(__line.split("=")) == 2:
      __vars[__line.split("=")[0].strip()] = __line.split("=")[1].strip()
for __k in __newVars:
    __vars[__k] = __newVars[__k]
with open(".env", "w") as __fout:
    for __k in __vars:
        __fout.write(f"{__k}={__vars[__k]}\\n")
print("env set ok")
`;
            await ((_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.ready);
            let future = (_d = (_c = (_b = this._notebook) === null || _b === void 0 ? void 0 : _b.sessionContext.session) === null || _c === void 0 ? void 0 : _c.kernel) === null || _d === void 0 ? void 0 : _d.requestExecute({
                code,
                store_history: false,
            });
            // console.log({ future });
            if (future) {
                future.onIOPub = this._onIOPub;
            }
        }
        catch (e) {
            console.log(e);
        }
    }
}


/***/ }),

/***/ "./lib/flags.js":
/*!**********************!*\
  !*** ./lib/flags.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getAlwaysOpen: () => (/* binding */ getAlwaysOpen),
/* harmony export */   setAlwaysOpen: () => (/* binding */ setAlwaysOpen)
/* harmony export */ });
/* harmony import */ var _extendedcell_header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./extendedcell/header */ "./lib/extendedcell/header.js");

const ALWAYS_OPEN_FLAG = 'alwaysOpenPieceOfCode';
const setFlag = (key, value) => {
    localStorage.setItem(key, value);
};
const getFlag = (key) => {
    return localStorage.getItem(key);
};
const setAlwaysOpen = (value) => {
    setFlag(ALWAYS_OPEN_FLAG, value.toString());
    if (value) {
        _extendedcell_header__WEBPACK_IMPORTED_MODULE_0__.RecipeWidgetsRegistry.getInstance().showLastSelectedCellId();
    }
    else {
        _extendedcell_header__WEBPACK_IMPORTED_MODULE_0__.RecipeWidgetsRegistry.getInstance().hideAll();
    }
};
const getAlwaysOpen = () => {
    const f = getFlag(ALWAYS_OPEN_FLAG);
    if (f === null) {
        return true;
    }
    return f === 'true';
};


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cakeIcon: () => (/* binding */ cakeIcon),
/* harmony export */   cakeOffIcon: () => (/* binding */ cakeOffIcon),
/* harmony export */   mIcon: () => (/* binding */ mIcon),
/* harmony export */   mljarStudioIcon: () => (/* binding */ mljarStudioIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_cake_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../style/icons/cake.svg */ "./style/icons/cake.svg");
/* harmony import */ var _style_icons_cakeoff_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../style/icons/cakeoff.svg */ "./style/icons/cakeoff.svg");
/* harmony import */ var _style_icons_m_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/icons/m.svg */ "./style/icons/m.svg");
/* harmony import */ var _style_icons_mljarStudio_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/icons/mljarStudio.svg */ "./style/icons/mljarStudio.svg");





const cakeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'cake-icon',
    svgstr: _style_icons_cake_svg__WEBPACK_IMPORTED_MODULE_1__
});
const cakeOffIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'cake-off-icon',
    svgstr: _style_icons_cakeoff_svg__WEBPACK_IMPORTED_MODULE_2__
});
const mIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'm-icon',
    svgstr: _style_icons_m_svg__WEBPACK_IMPORTED_MODULE_3__
});
const mljarStudioIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'mljar-studio-icon',
    svgstr: _style_icons_mljarStudio_svg__WEBPACK_IMPORTED_MODULE_4__
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _commands__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./commands */ "./lib/commands/index.js");
/* harmony import */ var _flags__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./flags */ "./lib/flags.js");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_polling__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/polling */ "webpack/sharing/consume/default/@lumino/polling");
/* harmony import */ var _lumino_polling__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_polling__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");
/* harmony import */ var _selectRecipeLeft__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./selectRecipeLeft */ "./lib/selectRecipeLeft.js");
/* harmony import */ var _contexts_activeCell__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./contexts/activeCell */ "./lib/contexts/activeCell.js");



// import { extendedCellFactory } from './extendedcell';

/**
 * Initialization data for the pieceofcode extension.
 */
const plugin = {
    id: 'pieceofcode:plugin',
    description: 'Write code with UI.',
    autoStart: true,
    optional: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__.ISettingRegistry, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.IThemeManager],
    activate: async (app, settingRegistry, themeManager) => {
        console.log('Piece of Code extension is activated!');
        const tm = themeManager;
        if (tm) {
            if (!tm.isToggledThemeScrollbars())
                tm.toggleThemeScrollbars();
        }
        if (settingRegistry) {
            settingRegistry
                .load(plugin.id)
                .then(settings => {
                const updateSettings = () => {
                    const alwaysOpen = settings.get('alwaysOpenPieceOfCode')
                        .composite;
                    if (alwaysOpen !== undefined) {
                        (0,_flags__WEBPACK_IMPORTED_MODULE_2__.setAlwaysOpen)(alwaysOpen);
                    }
                };
                updateSettings();
                settings.changed.connect(updateSettings);
                // console.log('pieceofcode settings loaded:', settings.composite);
            })
                .catch(reason => {
                console.error('Failed to load settings for pieceofcode.', reason);
            });
        }
    }
};


// import { jupyterFaviconIcon } from '@jupyterlab/ui-components';



const SPLASH_RECOVER_TIMEOUT = 12000;
const splash = {
    id: '@jupyterlab/apputils-extension:splash2',
    description: 'Provides the splash screen.',
    autoStart: true,
    requires: [_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_3__.ITranslator],
    provides: _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ISplashScreen,
    activate: (app, translator) => {
        const trans = translator.load('jupyterlab');
        const { commands, restored } = app;
        // Create splash element and populate it.
        const splash = document.createElement('div');
        const logo = document.createElement('div');
        splash.id = 'jupyterlab-splash';
        logo.id = 'main-logo';
        _icons__WEBPACK_IMPORTED_MODULE_6__.mljarStudioIcon.element({
            container: logo,
            stylesheet: 'splash'
        });
        splash.appendChild(logo);
        // Create debounced recovery dialog function.
        let dialog;
        const recovery = new _lumino_polling__WEBPACK_IMPORTED_MODULE_4__.Throttler(async () => {
            if (dialog) {
                return;
            }
            dialog = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog({
                title: trans.__('Loading…'),
                body: trans.__(`The loading screen is taking a long time.
Would you like to clear the workspace or keep waiting?`),
                buttons: [
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.cancelButton({ label: trans.__('Keep Waiting') }),
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.warnButton({ label: trans.__('Clear Workspace') })
                ]
            });
            try {
                const result = await dialog.launch();
                dialog.dispose();
                dialog = null;
                if (result.button.accept && commands.hasCommand('apputils:reset')) {
                    return commands.execute('apputils:reset');
                }
                // Re-invoke the recovery timer in the next frame.
                requestAnimationFrame(() => {
                    // Because recovery can be stopped, handle invocation rejection.
                    void recovery.invoke().catch(_ => undefined);
                });
            }
            catch (error) {
                /* no-op */
            }
        }, { limit: SPLASH_RECOVER_TIMEOUT, edge: 'trailing' });
        // Return ISplashScreen.
        let splashCount = 0;
        return {
            show: (light = true) => {
                splash.classList.remove('splash-fade');
                //splash.classList.toggle('light', light);
                //splash.classList.toggle('dark', !light);
                splashCount++;
                document.body.appendChild(splash);
                // Because recovery can be stopped, handle invocation rejection.
                void recovery.invoke().catch(_ => undefined);
                return new _lumino_disposable__WEBPACK_IMPORTED_MODULE_5__.DisposableDelegate(async () => {
                    await restored;
                    if (--splashCount === 0) {
                        void recovery.stop();
                        if (dialog) {
                            dialog.dispose();
                            dialog = null;
                        }
                        splash.classList.add('splash-fade');
                        window.setTimeout(() => {
                            document.body.removeChild(splash);
                        }, 3000);
                    }
                });
            }
        };
    }
};


const pocLeft = {
    id: '@mljar/pocLeft',
    autoStart: true,
    activate: async (app) => {
        const activeCellManager = new _contexts_activeCell__WEBPACK_IMPORTED_MODULE_7__.ActiveCellManager(app.shell);
        let widget = (0,_selectRecipeLeft__WEBPACK_IMPORTED_MODULE_8__.createPocLeft)(activeCellManager);
        /**
         * Add Chat widget to right sidebar
         */
        app.shell.add(widget, 'left', { rank: 2000 });
    }
};
// extendedCellFactory
const plugins = [plugin, _commands__WEBPACK_IMPORTED_MODULE_9__.commandsPlugin, splash, pocLeft];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugins);


/***/ }),

/***/ "./lib/inspector/baseInspector.js":
/*!****************************************!*\
  !*** ./lib/inspector/baseInspector.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BaseInspector: () => (/* binding */ BaseInspector)
/* harmony export */ });
/* harmony import */ var _codes_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./codes/utils */ "./lib/inspector/codes/utils.js");

var notebookPackageManager = {};
class BaseInspector {
    constructor(nb) {
        var _a;
        this._onCheckPackageManager = (msg) => {
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'stream':
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    const content = msg.content;
                    if (this._notebookId) {
                        //                     n(N)ot a conda environment
                        if (content.text.includes('ot a conda environment')) {
                            notebookPackageManager[this._notebookId] = 'pip';
                        }
                        else {
                            notebookPackageManager[this._notebookId] = 'conda';
                        }
                    }
                    break;
                default:
                    break;
            }
            return;
        };
        this._notebook = nb;
        this._notebookId = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.id;
    }
    getPackageManager() {
        let packageManager = 'conda';
        if (this._notebookId && this._notebookId in notebookPackageManager) {
            packageManager = notebookPackageManager[this._notebookId];
        }
        return packageManager;
    }
    checkPackageManager() {
        var _a, _b, _c;
        // if already checked, then skip this step
        if (this._notebookId && this._notebookId in notebookPackageManager) {
            return;
        }
        // console.log('Check package manager');
        let future = (_c = (_b = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.session) === null || _b === void 0 ? void 0 : _b.kernel) === null || _c === void 0 ? void 0 : _c.requestExecute({
            code: _codes_utils__WEBPACK_IMPORTED_MODULE_0__.checkIfConda,
            store_history: false,
        });
        if (future) {
            future.onIOPub = this._onCheckPackageManager;
        }
    }
}


/***/ }),

/***/ "./lib/inspector/codes/init.js":
/*!*************************************!*\
  !*** ./lib/inspector/codes/init.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   codeInitInspector: () => (/* binding */ codeInitInspector)
/* harmony export */ });
// below code is based on
// https://github.com/jupyterlab-contrib/jupyterlab-variableInspector
const codeInitInspector = `import json
import sys
from importlib import __import__
from IPython import get_ipython
from IPython.core.magics.namespace import NamespaceMagics


_jupyterlab_variableinspector_nms = NamespaceMagics()
_jupyterlab_variableinspector_Jupyter = get_ipython()
_jupyterlab_variableinspector_nms.shell = _jupyterlab_variableinspector_Jupyter.kernel.shell

__np = None
__pd = None
__pyspark = None
__tf = None
__K = None
__torch = None
__ipywidgets = None
__xr = None


def _attempt_import(module):
    try:
        return __import__(module)
    except ImportError:
        return None


def _check_imported():
    global __np, __pd, __pyspark, __tf, __K, __torch, __ipywidgets, __xr

    __np = _attempt_import('numpy')
    __pd = _attempt_import('pandas')
    __pyspark = _attempt_import('pyspark')
    __tf = _attempt_import('tensorflow')
    __K = _attempt_import('keras.backend') or _attempt_import('tensorflow.keras.backend')
    __torch = _attempt_import('torch')
    __ipywidgets = _attempt_import('ipywidgets')
    __xr = _attempt_import('xarray')


def _jupyterlab_variableinspector_getsizeof(x):
    if type(x).__name__ in ['ndarray', 'Series']:
        return x.nbytes
    elif __pyspark and isinstance(x, __pyspark.sql.DataFrame):
        return "?"
    elif __tf and isinstance(x, __tf.Variable):
        return "?"
    elif __torch and isinstance(x, __torch.Tensor):
        return x.element_size() * x.nelement()
    elif __pd and type(x).__name__ == 'DataFrame':
        return x.memory_usage().sum()
    else:
        return sys.getsizeof(x)


def _jupyterlab_variableinspector_getshapeof(x):
    if __pd and isinstance(x, __pd.DataFrame):
        return "%d rows x %d cols" % x.shape
    if __pd and isinstance(x, __pd.Series):
        return "%d rows" % x.shape
    if __np and isinstance(x, __np.ndarray):
        shape = " x ".join([str(i) for i in x.shape])
        return "%s" % shape
    if __pyspark and isinstance(x, __pyspark.sql.DataFrame):
        return "? rows x %d cols" % len(x.columns)
    if __tf and isinstance(x, __tf.Variable):
        shape = " x ".join([str(int(i)) for i in x.shape])
        return "%s" % shape
    if __tf and isinstance(x, __tf.Tensor):
        shape = " x ".join([str(int(i)) for i in x.shape])
        return "%s" % shape
    if __torch and isinstance(x, __torch.Tensor):
        shape = " x ".join([str(int(i)) for i in x.shape])
        return "%s" % shape
    if __xr and isinstance(x, __xr.DataArray):
        shape = " x ".join([str(int(i)) for i in x.shape])
        return "%s" % shape
    if isinstance(x, list):
        return "%s" % len(x)
    if isinstance(x, dict):
        return "%s keys" % len(x)
    return None

def _jupyterlab_variableinspector_getcolumnsof(x):
    if __pd and isinstance(x, __pd.DataFrame):
        return list(x.columns)
    return []

def _jupyterlab_variableinspector_getcolumntypesof(x):
    if __pd and isinstance(x, __pd.DataFrame):
        return [str(t) for t in x.dtypes]
    return []


def _jupyterlab_variableinspector_getcontentof(x):
    # returns content in a friendly way for python variables
    # pandas and numpy
    if __pd and isinstance(x, __pd.DataFrame):
        colnames = ', '.join(x.columns.map(str))
        content = "Columns: %s" % colnames
    elif __pd and isinstance(x, __pd.Series):
        content = str(x.values).replace(" ", ", ")[1:-1]
        content = content.replace("\\n", "")
    elif __np and isinstance(x, __np.ndarray):
        content = x.__repr__()
    elif __xr and isinstance(x, __xr.DataArray):
        content = x.values.__repr__()
    else:
        content = str(x)

    if len(content) > 150:
        return content[:150] + " ..."
    else:
        return content


def _jupyterlab_variableinspector_is_matrix(x):
    # True if type(x).__name__ in ["DataFrame", "ndarray", "Series"] else False
    if __pd and isinstance(x, __pd.DataFrame):
        return True
    if __pd and isinstance(x, __pd.Series):
        return True
    if __np and isinstance(x, __np.ndarray) and len(x.shape) <= 2:
        return True
    if __pyspark and isinstance(x, __pyspark.sql.DataFrame):
        return True
    if __tf and isinstance(x, __tf.Variable) and len(x.shape) <= 2:
        return True
    if __tf and isinstance(x, __tf.Tensor) and len(x.shape) <= 2:
        return True
    if __torch and isinstance(x, __torch.Tensor) and len(x.shape) <= 2:
        return True
    if __xr and isinstance(x, __xr.DataArray) and len(x.shape) <= 2:
        return True
    if isinstance(x, list):
        return True
    return False


def _jupyterlab_variableinspector_is_widget(x):
    return __ipywidgets and issubclass(x, __ipywidgets.DOMWidget)


def _jupyterlab_variableinspector_dict_list():
    _check_imported()
    def keep_cond(v):
        try:
            obj = eval(v)
            if isinstance(obj, str):
                return True
            if __tf and isinstance(obj, __tf.Variable):
                return True
            if __pd and __pd is not None and (
                isinstance(obj, __pd.core.frame.DataFrame)
                or isinstance(obj, __pd.core.series.Series)):
                return True
            if __xr and __xr is not None and isinstance(obj, __xr.DataArray):
                return True
            if str(obj).startswith("<psycopg.Connection"):
                return True
            if str(obj).startswith("<module"):
                return False
            if str(obj).startswith("<class"):
                return False 
            if str(obj).startswith("<function"):
                return False 
            if  v in ['__np', '__pd', '__pyspark', '__tf', '__K', '__torch', '__ipywidgets', '__xr']:
                return obj is not None
            if str(obj).startswith("_Feature"):
                # removes tf/keras objects
                return False
            return True
        except:
            return False
    values = _jupyterlab_variableinspector_nms.who_ls()
    
    vardic = []
    for _v in values:
        if keep_cond(_v):
            _ev = eval(_v)
            vardic += [{
                'varName': _v,
                'varType': type(_ev).__name__, 
                'varSize': str(_jupyterlab_variableinspector_getsizeof(_ev)), 
                'varShape': str(_jupyterlab_variableinspector_getshapeof(_ev)) if _jupyterlab_variableinspector_getshapeof(_ev) else '', 
                'varContent': "", # str(_jupyterlab_variableinspector_getcontentof(_ev)), 
                'isMatrix': _jupyterlab_variableinspector_is_matrix(_ev),
                'isWidget': _jupyterlab_variableinspector_is_widget(type(_ev)),
                'varColumns': _jupyterlab_variableinspector_getcolumnsof(_ev),
                'varColumnTypes': _jupyterlab_variableinspector_getcolumntypesof(_ev),
            }]
  
    return json.dumps(vardic, ensure_ascii=False)


def _jupyterlab_variableinspector_getmatrixcontent(x, max_rows=10000):
    # to do: add something to handle this in the future
    threshold = max_rows

    if __pd and __pyspark and isinstance(x, __pyspark.sql.DataFrame):
        df = x.limit(threshold).toPandas()
        return _jupyterlab_variableinspector_getmatrixcontent(df.copy())
    elif __np and __pd and type(x).__name__ == "DataFrame":
        if threshold is not None:
            x = x.head(threshold)
        x.columns = x.columns.map(str)
        return x.to_json(orient="table", default_handler=_jupyterlab_variableinspector_default, force_ascii=False)
    elif __np and __pd and type(x).__name__ == "Series":
        if threshold is not None:
            x = x.head(threshold)
        return x.to_json(orient="table", default_handler=_jupyterlab_variableinspector_default, force_ascii=False)
    elif __np and __pd and type(x).__name__ == "ndarray":
        df = __pd.DataFrame(x)
        return _jupyterlab_variableinspector_getmatrixcontent(df)
    elif __tf and (isinstance(x, __tf.Variable) or isinstance(x, __tf.Tensor)):
        df = __K.get_value(x)
        return _jupyterlab_variableinspector_getmatrixcontent(df)
    elif __torch and isinstance(x, __torch.Tensor):
        df = x.cpu().numpy()
        return _jupyterlab_variableinspector_getmatrixcontent(df)
    elif __xr and isinstance(x, __xr.DataArray):
        df = x.to_numpy()
        return _jupyterlab_variableinspector_getmatrixcontent(df)
    elif isinstance(x, list):
        s = __pd.Series(x)
        return _jupyterlab_variableinspector_getmatrixcontent(s)


def _jupyterlab_variableinspector_displaywidget(widget):
    display(widget)


def _jupyterlab_variableinspector_default(o):
    if isinstance(o, __np.number): return int(o)  
    raise TypeError


def _jupyterlab_variableinspector_deletevariable(x):
    exec("del %s" % x, globals())`;


/***/ }),

/***/ "./lib/inspector/codes/utils.js":
/*!**************************************!*\
  !*** ./lib/inspector/codes/utils.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   checkIfConda: () => (/* binding */ checkIfConda),
/* harmony export */   checkPackageCode: () => (/* binding */ checkPackageCode),
/* harmony export */   getVars: () => (/* binding */ getVars),
/* harmony export */   installPackageConda: () => (/* binding */ installPackageConda),
/* harmony export */   installPackagePip: () => (/* binding */ installPackagePip)
/* harmony export */ });
// 
const getVars = `_jupyterlab_variableinspector_dict_list()`;
const installPackageConda = (pkg) => `
import sys
!conda install --yes --prefix {sys.prefix} -c conda-forge ${pkg}`;
const installPackagePip = (pkg) => `
import sys
!{sys.executable} -m pip install ${pkg}`;
const checkIfConda = `import sys
!conda list --prefix {sys.prefix}`;
const checkPackageCode = (pkgInstallName, pkgImportName) => `
from importlib import __import__
try:
    try:
        print('{' + f'"package": "${pkgImportName}", "version": "{__import__(f"${pkgImportName}").__version__}"' + '}')
    except AttributeError:
        import importlib.metadata as __imeta__
        print('{' + f'"package": "${pkgImportName}", "version": "{__imeta__.version(f"${pkgInstallName}")}"' + '}')
except Exception:
    print('{"package": "${pkgImportName}", "version": "error"}')
  `;


/***/ }),

/***/ "./lib/inspector/packagesInspector.js":
/*!********************************************!*\
  !*** ./lib/inspector/packagesInspector.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PackagesInspector: () => (/* binding */ PackagesInspector)
/* harmony export */ });
/* harmony import */ var _codes_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./codes/utils */ "./lib/inspector/codes/utils.js");
/* harmony import */ var _baseInspector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./baseInspector */ "./lib/inspector/baseInspector.js");


var checkedPackages = {};
class PackagesInspector extends _baseInspector__WEBPACK_IMPORTED_MODULE_0__.BaseInspector {
    constructor(nb, setAvailablePackages, setInstallationLog) {
        super(nb);
        this._onCheckPackage = (msg) => {
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'stream':
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    const content = msg.content;
                    try {
                        const p = JSON.parse(content.text);
                        if (this._notebookId) {
                            if (!(this._notebookId in checkedPackages)) {
                                checkedPackages[this._notebookId] = { [p.package]: p.version };
                            }
                            else {
                                checkedPackages[this._notebookId][p.package] = p.version;
                            }
                            this._setAvailablePackages(checkedPackages[this._notebookId]);
                        }
                    }
                    catch (e) {
                        console.log(e);
                    }
                    break;
                default:
                    break;
            }
            return;
        };
        this._onInstallPackage = (msg) => {
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'stream':
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    const content = msg.content;
                    console.log(content);
                    this._setInstallationLog(content.text);
                    break;
                default:
                    break;
            }
            return;
        };
        this._setAvailablePackages = setAvailablePackages;
        this._setInstallationLog = setInstallationLog;
    }
    /*
    Check package is available
    */
    checkPackage(pkgInstallName, pkgImportName) {
        var _a, _b, _c;
        this.checkPackageManager();
        if (this._notebookId) {
            if (this._notebookId in checkedPackages && pkgImportName in checkedPackages[this._notebookId]) {
                this._setAvailablePackages(checkedPackages[this._notebookId]);
            }
            else {
                let future = (_c = (_b = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.session) === null || _b === void 0 ? void 0 : _b.kernel) === null || _c === void 0 ? void 0 : _c.requestExecute({
                    code: (0,_codes_utils__WEBPACK_IMPORTED_MODULE_1__.checkPackageCode)(pkgInstallName, pkgImportName),
                    store_history: false,
                });
                if (future) {
                    future.onIOPub = this._onCheckPackage;
                }
            }
        }
    }
    /*
    Installer
    */
    installPackage(installationName, importName) {
        // console.log('Install', importName, 'with', packageManager);
        var _a, _b, _c;
        let packageManager = this.getPackageManager();
        if (this._notebookId) {
            if (!(this._notebookId in checkedPackages)) {
                checkedPackages[this._notebookId] = { [importName]: 'install' };
            }
            else {
                checkedPackages[this._notebookId][importName] = 'install';
            }
            console.log("set installed package");
            console.log("set installed package");
            console.log("set installed package");
            this._setAvailablePackages(checkedPackages[this._notebookId]);
            // this._setInstalledPackages(checkedPackages[this._notebookId]);
        }
        console.log("what package manager?");
        console.log(packageManager);
        const code = packageManager === 'conda' ? (0,_codes_utils__WEBPACK_IMPORTED_MODULE_1__.installPackageConda)(installationName) : (0,_codes_utils__WEBPACK_IMPORTED_MODULE_1__.installPackagePip)(installationName);
        console.log("code", code);
        let future = (_c = (_b = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.session) === null || _b === void 0 ? void 0 : _b.kernel) === null || _c === void 0 ? void 0 : _c.requestExecute({
            code,
            store_history: false,
        });
        console.log("future", future);
        if (future) {
            console.log("here");
            // will be needed to collect logs from installation
            future.onIOPub = this._onInstallPackage.bind(this);
            future.done.then(() => {
                console.log("future done!");
                if (this._notebookId && this._notebookId in checkedPackages) {
                    // delete all packages, we need to re-check all packages again
                    // there might be installed additional dependencies during this install
                    delete checkedPackages[this._notebookId];
                    this.checkPackage(installationName, importName);
                    this._setInstallationLog("");
                }
            });
        }
    }
}


/***/ }),

/***/ "./lib/inspector/variablesInspector.js":
/*!*********************************************!*\
  !*** ./lib/inspector/variablesInspector.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VariablesInspector: () => (/* binding */ VariablesInspector)
/* harmony export */ });
/* harmony import */ var _codes_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./codes/init */ "./lib/inspector/codes/init.js");
/* harmony import */ var _codes_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./codes/utils */ "./lib/inspector/codes/utils.js");
/* harmony import */ var _baseInspector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./baseInspector */ "./lib/inspector/baseInspector.js");



var notebooksInitialized = [];
class VariablesInspector extends _baseInspector__WEBPACK_IMPORTED_MODULE_0__.BaseInspector {
    constructor(nb, setVariablesStatus, setVariables) {
        super(nb);
        this._onIOPub = (msg) => {
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    const content = msg.content;
                    try {
                        let contentDisplay = content.data["text/plain"];
                        contentDisplay = contentDisplay.slice(1, -1);
                        contentDisplay = contentDisplay
                            .replace(/\\"/g, '"')
                            .replace(/\\'/g, "'");
                        const variables = JSON.parse(contentDisplay);
                        console.log(variables);
                        this._setVariables(variables);
                        this._setVariablesStatus("loaded");
                        if (this._notebookId && !notebooksInitialized.includes(this._notebookId)) {
                            notebooksInitialized.push(this._notebookId);
                        }
                    }
                    catch (e) {
                        console.log(e);
                        this._setVariables([]);
                        this._setVariablesStatus("error");
                    }
                    break;
                default:
                    break;
            }
            return;
        };
        this._setVariablesStatus = setVariablesStatus;
        this._setVariables = setVariables;
    }
    async getVariables() {
        var _a, _b, _c, _d;
        try {
            this.checkPackageManager();
            this._setVariablesStatus("loading");
            this._setVariables([]);
            let code = '';
            if (this._notebookId === undefined) {
                code += _codes_init__WEBPACK_IMPORTED_MODULE_1__.codeInitInspector + '\n\n';
            }
            if (this._notebookId && !notebooksInitialized.includes(this._notebookId)) {
                code += _codes_init__WEBPACK_IMPORTED_MODULE_1__.codeInitInspector + '\n\n';
            }
            code += _codes_utils__WEBPACK_IMPORTED_MODULE_2__.getVars;
            await ((_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.ready);
            let future = (_d = (_c = (_b = this._notebook) === null || _b === void 0 ? void 0 : _b.sessionContext.session) === null || _c === void 0 ? void 0 : _c.kernel) === null || _d === void 0 ? void 0 : _d.requestExecute({
                code,
                store_history: false,
            });
            if (future) {
                future.onIOPub = this._onIOPub;
                future.done.then(() => {
                    this._setVariablesStatus("loaded");
                });
            }
        }
        catch (e) {
            console.log(e);
        }
    }
}


/***/ }),

/***/ "./lib/selectRecipeLeft.js":
/*!*********************************!*\
  !*** ./lib/selectRecipeLeft.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createPocLeft: () => (/* binding */ createPocLeft)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contexts_activeCell__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./contexts/activeCell */ "./lib/contexts/activeCell.js");
/* harmony import */ var _contexts_variables__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./contexts/variables */ "./lib/contexts/variables.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");
/* harmony import */ var _contexts_packages__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./contexts/packages */ "./lib/contexts/packages.js");
/* harmony import */ var _selectRecipeLeftComponent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./selectRecipeLeftComponent */ "./lib/selectRecipeLeftComponent.js");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_2__);








class PieceOfCodeWidget extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(activeCellManager) {
        super();
        this._signal = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_2__.Signal(this);
        this._activeCellManager = activeCellManager;
    }
    updateWidget() {
        this._signal.emit();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.UseSignal, { signal: this._signal }, () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_activeCell__WEBPACK_IMPORTED_MODULE_3__.ActiveCellContextProvider, { activeCellManager: this._activeCellManager },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_variables__WEBPACK_IMPORTED_MODULE_4__.VariablesContextProvider, { activeCellManager: this._activeCellManager },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_packages__WEBPACK_IMPORTED_MODULE_5__.PackagesContextProvider, { activeCellManager: this._activeCellManager, updateWidget: this.updateWidget.bind(this) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_selectRecipeLeftComponent__WEBPACK_IMPORTED_MODULE_6__.PieceOfCodeComponent, null)))))))));
    }
}
function createPocLeft(activeCellManager) {
    const widget = new PieceOfCodeWidget(activeCellManager);
    widget.id = 'mljar::piece-of-code';
    widget.title.icon = _icons__WEBPACK_IMPORTED_MODULE_7__.cakeIcon;
    widget.title.caption = 'Piece of Code';
    widget.addClass("overflowYAuto");
    return widget;
}


/***/ }),

/***/ "./lib/selectRecipeLeftComponent.js":
/*!******************************************!*\
  !*** ./lib/selectRecipeLeftComponent.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PieceOfCodeComponent: () => (/* binding */ PieceOfCodeComponent)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mljar/recipes */ "webpack/sharing/consume/default/@mljar/recipes/@mljar/recipes");
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mljar_recipes__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contexts_activeCell__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contexts/activeCell */ "./lib/contexts/activeCell.js");
/* harmony import */ var _contexts_codeCell__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./contexts/codeCell */ "./lib/contexts/codeCell.js");
/* harmony import */ var _contexts_variables__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./contexts/variables */ "./lib/contexts/variables.js");
/* harmony import */ var _contexts_packages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./contexts/packages */ "./lib/contexts/packages.js");






const PieceOfCodeComponent = () => {
    const activeCell = (0,_contexts_activeCell__WEBPACK_IMPORTED_MODULE_2__.useActiveCellContext)();
    const variables = (0,_contexts_variables__WEBPACK_IMPORTED_MODULE_3__.useVariablesContext)();
    const packages = (0,_contexts_packages__WEBPACK_IMPORTED_MODULE_4__.usePackagesContext)();
    const [code, setCode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [importCode, setImportCode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    if (!activeCell.exists) {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: '2rem', fontWeight: 'bold', textAlign: 'center' } }, "Please open notebook"));
    }
    const checkPackage = (pkgInstallName, pkgImportName) => {
        packages.checkPackage(pkgInstallName, pkgImportName);
    };
    const installPackage = (pkgInstallName, pkgImportName) => {
        packages.installPackage(pkgInstallName, pkgImportName);
    };
    const useThisCode = () => {
        console.log('use this code');
        console.log(importCode, code);
        activeCell.manager.setContent(importCode + '\n' + code);
        // console.log(activeCell.manager.firstCodeCellSource());
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mljar_recipes__WEBPACK_IMPORTED_MODULE_1__.SelectRecipeLeft, { previousCode: '', previousErrorName: '', previousErrorValue: '', previousExecutionCount: 0, setCode: (code) => {
                setCode(code);
            }, setPackages: (imports) => {
                setImportCode(imports.join('\n'));
            }, runCell: () => { }, executionSteps: [], deleteCell: () => { }, addCell: () => {
                if (activeCell.exists) {
                    activeCell.manager.insertBelow('test');
                }
            }, variablesStatus: variables.status, variables: variables.variables, checkPackage: checkPackage, checkedPackages: packages.packages, installPackage: installPackage, installLog: packages.installLog, clearExecutionSteps: () => { }, metadata: {}, setMetadata: (m) => { }, changeCellToMarkdown: () => { }, changeCellToCode: () => { }, cellType: 'code', getCellCode: () => '', setEnv: () => { } }),
        code && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                    border: '1px solid #eee',
                    margin: '8px',
                    borderRadius: '7px'
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '5px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_codeCell__WEBPACK_IMPORTED_MODULE_5__.CodeCellComponent, { cellInput: importCode + '\n' + code, languageMimetype: "python" }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                    margin: '8px'
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "useCodeButton", role: "button", onClick: () => useThisCode() }, "Use this code"))))));
};


/***/ }),

/***/ "./style/icons/cake.svg":
/*!******************************!*\
  !*** ./style/icons/cake.svg ***!
  \******************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" class=\"icon icon-tabler icon-tabler-cake-off\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke=\"currentColor\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path stroke=\"none\" d=\"M0 0h24v24H0z\" fill=\"none\"/><path d=\"M3 20h18v-8a3 3 0 0 0 -3 -3h-12a3 3 0 0 0 -3 3v8z\" /><path d=\"M3 14.803c.312 .135 .654 .204 1 .197a2.4 2.4 0 0 0 2 -1a2.4 2.4 0 0 1 2 -1a2.4 2.4 0 0 1 2 1a2.4 2.4 0 0 0 2 1a2.4 2.4 0 0 0 2 -1a2.4 2.4 0 0 1 2 -1a2.4 2.4 0 0 1 2 1a2.4 2.4 0 0 0 2 1c.35 .007 .692 -.062 1 -.197\" /><path d=\"M12 4l1.465 1.638a2 2 0 1 1 -3.015 .099l1.55 -1.737z\" /></svg>";

/***/ }),

/***/ "./style/icons/cakeoff.svg":
/*!*********************************!*\
  !*** ./style/icons/cakeoff.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" class=\"icon icon-tabler icon-tabler-cake-off\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke=\"currentColor\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path stroke=\"none\" d=\"M0 0h24v24H0z\" fill=\"none\"/><path d=\"M21 17v-5a3 3 0 0 0 -3 -3h-5m-4 0h-3a3 3 0 0 0 -3 3v8h17\" /><path d=\"M3 14.803c.312 .135 .654 .204 1 .197a2.4 2.4 0 0 0 2 -1a2.4 2.4 0 0 1 2 -1a2.4 2.4 0 0 1 2 1a2.4 2.4 0 0 0 2 1a2.4 2.4 0 0 0 2 -1m4 0a2.4 2.4 0 0 0 2 1c.35 .007 .692 -.062 1 -.197\" /><path d=\"M10.172 6.188c.07 -.158 .163 -.31 .278 -.451l1.55 -1.737l1.465 1.638a2 2 0 0 1 -.65 3.19\" /><path d=\"M3 3l18 18\" /></svg>";

/***/ }),

/***/ "./style/icons/m.svg":
/*!***************************!*\
  !*** ./style/icons/m.svg ***!
  \***************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"1024\" zoomAndPan=\"magnify\" viewBox=\"0 0 768 767.999994\" height=\"1024\" preserveAspectRatio=\"xMidYMid meet\" version=\"1.0\"><defs><g/><clipPath id=\"a019ea6fbe\"><path d=\"M 33.050781 35.960938 L 745.660156 35.960938 L 745.660156 748.570312 L 33.050781 748.570312 Z M 33.050781 35.960938 \" clipRule=\"nonzero\"/></clipPath><clipPath id=\"e0fdfad94b\"><path d=\"M 389.355469 35.960938 C 192.574219 35.960938 33.050781 195.484375 33.050781 392.265625 C 33.050781 589.046875 192.574219 748.570312 389.355469 748.570312 C 586.136719 748.570312 745.660156 589.046875 745.660156 392.265625 C 745.660156 195.484375 586.136719 35.960938 389.355469 35.960938 Z M 389.355469 35.960938 \" clipRule=\"nonzero\"/></clipPath></defs><g clip-path=\"url(#a019ea6fbe)\"><g clip-path=\"url(#e0fdfad94b)\"><path fill=\"#0099cc\" d=\"M 33.050781 35.960938 L 745.660156 35.960938 L 745.660156 748.570312 L 33.050781 748.570312 Z M 33.050781 35.960938 \" fill-opacity=\"1\" fillRule=\"nonzero\"/></g></g><g fill=\"#ffffff\" fill-opacity=\"1\"><g transform=\"translate(139.916115, 561.03477)\"><g><path d=\"M 207.765625 -161.46875 C 207.765625 -189.25 204.195312 -208.925781 197.0625 -220.5 C 189.925781 -232.070312 177.675781 -237.859375 160.3125 -237.859375 C 154.90625 -237.859375 149.304688 -237.566406 143.515625 -236.984375 C 137.734375 -236.410156 132.144531 -235.738281 126.75 -234.96875 L 126.75 0 L 40.515625 0 L 40.515625 -294 C 47.835938 -295.925781 56.414062 -297.945312 66.25 -300.0625 C 76.09375 -302.1875 86.515625 -304.117188 97.515625 -305.859375 C 108.515625 -307.597656 119.800781 -308.945312 131.375 -309.90625 C 142.945312 -310.875 154.328125 -311.359375 165.515625 -311.359375 C 187.503906 -311.359375 205.347656 -308.5625 219.046875 -302.96875 C 232.742188 -297.375 244.03125 -290.71875 252.90625 -283 C 265.25 -291.875 279.425781 -298.816406 295.4375 -303.828125 C 311.457031 -308.847656 326.21875 -311.359375 339.71875 -311.359375 C 364.019531 -311.359375 383.984375 -307.984375 399.609375 -301.234375 C 415.242188 -294.484375 427.6875 -284.929688 436.9375 -272.578125 C 446.195312 -260.234375 452.5625 -245.570312 456.03125 -228.59375 C 459.507812 -211.625 461.25 -192.722656 461.25 -171.890625 L 461.25 0 L 375.015625 0 L 375.015625 -161.46875 C 375.015625 -189.25 371.445312 -208.925781 364.3125 -220.5 C 357.175781 -232.070312 344.925781 -237.859375 327.5625 -237.859375 C 322.9375 -237.859375 316.472656 -236.703125 308.171875 -234.390625 C 299.878906 -232.078125 293.03125 -229.179688 287.625 -225.703125 C 290.332031 -216.828125 292.070312 -207.46875 292.84375 -197.625 C 293.613281 -187.789062 294 -177.28125 294 -166.09375 L 294 0 L 207.765625 0 Z M 207.765625 -161.46875 \"/></g></g></g></svg>";

/***/ }),

/***/ "./style/icons/mljarStudio.svg":
/*!*************************************!*\
  !*** ./style/icons/mljarStudio.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"1024\" zoomAndPan=\"magnify\" viewBox=\"0 0 768 767.999994\" height=\"1024\" preserveAspectRatio=\"xMidYMid meet\" version=\"1.0\"><defs><g/><clipPath id=\"572969ecf2\"><path d=\"M 503 51.820312 L 611 51.820312 L 611 159 L 503 159 Z M 503 51.820312 \" clipRule=\"nonzero\"/></clipPath><clipPath id=\"a88d1680c1\"><path d=\"M 453 354 L 670 354 L 670 469.570312 L 453 469.570312 Z M 453 354 \" clipRule=\"nonzero\"/></clipPath><clipPath id=\"b8d5c88bf8\"><path d=\"M 680 218 L 744.5625 218 L 744.5625 283 L 680 283 Z M 680 218 \" clipRule=\"nonzero\"/></clipPath><clipPath id=\"c0165df3b9\"><path d=\"M 64.042969 102.457031 L 416.8125 102.457031 L 416.8125 455.226562 L 64.042969 455.226562 Z M 64.042969 102.457031 \" clipRule=\"nonzero\"/></clipPath><clipPath id=\"8fed9601f6\"><path d=\"M 240.429688 102.457031 C 143.015625 102.457031 64.042969 181.429688 64.042969 278.84375 C 64.042969 376.257812 143.015625 455.226562 240.429688 455.226562 C 337.84375 455.226562 416.8125 376.257812 416.8125 278.84375 C 416.8125 181.429688 337.84375 102.457031 240.429688 102.457031 Z M 240.429688 102.457031 \" clipRule=\"nonzero\"/></clipPath></defs><rect x=\"-76.8\" width=\"921.6\" fill=\"#ffffff\" y=\"-76.799999\" height=\"921.599993\" fill-opacity=\"1\"/><rect x=\"-76.8\" width=\"921.6\" fill=\"#ffffff\" y=\"-76.799999\" height=\"921.599993\" fill-opacity=\"1\"/><path fill=\"#111827\" d=\"M 490.835938 208.230469 L 490.847656 208.230469 C 510.960938 208.230469 527.328125 191.859375 527.328125 171.742188 C 527.328125 151.617188 510.949219 135.25 490.824219 135.25 C 481.082031 135.25 471.921875 139.042969 465.03125 145.933594 C 458.132812 152.828125 454.335938 161.992188 454.339844 171.738281 C 454.339844 181.476562 458.136719 190.640625 465.03125 197.539062 C 471.925781 204.433594 481.089844 208.230469 490.835938 208.230469 Z M 490.824219 149.222656 C 503.246094 149.222656 513.351562 159.328125 513.351562 171.742188 C 513.351562 184.15625 503.257812 194.257812 490.847656 194.257812 L 490.847656 201.246094 L 490.835938 194.257812 C 484.824219 194.257812 479.171875 191.910156 474.917969 187.65625 C 470.660156 183.402344 468.316406 177.746094 468.316406 171.734375 C 468.316406 165.722656 470.65625 160.070312 474.910156 155.816406 C 479.164062 151.566406 484.8125 149.222656 490.824219 149.222656 Z M 490.824219 149.222656 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><path fill=\"#111827\" d=\"M 550.871094 241.667969 L 555.816406 236.722656 C 579.28125 213.257812 588.273438 178.828125 579.289062 146.867188 L 565.835938 150.644531 C 572.820312 175.492188 566.996094 202.09375 550.648438 221.679688 L 440.890625 111.90625 C 460.46875 95.574219 487.054688 89.742188 511.878906 96.695312 L 515.648438 83.238281 C 483.710938 74.277344 449.296875 83.289062 425.84375 106.742188 L 420.902344 111.683594 Z M 550.871094 241.667969 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><g clip-path=\"url(#572969ecf2)\"><path fill=\"#111827\" d=\"M 572.625 158.699219 L 596.941406 134.378906 C 615.425781 115.375 615.1875 84.761719 596.488281 66.058594 C 587.300781 56.875 575.101562 51.820312 562.128906 51.820312 C 549.160156 51.820312 536.953125 56.875 527.773438 66.058594 L 503.867188 89.960938 Z M 562.128906 65.792969 C 571.367188 65.792969 580.0625 69.394531 586.609375 75.941406 C 599.9375 89.265625 600.105469 111.078125 586.996094 124.566406 L 572.628906 138.933594 L 523.632812 89.960938 L 537.65625 75.941406 C 544.195312 69.398438 552.886719 65.792969 562.128906 65.792969 Z M 562.128906 65.792969 \" fill-opacity=\"1\" fillRule=\"nonzero\"/></g><path fill=\"#111827\" d=\"M 481.507812 372.699219 L 471.628906 382.585938 L 485.515625 396.46875 L 495.398438 386.585938 Z M 481.507812 372.699219 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><g clip-path=\"url(#a88d1680c1)\"><path fill=\"#111827\" d=\"M 453.414062 469.535156 L 669.484375 469.535156 L 669.484375 462.546875 C 669.484375 402.980469 621.019531 354.523438 561.449219 354.523438 C 501.878906 354.523438 453.414062 402.980469 453.414062 462.546875 Z M 655.253906 455.558594 L 467.644531 455.558594 C 471.234375 406.957031 511.9375 368.5 561.445312 368.5 C 610.960938 368.5 651.664062 406.957031 655.253906 455.558594 Z M 655.253906 455.558594 \" fill-opacity=\"1\" fillRule=\"nonzero\"/></g><path fill=\"#111827\" d=\"M 578.527344 395.492188 L 582.011719 381.960938 C 575.371094 380.246094 568.449219 379.378906 561.453125 379.378906 L 561.453125 393.355469 C 567.277344 393.351562 573.019531 394.070312 578.527344 395.492188 Z M 578.527344 395.492188 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><path fill=\"#111827\" d=\"M 626.902344 439.988281 L 640.105469 435.410156 C 632.386719 413.167969 615.535156 395.144531 593.867188 385.957031 L 588.414062 398.820312 C 606.449219 406.472656 620.476562 421.472656 626.902344 439.988281 Z M 626.902344 439.988281 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><g clip-path=\"url(#b8d5c88bf8)\"><path fill=\"#111827\" d=\"M 712.292969 282.597656 C 729.949219 282.597656 744.3125 268.230469 744.3125 250.570312 C 744.3125 232.925781 729.949219 218.570312 712.292969 218.570312 C 694.644531 218.570312 680.289062 232.925781 680.289062 250.570312 C 680.289062 268.230469 694.644531 282.597656 712.292969 282.597656 Z M 712.292969 232.542969 C 722.246094 232.542969 730.339844 240.628906 730.339844 250.570312 C 730.339844 260.527344 722.246094 268.625 712.292969 268.625 C 702.351562 268.625 694.265625 260.527344 694.265625 250.570312 C 694.265625 240.628906 702.351562 232.542969 712.292969 232.542969 Z M 712.292969 232.542969 \" fill-opacity=\"1\" fillRule=\"nonzero\"/></g><path fill=\"#111827\" d=\"M 596.539062 124.902344 L 586.652344 134.785156 L 689.660156 237.847656 L 699.546875 227.964844 Z M 596.539062 124.902344 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><path fill=\"#111827\" d=\"M 689.660156 263.324219 L 590.542969 362.445312 L 600.425781 372.324219 L 699.542969 273.207031 Z M 689.660156 263.324219 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><path fill=\"#111827\" d=\"M 497.832031 222.628906 L 483.855469 222.628906 L 483.855469 245.570312 L 497.832031 245.570312 Z M 497.832031 222.628906 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><path fill=\"#111827\" d=\"M 459.359375 212.324219 L 447.890625 232.207031 L 460 239.191406 L 471.464844 219.304688 Z M 459.359375 212.324219 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><path fill=\"#111827\" d=\"M 443.277344 191.136719 L 423.410156 202.601562 L 430.398438 214.707031 L 450.261719 203.242188 Z M 443.277344 191.136719 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><path fill=\"#111827\" d=\"M 439.945312 164.753906 L 417.011719 164.753906 L 417.011719 178.726562 L 439.945312 178.726562 Z M 439.945312 164.753906 \" fill-opacity=\"1\" fillRule=\"nonzero\"/><g clip-path=\"url(#c0165df3b9)\"><g clip-path=\"url(#8fed9601f6)\"><path fill=\"#0099cc\" d=\"M 64.042969 102.457031 L 416.8125 102.457031 L 416.8125 455.226562 L 64.042969 455.226562 Z M 64.042969 102.457031 \" fill-opacity=\"1\" fillRule=\"nonzero\"/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(740.773454, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(743.248438, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(745.723421, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(748.198404, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(750.673387, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(753.148371, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(755.623354, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(758.098337, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(760.573321, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(763.048304, 764.899991)\"><g/></g></g><g fill=\"#000000\" fill-opacity=\"1\"><g transform=\"translate(765.523287, 764.899991)\"><g/></g></g><g fill=\"#111827\" fill-opacity=\"1\"><g transform=\"translate(51.813902, 656.119218)\"><g><path d=\"M 50.5 -24.453125 C 56.738281 -24.453125 61.148438 -25.0625 63.734375 -26.28125 C 66.328125 -27.5 67.625 -29.859375 67.625 -33.359375 C 67.625 -36.097656 65.945312 -38.492188 62.59375 -40.546875 C 59.25 -42.609375 54.148438 -44.9375 47.296875 -47.53125 C 41.960938 -49.507812 37.125 -51.5625 32.78125 -53.6875 C 28.445312 -55.820312 24.753906 -58.375 21.703125 -61.34375 C 18.660156 -64.3125 16.300781 -67.851562 14.625 -71.96875 C 12.945312 -76.082031 12.109375 -81.035156 12.109375 -86.828125 C 12.109375 -98.097656 16.296875 -107.003906 24.671875 -113.546875 C 33.054688 -120.097656 44.554688 -123.375 59.171875 -123.375 C 66.484375 -123.375 73.488281 -122.726562 80.1875 -121.4375 C 86.894531 -120.144531 92.226562 -118.738281 96.1875 -117.21875 L 90.25 -90.703125 C 86.289062 -92.078125 81.988281 -93.296875 77.34375 -94.359375 C 72.695312 -95.429688 67.476562 -95.96875 61.6875 -95.96875 C 51.03125 -95.96875 45.703125 -92.992188 45.703125 -87.046875 C 45.703125 -85.679688 45.925781 -84.460938 46.375 -83.390625 C 46.832031 -82.328125 47.75 -81.300781 49.125 -80.3125 C 50.5 -79.320312 52.363281 -78.253906 54.71875 -77.109375 C 57.082031 -75.972656 60.09375 -74.71875 63.75 -73.34375 C 71.207031 -70.601562 77.375 -67.898438 82.25 -65.234375 C 87.125 -62.566406 90.96875 -59.671875 93.78125 -56.546875 C 96.601562 -53.421875 98.585938 -49.953125 99.734375 -46.140625 C 100.878906 -42.335938 101.453125 -37.925781 101.453125 -32.90625 C 101.453125 -21.019531 96.992188 -12.03125 88.078125 -5.9375 C 79.171875 0.15625 66.566406 3.203125 50.265625 3.203125 C 39.597656 3.203125 30.722656 2.285156 23.640625 0.453125 C 16.566406 -1.367188 11.65625 -2.890625 8.90625 -4.109375 L 14.625 -31.765625 C 20.414062 -29.472656 26.351562 -27.679688 32.4375 -26.390625 C 38.53125 -25.097656 44.550781 -24.453125 50.5 -24.453125 Z M 50.5 -24.453125 \"/></g></g></g><g fill=\"#111827\" fill-opacity=\"1\"><g transform=\"translate(154.862681, 656.119218)\"><g><path d=\"M 14.84375 -150.109375 L 48.890625 -155.59375 L 48.890625 -120.1875 L 89.796875 -120.1875 L 89.796875 -91.84375 L 48.890625 -91.84375 L 48.890625 -49.578125 C 48.890625 -42.421875 50.144531 -36.707031 52.65625 -32.4375 C 55.175781 -28.175781 60.242188 -26.046875 67.859375 -26.046875 C 71.515625 -26.046875 75.285156 -26.390625 79.171875 -27.078125 C 83.054688 -27.765625 86.597656 -28.71875 89.796875 -29.9375 L 94.59375 -3.421875 C 90.476562 -1.742188 85.90625 -0.300781 80.875 0.90625 C 75.851562 2.125 69.6875 2.734375 62.375 2.734375 C 53.082031 2.734375 45.390625 1.476562 39.296875 -1.03125 C 33.203125 -3.539062 28.328125 -7.039062 24.671875 -11.53125 C 21.015625 -16.03125 18.460938 -21.476562 17.015625 -27.875 C 15.566406 -34.269531 14.84375 -41.351562 14.84375 -49.125 Z M 14.84375 -150.109375 \"/></g></g></g><g fill=\"#111827\" fill-opacity=\"1\"><g transform=\"translate(248.543405, 656.119218)\"><g><path d=\"M 118.578125 -4.109375 C 112.796875 -2.429688 105.332031 -0.875 96.1875 0.5625 C 87.050781 2.007812 77.457031 2.734375 67.40625 2.734375 C 57.195312 2.734375 48.703125 1.363281 41.921875 -1.375 C 35.148438 -4.113281 29.78125 -7.957031 25.8125 -12.90625 C 21.851562 -17.851562 19.035156 -23.753906 17.359375 -30.609375 C 15.679688 -37.472656 14.84375 -45.015625 14.84375 -53.234375 L 14.84375 -120.1875 L 48.890625 -120.1875 L 48.890625 -57.34375 C 48.890625 -46.382812 50.335938 -38.46875 53.234375 -33.59375 C 56.128906 -28.71875 61.535156 -26.28125 69.453125 -26.28125 C 71.890625 -26.28125 74.476562 -26.394531 77.21875 -26.625 C 79.96875 -26.851562 82.410156 -27.117188 84.546875 -27.421875 L 84.546875 -120.1875 L 118.578125 -120.1875 Z M 118.578125 -4.109375 \"/></g></g></g><g fill=\"#111827\" fill-opacity=\"1\"><g transform=\"translate(375.355117, 656.119218)\"><g><path d=\"M 45.015625 -61 C 45.015625 -50.488281 47.375 -42.035156 52.09375 -35.640625 C 56.8125 -29.242188 63.816406 -26.046875 73.109375 -26.046875 C 76.160156 -26.046875 78.976562 -26.160156 81.5625 -26.390625 C 84.15625 -26.617188 86.289062 -26.882812 87.96875 -27.1875 L 87.96875 -89.109375 C 85.832031 -90.484375 83.050781 -91.625 79.625 -92.53125 C 76.195312 -93.445312 72.734375 -93.90625 69.234375 -93.90625 C 53.085938 -93.90625 45.015625 -82.9375 45.015625 -61 Z M 122.015625 -3.890625 C 118.960938 -2.972656 115.457031 -2.09375 111.5 -1.25 C 107.539062 -0.414062 103.390625 0.300781 99.046875 0.90625 C 94.703125 1.519531 90.285156 2.015625 85.796875 2.390625 C 81.304688 2.773438 77.003906 2.96875 72.890625 2.96875 C 62.984375 2.96875 54.144531 1.519531 46.375 -1.375 C 38.613281 -4.269531 32.066406 -8.421875 26.734375 -13.828125 C 21.398438 -19.234375 17.320312 -25.78125 14.5 -33.46875 C 11.6875 -41.164062 10.28125 -49.8125 10.28125 -59.40625 C 10.28125 -69.15625 11.5 -77.953125 13.9375 -85.796875 C 16.375 -93.640625 19.875 -100.300781 24.4375 -105.78125 C 29.007812 -111.269531 34.609375 -115.460938 41.234375 -118.359375 C 47.867188 -121.253906 55.445312 -122.703125 63.96875 -122.703125 C 68.695312 -122.703125 72.925781 -122.242188 76.65625 -121.328125 C 80.382812 -120.410156 84.15625 -119.113281 87.96875 -117.4375 L 87.96875 -171.8125 L 122.015625 -177.296875 Z M 122.015625 -3.890625 \"/></g></g></g><g fill=\"#111827\" fill-opacity=\"1\"><g transform=\"translate(505.594175, 656.119218)\"><g><path d=\"M 50.03125 0 L 16 0 L 16 -120.1875 L 50.03125 -120.1875 Z M 53.234375 -154.90625 C 53.234375 -148.664062 51.210938 -143.753906 47.171875 -140.171875 C 43.140625 -136.597656 38.382812 -134.8125 32.90625 -134.8125 C 27.414062 -134.8125 22.648438 -136.597656 18.609375 -140.171875 C 14.578125 -143.753906 12.5625 -148.664062 12.5625 -154.90625 C 12.5625 -161.15625 14.578125 -166.066406 18.609375 -169.640625 C 22.648438 -173.222656 27.414062 -175.015625 32.90625 -175.015625 C 38.382812 -175.015625 43.140625 -173.222656 47.171875 -169.640625 C 51.210938 -166.066406 53.234375 -161.15625 53.234375 -154.90625 Z M 53.234375 -154.90625 \"/></g></g></g><g fill=\"#111827\" fill-opacity=\"1\"><g transform=\"translate(563.859027, 656.119218)\"><g><path d=\"M 128.40625 -60.3125 C 128.40625 -50.875 127.035156 -42.234375 124.296875 -34.390625 C 121.554688 -26.546875 117.59375 -19.84375 112.40625 -14.28125 C 107.226562 -8.71875 101.019531 -4.410156 93.78125 -1.359375 C 86.550781 1.679688 78.441406 3.203125 69.453125 3.203125 C 60.617188 3.203125 52.582031 1.679688 45.34375 -1.359375 C 38.113281 -4.410156 31.910156 -8.71875 26.734375 -14.28125 C 21.554688 -19.84375 17.519531 -26.546875 14.625 -34.390625 C 11.726562 -42.234375 10.28125 -50.875 10.28125 -60.3125 C 10.28125 -69.757812 11.765625 -78.367188 14.734375 -86.140625 C 17.703125 -93.910156 21.8125 -100.535156 27.0625 -106.015625 C 32.320312 -111.503906 38.570312 -115.769531 45.8125 -118.8125 C 53.050781 -121.851562 60.929688 -123.375 69.453125 -123.375 C 78.140625 -123.375 86.097656 -121.851562 93.328125 -118.8125 C 100.566406 -115.769531 106.773438 -111.503906 111.953125 -106.015625 C 117.128906 -100.535156 121.164062 -93.910156 124.0625 -86.140625 C 126.957031 -78.367188 128.40625 -69.757812 128.40625 -60.3125 Z M 93.671875 -60.3125 C 93.671875 -70.820312 91.578125 -79.085938 87.390625 -85.109375 C 83.203125 -91.128906 77.222656 -94.140625 69.453125 -94.140625 C 61.691406 -94.140625 55.675781 -91.128906 51.40625 -85.109375 C 47.144531 -79.085938 45.015625 -70.820312 45.015625 -60.3125 C 45.015625 -49.800781 47.144531 -41.460938 51.40625 -35.296875 C 55.675781 -29.128906 61.691406 -26.046875 69.453125 -26.046875 C 77.222656 -26.046875 83.203125 -29.128906 87.390625 -35.296875 C 91.578125 -41.460938 93.671875 -49.800781 93.671875 -60.3125 Z M 93.671875 -60.3125 \"/></g></g></g><g fill=\"#ffffff\" fill-opacity=\"1\"><g transform=\"translate(75.641889, 317.889069)\"><g><path d=\"M 48.453125 -37.65625 C 48.453125 -44.132812 47.617188 -48.722656 45.953125 -51.421875 C 44.285156 -54.117188 41.425781 -55.46875 37.375 -55.46875 C 36.125 -55.46875 34.820312 -55.398438 33.46875 -55.265625 C 32.113281 -55.128906 30.8125 -54.972656 29.5625 -54.796875 L 29.5625 0 L 9.453125 0 L 9.453125 -68.5625 C 11.160156 -69.007812 13.160156 -69.476562 15.453125 -69.96875 C 17.742188 -70.46875 20.171875 -70.921875 22.734375 -71.328125 C 25.296875 -71.734375 27.925781 -72.046875 30.625 -72.265625 C 33.332031 -72.492188 35.988281 -72.609375 38.59375 -72.609375 C 43.71875 -72.609375 47.878906 -71.953125 51.078125 -70.640625 C 54.273438 -69.335938 56.90625 -67.785156 58.96875 -65.984375 C 61.851562 -68.054688 65.160156 -69.675781 68.890625 -70.84375 C 72.628906 -72.019531 76.070312 -72.609375 79.21875 -72.609375 C 84.882812 -72.609375 89.539062 -71.816406 93.1875 -70.234375 C 96.832031 -68.660156 99.734375 -66.4375 101.890625 -63.5625 C 104.046875 -60.6875 105.53125 -57.269531 106.34375 -53.3125 C 107.15625 -49.351562 107.5625 -44.941406 107.5625 -40.078125 L 107.5625 0 L 87.453125 0 L 87.453125 -37.65625 C 87.453125 -44.132812 86.617188 -48.722656 84.953125 -51.421875 C 83.285156 -54.117188 80.429688 -55.46875 76.390625 -55.46875 C 75.304688 -55.46875 73.796875 -55.195312 71.859375 -54.65625 C 69.929688 -54.113281 68.335938 -53.4375 67.078125 -52.625 C 67.703125 -50.5625 68.101562 -48.378906 68.28125 -46.078125 C 68.46875 -43.785156 68.5625 -41.335938 68.5625 -38.734375 L 68.5625 0 L 48.453125 0 Z M 48.453125 -37.65625 \"/></g></g></g><g fill=\"#ffffff\" fill-opacity=\"1\"><g transform=\"translate(191.970234, 317.889069)\"><g><path d=\"M 37.78125 1.34375 C 31.9375 1.257812 27.191406 0.632812 23.546875 -0.53125 C 19.898438 -1.707031 17.019531 -3.351562 14.90625 -5.46875 C 12.789062 -7.582031 11.351562 -10.144531 10.59375 -13.15625 C 9.832031 -16.164062 9.453125 -19.5625 9.453125 -23.34375 L 9.453125 -101.484375 L 29.5625 -104.71875 L 29.5625 -27.390625 C 29.5625 -25.597656 29.691406 -23.976562 29.953125 -22.53125 C 30.222656 -21.09375 30.738281 -19.878906 31.5 -18.890625 C 32.269531 -17.898438 33.375 -17.085938 34.8125 -16.453125 C 36.257812 -15.828125 38.195312 -15.425781 40.625 -15.25 Z M 37.78125 1.34375 \"/></g></g></g><g fill=\"#ffffff\" fill-opacity=\"1\"><g transform=\"translate(234.614962, 317.889069)\"><g><path d=\"M 2.828125 24.96875 C 1.566406 24.96875 -0.296875 24.832031 -2.765625 24.5625 C -5.242188 24.289062 -7.5625 23.796875 -9.71875 23.078125 L -7.015625 6.75 C -5.671875 7.195312 -4.4375 7.507812 -3.3125 7.6875 C -2.1875 7.875 -0.769531 7.96875 0.9375 7.96875 C 4.09375 7.96875 6.300781 7.019531 7.5625 5.125 C 8.820312 3.238281 9.453125 0.492188 9.453125 -3.109375 L 9.453125 -70.984375 L 29.5625 -70.984375 L 29.5625 -2.5625 C 29.5625 6.789062 27.265625 13.71875 22.671875 18.21875 C 18.085938 22.71875 11.472656 24.96875 2.828125 24.96875 Z M 31.4375 -91.5 C 31.4375 -87.8125 30.242188 -84.910156 27.859375 -82.796875 C 25.484375 -80.679688 22.675781 -79.625 19.4375 -79.625 C 16.195312 -79.625 13.382812 -80.679688 11 -82.796875 C 8.613281 -84.910156 7.421875 -87.8125 7.421875 -91.5 C 7.421875 -95.1875 8.613281 -98.085938 11 -100.203125 C 13.382812 -102.316406 16.195312 -103.375 19.4375 -103.375 C 22.675781 -103.375 25.484375 -102.316406 27.859375 -100.203125 C 30.242188 -98.085938 31.4375 -95.1875 31.4375 -91.5 Z M 31.4375 -91.5 \"/></g></g></g><g fill=\"#ffffff\" fill-opacity=\"1\"><g transform=\"translate(273.615995, 317.889069)\"><g><path d=\"M 36.578125 -14.03125 C 38.554688 -14.03125 40.441406 -14.078125 42.234375 -14.171875 C 44.035156 -14.265625 45.476562 -14.398438 46.5625 -14.578125 L 46.5625 -29.828125 C 45.75 -30.003906 44.53125 -30.179688 42.90625 -30.359375 C 41.289062 -30.546875 39.8125 -30.640625 38.46875 -30.640625 C 36.570312 -30.640625 34.789062 -30.523438 33.125 -30.296875 C 31.46875 -30.066406 30.007812 -29.632812 28.75 -29 C 27.488281 -28.375 26.5 -27.519531 25.78125 -26.4375 C 25.0625 -25.363281 24.703125 -24.019531 24.703125 -22.40625 C 24.703125 -19.25 25.757812 -17.0625 27.875 -15.84375 C 29.988281 -14.632812 32.890625 -14.03125 36.578125 -14.03125 Z M 34.953125 -72.875 C 40.890625 -72.875 45.835938 -72.195312 49.796875 -70.84375 C 53.753906 -69.5 56.925781 -67.566406 59.3125 -65.046875 C 61.695312 -62.523438 63.382812 -59.460938 64.375 -55.859375 C 65.363281 -52.265625 65.859375 -48.265625 65.859375 -43.859375 L 65.859375 -2.03125 C 62.972656 -1.394531 58.96875 -0.648438 53.84375 0.203125 C 48.71875 1.054688 42.507812 1.484375 35.21875 1.484375 C 30.632812 1.484375 26.472656 1.078125 22.734375 0.265625 C 19.003906 -0.535156 15.789062 -1.859375 13.09375 -3.703125 C 10.394531 -5.554688 8.320312 -7.96875 6.875 -10.9375 C 5.4375 -13.90625 4.71875 -17.546875 4.71875 -21.859375 C 4.71875 -25.992188 5.550781 -29.5 7.21875 -32.375 C 8.882812 -35.257812 11.109375 -37.554688 13.890625 -39.265625 C 16.679688 -40.972656 19.875 -42.207031 23.46875 -42.96875 C 27.070312 -43.738281 30.8125 -44.125 34.6875 -44.125 C 37.289062 -44.125 39.601562 -44.007812 41.625 -43.78125 C 43.65625 -43.5625 45.300781 -43.273438 46.5625 -42.921875 L 46.5625 -44.796875 C 46.5625 -48.222656 45.523438 -50.96875 43.453125 -53.03125 C 41.378906 -55.101562 37.78125 -56.140625 32.65625 -56.140625 C 29.238281 -56.140625 25.863281 -55.890625 22.53125 -55.390625 C 19.207031 -54.898438 16.332031 -54.207031 13.90625 -53.3125 L 11.34375 -69.5 C 12.507812 -69.863281 13.96875 -70.242188 15.71875 -70.640625 C 17.476562 -71.046875 19.390625 -71.40625 21.453125 -71.71875 C 23.523438 -72.039062 25.707031 -72.3125 28 -72.53125 C 30.289062 -72.757812 32.609375 -72.875 34.953125 -72.875 Z M 34.953125 -72.875 \"/></g></g></g><g fill=\"#ffffff\" fill-opacity=\"1\"><g transform=\"translate(348.244274, 317.889069)\"><g><path d=\"M 52.234375 -53.171875 C 50.429688 -53.617188 48.3125 -54.085938 45.875 -54.578125 C 43.445312 -55.078125 40.84375 -55.328125 38.0625 -55.328125 C 36.800781 -55.328125 35.289062 -55.210938 33.53125 -54.984375 C 31.78125 -54.765625 30.457031 -54.519531 29.5625 -54.25 L 29.5625 0 L 9.453125 0 L 9.453125 -67.203125 C 13.046875 -68.460938 17.296875 -69.65625 22.203125 -70.78125 C 27.109375 -71.90625 32.570312 -72.46875 38.59375 -72.46875 C 39.675781 -72.46875 40.976562 -72.398438 42.5 -72.265625 C 44.03125 -72.128906 45.5625 -71.945312 47.09375 -71.71875 C 48.625 -71.5 50.15625 -71.234375 51.6875 -70.921875 C 53.21875 -70.609375 54.519531 -70.222656 55.59375 -69.765625 Z M 52.234375 -53.171875 \"/></g></g></g></svg>";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.2d223358a25a449c253e.js.map