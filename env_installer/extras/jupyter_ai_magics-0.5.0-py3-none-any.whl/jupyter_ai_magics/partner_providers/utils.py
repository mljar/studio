
MLJAR_ADDRESS = "https://licenses.mljar.com"
MLJAR_COMPLETION_API = f"{MLJAR_ADDRESS}/api/completion/"

MLJAR_AUTH_KEY = "MLJAR_AUTH_KEY"
