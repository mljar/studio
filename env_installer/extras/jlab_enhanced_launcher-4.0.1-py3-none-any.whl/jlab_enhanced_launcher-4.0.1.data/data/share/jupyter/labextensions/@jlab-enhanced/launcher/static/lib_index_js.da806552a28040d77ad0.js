"use strict";
(self["webpackChunk_jlab_enhanced_launcher"] = self["webpackChunk_jlab_enhanced_launcher"] || []).push([["lib_index_js"],{

/***/ "./lib/ChatButton.js":
/*!***************************!*\
  !*** ./lib/ChatButton.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatButtonWidget: () => (/* binding */ ChatButtonWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


class ChatButtonWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(props) {
        super();
        this.props = props;
        this.update();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: { paddingTop: '10px', paddingBottom: '10px' } },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { className: "mljarAskAIButton", onClick: () => {
                    this.props.stateDB.save('promptToAI', this.props.prompt);
                    this.props.commands.execute('ai-data-scientist:focus-chat-input');
                } },
                "Ask AI: ",
                this.props.prompt)));
    }
}


/***/ }),

/***/ "./lib/PoCButton.js":
/*!**************************!*\
  !*** ./lib/PoCButton.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PoCButtonWidget: () => (/* binding */ PoCButtonWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


class PoCButtonWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(props) {
        super();
        this.props = props;
        this.update();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: { paddingTop: '10px', paddingBottom: '10px' } },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { className: "mljarPoCButton", onClick: () => {
                    this.props.commands.execute('mljar-piece-of-code:focus', {
                        recipeSet: this.props.recipeSet,
                        recipe: this.props.recipe
                    });
                } },
                "Piece of Code: ",
                this.props.buttonLabel)));
    }
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/statedb */ "webpack/sharing/consume/default/@jupyterlab/statedb");
/* harmony import */ var _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @jupyterlab/rendermime */ "webpack/sharing/consume/default/@jupyterlab/rendermime");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _launcher__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./launcher */ "./lib/launcher.js");
/* harmony import */ var _ChatButton__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ChatButton */ "./lib/ChatButton.js");
/* harmony import */ var _starters__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./starters */ "./lib/starters.js");
/* harmony import */ var _PoCButton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./PoCButton */ "./lib/PoCButton.js");
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.














class CustomTextRenderer extends _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__.RenderedText {
    constructor(options, stateDB, commands) {
        super(options);
        this._stateDB = stateDB;
        this._commands = commands;
    }
    async renderModel(model) {
        await super.renderModel(model);
        const txt = (model.data['text/plain'] ||
            model.data['application/vnd.jupyter.stdout']);
        const matchAI = txt.match(/Ask AI:\s*(.*)/);
        if (matchAI) {
            const valueAfter = matchAI[1];
            const helperButton = new _ChatButton__WEBPACK_IMPORTED_MODULE_10__.ChatButtonWidget({
                prompt: valueAfter,
                stateDB: this._stateDB,
                commands: this._commands
            });
            this.node.appendChild(helperButton.node);
        }
        if (txt.includes('🍰 Recipe:')) {
            const matchPoC = txt.match(/Recipe:\s*(.*)/);
            const valueAfter = matchPoC[1];
            let recipeSet = '';
            let recipe = '';
            let buttonLabel = '';
            if (valueAfter.includes('Load sample dataset')) {
                recipeSet = 'Read data';
                recipe = 'Sample datasets';
                buttonLabel = 'Load sample dataset';
            }
            if (valueAfter.includes('Exploratory data')) {
                recipeSet = 'Explore data';
                recipe = 'Skrub';
                buttonLabel = 'Exploratory data analysis';
            }
            const helperButton = new _PoCButton__WEBPACK_IMPORTED_MODULE_11__.PoCButtonWidget({
                recipeSet,
                recipe,
                buttonLabel,
                commands: this._commands
            });
            this.node.appendChild(helperButton.node);
        }
    }
}
/**
 * The command IDs used by the launcher plugin.
 */
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.create = 'launcher:create';
})(CommandIDs || (CommandIDs = {}));
/**
 * A service providing an interface to the the launcher.
 */
const plugin = {
    activate,
    id: _launcher__WEBPACK_IMPORTED_MODULE_12__.EXTENSION_ID,
    requires: [_jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5__.IStateDB, _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__.IRenderMimeRegistry],
    optional: [
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILabShell,
        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette,
        _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__.IDefaultFileBrowser,
        _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_4__.ISettingRegistry,
        _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5__.IStateDB
    ],
    provides: _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_3__.ILauncher,
    autoStart: true
};
/**
 * Export the plugin as default.
 */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);
/**
 * Activate the launcher.
 */
async function activate(app, stateDB, rmRegistry, labShell, palette, defaultBrowser, settingRegistry, state) {
    const { commands, shell, serviceManager } = app;
    let settings = null;
    if (settingRegistry) {
        try {
            settings = await settingRegistry.load(_launcher__WEBPACK_IMPORTED_MODULE_12__.EXTENSION_ID);
        }
        catch (reason) {
            console.log(`Failed to load settings for ${_launcher__WEBPACK_IMPORTED_MODULE_12__.EXTENSION_ID}.`, reason);
        }
    }
    const templateRendererFactory = {
        safe: true,
        mimeTypes: ['text/plain', 'application/vnd.jupyter.stdout'],
        defaultRank: 1000,
        createRenderer: options => {
            return new CustomTextRenderer(options, stateDB, commands);
        }
    };
    rmRegistry.addFactory(templateRendererFactory, 1000);
    const model = new _launcher__WEBPACK_IMPORTED_MODULE_12__.LauncherModel(settings, state);
    if (state) {
        Promise.all([
            state.fetch(`${_launcher__WEBPACK_IMPORTED_MODULE_12__.EXTENSION_ID}:usageData`),
            state.fetch(`${_launcher__WEBPACK_IMPORTED_MODULE_12__.EXTENSION_ID}:viewMode`),
            app.restored
        ])
            .then(([usage, mode]) => {
            model.viewMode = mode || 'cards';
            for (const key in usage) {
                model.usage[key] = usage[key];
            }
        })
            .catch(reason => {
            console.error('Fail to restore launcher usage data', reason);
        });
    }
    const commandID = 'launcher:create-hello-notebook';
    commands.addCommand(commandID, {
        label: 'New Hello Notebook',
        caption: 'Create a notebook with a Markdown cell and a hello world code cell',
        execute: async (args) => {
            // 1. Create a blank notebook on disk
            const untitled = await serviceManager.contents.newUntitled({
                type: 'notebook'
            });
            // 2. Open it in the UI
            const panel = (await commands.execute('docmanager:open', {
                path: untitled.path,
                factory: 'Notebook',
                kernel: { name: 'python3' },
                activate: true
            }));
            await panel.context.ready;
            // 3. Grab the model (cast to the concrete class so TS knows about fromJSON/toJSON)
            const model = panel.context.model;
            const base = model.toJSON();
            // 4. Compose a new JSON payload with exactly two cells
            const newNb = {
                ...base,
                cells: _starters__WEBPACK_IMPORTED_MODULE_13__.loadSampleData
            };
            // 5. Overwrite the model’s contents and save
            model.fromJSON(newNb);
            await panel.context.save();
            await commands.execute('notebook:hide-all-cell-code');
            // 6. Show it
            app.shell.activateById(panel.id);
            await panel.sessionContext.ready;
            await _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__.NotebookActions.runAll(panel.content, panel.sessionContext);
        }
    });
    commands.addCommand(CommandIDs.create, {
        label: 'New Launcher',
        icon: args => (args.toolbar ? _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__.addIcon : undefined),
        execute: (args) => {
            var _a, _b;
            const cwd = (_b = (_a = args['cwd']) !== null && _a !== void 0 ? _a : defaultBrowser === null || defaultBrowser === void 0 ? void 0 : defaultBrowser.model.path) !== null && _b !== void 0 ? _b : '';
            const id = `launcher-${Private.id++}`;
            const callback = (item) => {
                // If widget is attached to the main area replace the launcher
                if ((0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_9__.find)(shell.widgets('main'), w => w === item)) {
                    shell.add(item, 'main', { ref: id });
                    launcher.dispose();
                }
            };
            const launcher = new _launcher__WEBPACK_IMPORTED_MODULE_12__.Launcher({
                model,
                cwd,
                callback,
                commands
            });
            launcher.model = model;
            launcher.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__.launcherIcon;
            launcher.title.label = 'Get started';
            launcher.stateDB = stateDB;
            const main = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content: launcher });
            // If there are any other widgets open, remove the launcher close icon.
            main.title.closable = !!Array.from(shell.widgets('main')).length;
            main.id = id;
            shell.add(main, 'main', {
                activate: args['activate'],
                ref: args['ref']
            });
            if (labShell) {
                labShell.layoutModified.connect(() => {
                    // If there is only a launcher open, remove the close icon.
                    main.title.closable = Array.from(labShell.widgets('main')).length > 1;
                }, main);
            }
            if (defaultBrowser) {
                const onPathChanged = (model) => {
                    launcher.cwd = model.path;
                };
                defaultBrowser.model.pathChanged.connect(onPathChanged);
                launcher.disposed.connect(() => {
                    defaultBrowser.model.pathChanged.disconnect(onPathChanged);
                });
            }
            return main;
        }
    });
    if (labShell) {
        void Promise.all([app.restored, defaultBrowser === null || defaultBrowser === void 0 ? void 0 : defaultBrowser.model.restored]).then(() => {
            function maybeCreate() {
                // Create a launcher if there are no open items.
                if (labShell.isEmpty('main')) {
                    void commands.execute(CommandIDs.create);
                }
            }
            // When layout is modified, create a launcher if there are no open items.
            labShell.layoutModified.connect(() => {
                maybeCreate();
            });
        });
    }
    if (palette) {
        palette.addItem({
            command: CommandIDs.create,
            category: 'Launcher'
        });
    }
    if (labShell) {
        labShell.addButtonEnabled = true;
        labShell.addRequested.connect((sender, arg) => {
            var _a;
            // Get the ref for the current tab of the tabbar which the add button was clicked
            const ref = ((_a = arg.currentTitle) === null || _a === void 0 ? void 0 : _a.owner.id) ||
                arg.titles[arg.titles.length - 1].owner.id;
            return commands.execute(CommandIDs.create, { ref });
        });
    }
    return model;
}
/**
 * The namespace for module private data.
 */
var Private;
(function (Private) {
    /**
     * The incrementing id used for launcher widgets.
     */
    // eslint-disable-next-line prefer-const
    Private.id = 0;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/launcher.js":
/*!*************************!*\
  !*** ./lib/launcher.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EXTENSION_ID: () => (/* binding */ EXTENSION_ID),
/* harmony export */   Launcher: () => (/* binding */ Launcher),
/* harmony export */   LauncherModel: () => (/* binding */ LauncherModel)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_properties__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/properties */ "webpack/sharing/consume/default/@lumino/properties");
/* harmony import */ var _lumino_properties__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_properties__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* eslint-disable no-inner-declarations */
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.







// import { mostUsedIcon } from './icons';
/**
 * Extension identifier
 */
const EXTENSION_ID = '@jlab-enhanced/launcher:plugin';
/**
 * The class name added to Launcher instances.
 */
const LAUNCHER_CLASS = 'jp-NewLauncher';
/**
 * LauncherModel keeps track of the path to working directory and has a list of
 * LauncherItems, which the Launcher will render.
 */
class LauncherModel extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.VDomModel {
    constructor(settings, state) {
        super();
        this._items = [];
        this._settings = null;
        this._state = null;
        this._usageData = {};
        this._viewMode = 'cards';
        this._showMore = false;
        this._prompt = '';
        this._settings = settings || null;
        this._state = state || null;
        this.dispose();
    }
    /**
     * Generate an unique identifier for a launcher item
     *
     * @param item Launcher item
     */
    static getItemUID(item) {
        return `${item.command}${JSON.stringify(item.args || {})}`;
    }
    /**
     * The known categories of launcher items and their default ordering.
     */
    get categories() {
        return ['Other', 'Kernels'];
        // if (this._settings) {
        //   return this._settings.composite['categories'] as string[];
        // } else {
        //   return ['Other', 'Kernels'];
        // }
    }
    /**
     * The maximum number of cards showed in recent section
     */
    get nRecentCards() {
        if (this._settings) {
            return this._settings.composite['nRecentCards'];
        }
        else {
            return 4;
        }
    }
    /**
     * Time (in milliseconds) after which the usage is considered to old
     */
    get maxUsageAge() {
        let age = 30;
        if (this._settings) {
            age = this._settings.composite['maxUsageAge'];
        }
        return age * 24 * 3600 * 1000;
    }
    /**
     * Card usage data
     */
    get usage() {
        return this._usageData;
    }
    /**
     * Launcher view mode
     */
    get viewMode() {
        return this._viewMode;
    }
    set viewMode(mode) {
        const hasChanged = this._viewMode !== mode;
        this._viewMode = mode;
        if (this._state && hasChanged) {
            this._state.save(`${EXTENSION_ID}:viewMode`, mode).catch(reason => {
                console.error('Fail to save view mode', reason);
            });
        }
    }
    /**
     * Launcher show more
     */
    get showMore() {
        return this._showMore;
    }
    set showMore(show) {
        this._showMore = show;
    }
    /**
     * Launcher prompt
     */
    get prompt() {
        return this._prompt;
    }
    set prompt(p) {
        this._prompt = p;
    }
    /**
     * Add a command item to the launcher, and trigger re-render event for parent
     * widget.
     *
     * @param options - The specification options for a launcher item.
     *
     * @returns A disposable that will remove the item from Launcher, and trigger
     * re-render event for parent widget.
     *
     */
    add(options) {
        // Create a copy of the options to circumvent mutations to the original.
        const item = Private.createItem(options);
        this._items.push(item);
        this.stateChanged.emit(void 0);
        return new _lumino_disposable__WEBPACK_IMPORTED_MODULE_3__.DisposableDelegate(() => {
            _lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.ArrayExt.removeFirstOf(this._items, item);
            this.stateChanged.emit(void 0);
        });
    }
    /**
     * Return an iterator of copied launcher items.
     */
    items() {
        return this._items
            .map(item => {
            const key = LauncherModel.getItemUID(item);
            const usage = this._usageData[key] || { count: 0, mostRecent: 0 };
            return { ...item, ...usage };
        })[Symbol.iterator]();
    }
    /**
     * Handle card usage data when used.
     *
     * @param item Launcher item
     */
    useCard(item) {
        const id = LauncherModel.getItemUID(item);
        const usage = this._usageData[id];
        const now = Date.now();
        let currentCount = 0;
        if (usage && now - usage.mostRecent < this.maxUsageAge) {
            currentCount = usage.count;
        }
        this._usageData[id] = {
            count: currentCount + 1,
            mostRecent: now
        };
        if (this._state) {
            this._state
                .save(`${EXTENSION_ID}:usageData`, this._usageData)
                .catch((reason) => {
                console.error(`Failed to save ${EXTENSION_ID}:usageData - ${reason.message}`, reason);
            });
        }
    }
}
/**
 * A virtual-DOM-based widget for the Launcher.
 */
class Launcher extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.VDomRenderer {
    /**
     * Construct a new launcher widget.
     */
    constructor(options) {
        super(options.model);
        this._cwd = '';
        this._pending = false;
        this._searchInput = '';
        this._cwd = options.cwd;
        this._callback = options.callback;
        this._commands = options.commands;
        this.addClass(LAUNCHER_CLASS);
    }
    set stateDB(db) {
        this._stateDB = db;
        this.update();
    }
    /**
     * The cwd of the launcher.
     */
    get cwd() {
        return this._cwd;
    }
    set cwd(value) {
        this._cwd = value;
        this.update();
    }
    /**
     * Whether there is a pending item being launched.
     */
    get pending() {
        return this._pending;
    }
    set pending(value) {
        this._pending = value;
    }
    /**
     * Render the launcher to virtual DOM nodes.
     */
    render() {
        // Bail if there is no model.
        if (!this.model) {
            return null;
        }
        const mode = this.model.viewMode === 'cards' ? '' : '-Table';
        // First group-by categories
        const categories = Object.create(null);
        const itemsArray = [...this.model.items()];
        itemsArray.forEach((item) => {
            const cat = item.category || 'Other';
            if (!(cat in categories)) {
                categories[cat] = [];
            }
            categories[cat].push([item]);
        });
        // Merge kernel items
        const notebooks = categories['Notebook'];
        if (notebooks) {
            delete categories['Notebook'];
        }
        const consoles = categories['Console'];
        if (consoles) {
            delete categories['Console'];
        }
        const kernels = notebooks;
        consoles.forEach(console_ => {
            const consoleName = (console_[0].args['kernelPreference'] &&
                console_[0].args['kernelPreference']['name']) ||
                '';
            const consoleLabel = this._commands.label(console_[0].command, console_[0].args);
            const kernel = kernels.find(kernel => {
                // kernel comes from notebook
                const kernelName = kernel[0].args['kernelName'] || '';
                const kernelLabel = this._commands.label(kernel[0].command, kernel[0].args);
                return kernelLabel === consoleLabel && kernelName === consoleName;
            });
            if (kernel) {
                kernel.push(console_[0]);
            }
            else {
                kernels.push(console_);
            }
        });
        categories['Kernels'] = kernels;
        // Within each category sort by rank
        for (const cat in categories) {
            categories[cat] = categories[cat].sort((a, b) => {
                return Private.sortCmp(a[0], b[0], this._cwd, this._commands);
            });
        }
        // Variable to help create sections
        const sections = [];
        // Assemble the final ordered list of categories, beginning with
        // model.categories.
        const orderedCategories = [];
        this.model.categories.forEach(cat => {
            if (cat in categories) {
                orderedCategories.push(cat);
            }
        });
        for (const cat in categories) {
            if (this.model.categories.indexOf(cat) === -1) {
                orderedCategories.push(cat);
            }
        }
        /*const mostUsedItems = Array.from(this.model.items()).sort(
          (a: INewLauncher.IItemOptions, b: INewLauncher.IItemOptions) => {
            return Private.sortByUsage(
              a,
              b,
              this.model.maxUsageAge,
              this._cwd,
              this._commands
            );
          }
        );*/
        // Render the most used items
        /*if (this._searchInput === '') {
          const mostUsedSection = (
            <div className="jp-NewLauncher-section" key="most-used">
              <div className="jp-NewLauncher-sectionHeader">
                <mostUsedIcon.react stylesheet="launcherSection" />
                <h2 className="jp-NewLauncher-sectionTitle">
                  {this._trans.__('Most Used')}
                </h2>
              </div>
              <div className={`jp-NewLauncher${mode}-cardContainer`}>
                {Array.from(
                  map(
                    mostUsedItems.slice(0, this.model.nRecentCards),
                    (item: INewLauncher.IItemOptions) => {
                      return Card(
                        KERNEL_CATEGORIES.indexOf(item.category || 'Other') > -1,
                        [item],
                        this,
                        this._commands,
                        this._trans,
                        this._callback
                      );
                    }
                  )
                )}
              </div>
            </div>
          );
          sections.push(mostUsedSection);
        }*/
        // Now create the sections for each category
        orderedCategories.forEach(cat => {
            if (categories[cat].length === 0) {
                return;
            }
            const item = categories[cat][0][0];
            const args = { ...item.args, cwd: this.cwd };
            const kernel = cat === 'Kernels';
            const iconClass = this._commands.iconClass(item.command, args);
            const icon = this._commands.icon(item.command, args);
            const section = (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-section", key: cat },
                react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-sectionHeader" },
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon.resolveReact, { icon: icon, iconClass: (0,_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.classes)(iconClass, 'jp-Icon-cover'), stylesheet: "launcherSection" }),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("h2", { className: "jp-NewLauncher-sectionTitle", style: { fontSize: '24px', fontWeight: 600 } },
                        cat === 'Other' && 'Start with',
                        cat === 'Kernels' && 'Open notebook with custom kernel')),
                react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: `jp-NewLauncher${mode}-cardContainer` }, Array.from((0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.map)(categories[cat], (items) => {
                    const item = items[0];
                    const command = item.command;
                    const args = { ...item.args, cwd: this.cwd };
                    const label = this._commands.label(command, args);
                    // Apply search filter
                    if (label
                        .toLocaleLowerCase()
                        .indexOf(this._searchInput.toLocaleLowerCase()) === -1) {
                        return null;
                    }
                    return Card(kernel, items, this, this._commands, this._callback);
                })))));
            sections.push(section);
        });
        //  'ai-data-scientist:focus-chat-input';
        const createNewNotebook = () => {
            if (this.pending === true) {
                return;
            }
            this.pending = true;
            this._commands
                .execute('notebook:create-new', {
                isLauncher: true,
                kernelName: 'python3',
                cwd: this.cwd
            })
                .then(value => {
                this.pending = false;
                if (value instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget) {
                    this._callback(value);
                    this.dispose();
                }
            })
                .catch(err => {
                this.pending = false;
                void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('Error', 'Launcher Error', err);
            });
        };
        // Build the onclick handler.
        const createHelloNotebook = (notebook = 'starter') => {
            if (this.pending === true) {
                return;
            }
            this.pending = true;
            this._commands
                .execute('launcher:create-hello-notebook', { notebook })
                .then(value => {
                this.pending = false;
                if (value instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget) {
                    this._callback(value);
                    this.dispose();
                }
            })
                .catch(err => {
                this.pending = false;
                void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('Error', 'Launcher Error', err);
            });
        };
        // Wrap the sections in body and content divs.
        return (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-body" },
            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-content" },
                react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "mljar-launcher-container" },
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("h1", { className: "mljar-launcher-header" }, "What do you want to analyze?"),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "mljar-launcher-input-container" },
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("input", { type: "text", className: "mljar-launcher-input-field", placeholder: "Start a conversation with AI data analyst ...", onChange: e => {
                                this.model.prompt = e.target.value;
                            }, onKeyDown: e => {
                                if (e.key === 'Enter') {
                                    if (this._stateDB) {
                                        createNewNotebook();
                                        this._stateDB.save('promptToAI', this.model.prompt);
                                        this._commands.execute('ai-data-scientist:focus-chat-input');
                                    }
                                }
                            } }),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-send-button", style: { borderRadius: '50px' }, onClick: () => {
                                if (this._stateDB) {
                                    createNewNotebook();
                                    this._stateDB.save('promptToAI', this.model.prompt);
                                    this._commands.execute('ai-data-scientist:focus-chat-input');
                                }
                            } },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M22 2L11 13", stroke: "white", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M22 2L15 22L11 13L2 9L22 2Z", stroke: "white", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" })))),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "mljar-launcher-controls" },
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-control-button", onClick: createNewNotebook },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 2v20M2 12h20", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" })),
                            "New notebook"),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-control-button", onClick: async () => {
                                let isElectron = false;
                                if (typeof window !== 'undefined') {
                                    if (window.electronAPI !== undefined &&
                                        window.electronAPI !== null) {
                                        isElectron = true;
                                    }
                                }
                                if (isElectron) {
                                    const filePath = await window.electronAPI.recipeOpenFile();
                                    console.log('Selected path file', filePath);
                                    this._stateDB.save('promptToAI', `Read file ${filePath}`);
                                    this._commands.execute('ai-data-scientist:focus-chat-input');
                                }
                                else {
                                    console.log('Cant read data file path, not in electron!');
                                }
                            } },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M14 2v6h6M16 13H8M16 17H8M10 9H8", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" })),
                            "Read a data file"),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-control-button", onClick: () => createHelloNotebook('sample-data') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M14 2v6h6", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 11v6", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M9 14l3 3 3-3", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" })),
                            "Use sample data"),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-control-button", onClick: () => {
                                this.model.showMore = !this.model.showMore;
                                this.update();
                            } },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 13a1 1 0 100-2 1 1 0 000 2zM19 13a1 1 0 100-2 1 1 0 000 2zM5 13a1 1 0 100-2 1 1 0 000 2z", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" })),
                            !this.model.showMore && 'Show more',
                            this.model.showMore && 'Hide options')),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("h2", { className: "mljar-launcher-subheader" }, "Or start from ready workflows"),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflows" },
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('chat-with-data') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M4 5a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H9l-5 4V5z", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M8 9h10", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M8 13h6", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Chat with Data"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Read your data file and ask AI data analyst questions")),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('data-visualzation') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", style: { color: '#43c61f', backgroundColor: '#eaf6e7' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M18 20V10", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 20V4", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M6 20V14", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Data Visualization"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Quickly create visualizations for your data")),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('explore-data') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", style: { color: '#ef6f6c', backgroundColor: '#fce2e2' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "11", cy: "11", r: "8", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M21 21l-4.35-4.35", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Data Exploration"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Create exploratory data analysis on your data file")),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('automl') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", style: { color: '#004666', backgroundColor: '#ccdae0' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("rect", { x: "4", y: "6", width: "16", height: "12", rx: "2", stroke: "currentColor", "stroke-width": "2", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "9", cy: "11", r: "1.5", fill: "currentColor" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "15", cy: "11", r: "1.5", fill: "currentColor" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M9 15c1.333 1 2.667 1 4 0", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("line", { x1: "8", y1: "6", x2: "8", y2: "4", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("line", { x1: "16", y1: "6", x2: "16", y2: "4", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "8", cy: "4", r: "1", fill: "currentColor" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "16", cy: "4", r: "1", fill: "currentColor" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Train AutoML"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Train Machine Learning model with MLJAR AutoML"))),
                    this.model.showMore && (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-content-main" }, sections))))));
    }
}
/**
 * A pure tsx component for a launcher card.
 *
 * @param kernel - whether the item takes uses a kernel.
 *
 * @param item - the launcher item to render.
 *
 * @param launcher - the Launcher instance to which this is added.
 *
 * @param launcherCallback - a callback to call after an item has been launched.
 *
 * @returns a vdom `VirtualElement` for the launcher card.
 */
function Card(kernel, items, launcher, commands, launcherCallback) {
    const mode = launcher.model.viewMode === 'cards' ? '' : '-Table';
    // Get some properties of the first command
    const item = items[0];
    const command = item.command;
    const args = { ...item.args, cwd: launcher.cwd };
    const caption = commands.caption(command, args);
    const label = commands.label(command, args);
    const title = kernel ? label : caption || label;
    // Build the onclick handler.
    const onClickFactory = (item) => {
        const onClick = (event) => {
            event.stopPropagation();
            // If an item has already been launched,
            // don't try to launch another.
            if (launcher.pending === true) {
                return;
            }
            launcher.pending = true;
            void commands
                .execute(item.command, {
                ...item.args,
                cwd: launcher.cwd
            })
                .then(value => {
                launcher.model.useCard(item);
                launcher.pending = false;
                if (value instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget) {
                    launcherCallback(value);
                    launcher.dispose();
                }
            })
                .catch(err => {
                launcher.pending = false;
                void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('Error', 'Launcher Error', err);
            });
        };
        return onClick;
    };
    const mainOnClick = onClickFactory(item);
    // const getOptions = (items: INewLauncher.IItemOptions[]): JSX.Element[] => {
    //   return items.map(item => {
    //     let label = 'Open';
    //     if (
    //       item.category &&
    //       (items.length > 1 || KERNEL_CATEGORIES.indexOf(item.category) > -1)
    //     ) {
    //       label = item.category;
    //     }
    //     return (
    //       <div
    //         className="jp-NewLauncher-option-button"
    //         key={label.toLowerCase()}
    //         onClick={onClickFactory(item)}
    //       >
    //         <span className="jp-NewLauncher-option-button-text">
    //           {label.toUpperCase()}
    //         </span>
    //       </div>
    //     );
    //   });
    // };
    // With tabindex working, you can now pick a kernel by tabbing around and
    // pressing Enter.
    const onkeypress = (event) => {
        if (event.key === 'Enter') {
            mainOnClick(event);
        }
    };
    const iconClass = commands.iconClass(command, args);
    const icon = commands.icon(command, args);
    // Return the VDOM element.
    return (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: `jp-NewLauncher-item${mode}`, title: title, onClick: mainOnClick, onKeyPress: onkeypress, tabIndex: 100, "data-category": item.category || 'Other', key: Private.keyProperty.get(item) },
        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: `jp-NewLauncherCard-icon jp-NewLauncher${mode}-Cell` }, kernel ? (item.kernelIconUrl ? (react__WEBPACK_IMPORTED_MODULE_6__.createElement("img", { src: item.kernelIconUrl, className: "jp-NewLauncher-kernelIcon" })) : (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncherCard-noKernelIcon" }, label[0].toUpperCase()))) : (react__WEBPACK_IMPORTED_MODULE_6__.createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon.resolveReact, { icon: icon, iconClass: (0,_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.classes)(iconClass, 'jp-Icon-cover'), stylesheet: "launcherCard" }))),
        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: `jp-NewLauncher-label jp-NewLauncher${mode}-Cell`, title: label }, label)));
}
/**
 * The namespace for module private data.
 */
var Private;
(function (Private) {
    /**
     * An incrementing counter for keys.
     */
    let id = 0;
    /**
     * An attached property for an item's key.
     */
    Private.keyProperty = new _lumino_properties__WEBPACK_IMPORTED_MODULE_4__.AttachedProperty({
        name: 'key',
        create: () => id++
    });
    /**
     * Create a fully specified item given item options.
     */
    function createItem(options) {
        return {
            ...options,
            category: options.category || '',
            rank: options.rank !== undefined ? options.rank : Infinity
        };
    }
    Private.createItem = createItem;
    /**
     * A sort comparison function for a launcher item.
     */
    function sortCmp(a, b, cwd, commands) {
        // First, compare by rank.
        const r1 = a.rank;
        const r2 = b.rank;
        if (r1 !== r2 && r1 !== undefined && r2 !== undefined) {
            return r1 < r2 ? -1 : 1; // Infinity safe
        }
        // Finally, compare by display name.
        const aLabel = commands.label(a.command, { ...a.args, cwd });
        const bLabel = commands.label(b.command, { ...b.args, cwd });
        return aLabel.localeCompare(bLabel);
    }
    Private.sortCmp = sortCmp;
    function sortByUsage(a, b, maxUsageAge, cwd, commands) {
        const now = Date.now();
        const aCount = now - a.mostRecent < maxUsageAge ? a.count : 0;
        const bCount = now - b.mostRecent < maxUsageAge ? b.count : 0;
        if (aCount === bCount) {
            const mostRecent = b.mostRecent - a.mostRecent;
            return mostRecent === 0 ? sortCmp(a, b, cwd, commands) : mostRecent;
        }
        return bCount - aCount;
    }
    Private.sortByUsage = sortByUsage;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/starters.js":
/*!*************************!*\
  !*** ./lib/starters.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   loadSampleData: () => (/* binding */ loadSampleData)
/* harmony export */ });
const loadSampleData = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# Analysis with sample dataset

Please load sample dataset using Piece of Code recipe. 
You can run exploratory analysis on loaded data.
Please ask AI questions about data or ask for visualization.
      `
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: '## Step 1'
    },
    {
        cell_type: 'code',
        metadata: {},
        source: `# Load sample dataset
print('Please select which dataset would you like to use')
print('There are available datasets that are perfect for data analysis or machine learning tasks')
print('''🍰 Recipe: Load sample dataset''')`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: '## Step 2'
    },
    {
        cell_type: 'code',
        metadata: {},
        source: `# Step 2: Exploratory data analysis 
print('You can run automated exploratory data analysis')
print('''🍰 Recipe: Exploratory data analysis''')
`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: '## Step 3'
    },
    {
        cell_type: 'code',
        metadata: {},
        source: `# Step 3: Ask AI for data insights
print('You can ask AI about your data')
print('''🤖 Ask AI: Get insights about dataset''')
`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: '## Step 4'
    },
    {
        cell_type: 'code',
        metadata: {},
        source: `# Step 4: Ask AI for visualization
print('You can also ask AI to create visualizations')
print('''🤖 Ask AI: Create interactive visaulization''')
`
    }
];


/***/ })

}]);
//# sourceMappingURL=lib_index_js.da806552a28040d77ad0.js.map