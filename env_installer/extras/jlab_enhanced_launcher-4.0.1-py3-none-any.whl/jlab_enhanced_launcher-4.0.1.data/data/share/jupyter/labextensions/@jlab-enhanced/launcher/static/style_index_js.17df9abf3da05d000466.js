"use strict";
(self["webpackChunk_jlab_enhanced_launcher"] = self["webpackChunk_jlab_enhanced_launcher"] || []).push([["style_index_js"],{

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/* -----------------------------------------------------------------------------
| Copyright (c) Jupyter Development Team.
| Distributed under the terms of the Modified BSD License.
|---------------------------------------------------------------------------- */

/* Yellow Button */
.mljarPoCButton {
  padding: 10px 14px;
  border-radius: 6px;
  border: none;

  font-family: -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif;
  font-size: 0.85rem;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  background: linear-gradient(180deg, #ffeb3b 0%, #fbc02d 100%);
  background-origin: border-box;
  color: #000; /* better contrast for yellow */
  box-shadow:
    0px 0.5px 1.5px rgba(251, 192, 45, 0.25),
    inset 0px 0.8px 0px -0.25px rgba(255, 255, 255, 0.2);
}

.mljarPoCButton:hover {
  filter: brightness(1.05);
}

/* Blue Button */
.mljarAskAIButton {
  padding: 10px 14px;
  border-radius: 6px;
  border: none;
  color: #fff;
  font-family: -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif;
  font-size: 0.85rem;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  background: linear-gradient(180deg, #2196f3 0%, #1976d2 100%);
  background-origin: border-box;
  box-shadow:
    0px 0.5px 1.5px rgba(25, 118, 210, 0.25),
    inset 0px 0.8px 0px -0.25px rgba(255, 255, 255, 0.2);
}

.mljarAskAIButton:hover {
  filter: brightness(1.05);
}

/* Private CSS variables */

:root {
  --jp-private-new-launcher-top-padding: 16px;
  --jp-private-new-launcher-side-padding: 16px;
  --jp-private-new-launcher-card-size: 130px;
  --jp-private-new-launcher-card-label-height: 32px;
  --jp-private-new-launcher-card-icon-height: 68px;
  --jp-private-new-launcher-large-icon-size: 52px;
  --jp-private-new-launcher-small-icon-size: 32px;
  --primary: #0099cc;
  --primary-light: #e6f5fa;
  --text: #1a1a2e;
  --text-light: #4f4f6f;
  --background: #f8f9fc;
  --card-bg: #ffffff;
  --border: #e5e7eb;
  --hover: #f1f3ff;
}

.mljar-launcher-container {
  max-width: 1100px;
  margin: 0 auto;
  padding: 40px 20px;
  background-color: var(--background);
  color: var(--text);
  line-height: 1.6;
  padding: 20px;
  /* font-family: -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif; */
}

.mljar-launcher-header {
  font-size: 32px;
  font-weight: 600;
  color: var(--text);
}

.mljar-launcher-subheader {
  font-size: 24px;
  font-weight: 600;
  color: var(--text);
  margin-bottom: 10px;
}

/* Input area */
.mljar-launcher-input-container {
  background: var(--card-bg);
  border-radius: 16px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  padding: 8px;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
}

.mljar-launcher-input-field {
  flex: 1;
  border: none;
  padding: 15px;
  font-size: 16px;
  background: transparent;
  outline: none;
  color: var(--text);
}

.mljar-launcher-input-field::placeholder {
  color: var(--text-light);
}

.mljar-launcher-send-button {
  background-color: #0099cc;
  color: white;
  border: none;
  border-radius: 50%;
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  margin-left: 10px;
  transition: background-color 0.2s;
}

.mljar-launcher-send-button:hover {
  background-color: #00aacc;
}

/* Control buttons */
.mljar-launcher-controls {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  margin-bottom: 30px;
}

.mljar-launcher-control-button {
  background: var(--card-bg);
  border: 1px solid var(--border);
  border-radius: 30px !important;
  padding: 8px 16px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  display: flex;
  align-items: center;
  color: var(--text);
  transition: background-color 0.2s;
}

.mljar-launcher-control-button:hover {
  background-color: var(--hover);
}

.mljar-launcher-control-button svg {
  margin-right: 8px;
}

.mljar-launcher-control-button.dropdown::after {
  content: '▼';
  font-size: 10px;
  margin-left: 8px;
}

/* Workflow cards */
.workflows {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.workflow-card {
  background: var(--card-bg);
  border-radius: 12px;
  padding: 20px;
  transition:
    transform 0.2s,
    box-shadow 0.2s;
  cursor: pointer;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
  display: flex;
  flex-direction: column;
  height: 100%;
  border: 1px solid var(--border);
}

.workflow-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 15px rgba(0, 0, 0, 0.08);
}

.workflow-icon {
  width: 50px;
  height: 50px;
  background-color: var(--primary-light);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 15px;
  color: var(--primary);
}

.workflow-title {
  font-weight: 600;
  font-size: 16px;
  margin-bottom: 5px;
  color: var(--text);
}

.workflow-description {
  color: var(--text-light);
  font-size: 14px;
  margin-bottom: 15px;
  flex-grow: 1;
}

.workflow-stats {
  color: var(--text-light);
  font-size: 12px;
  display: flex;
  align-items: center;
}

.workflow-stats svg {
  margin-right: 5px;
}

/* Launcher */

.jp-NewLauncher {
  margin: 0;
  padding: 0;
  outline: none;
  background: var(--jp-layout-color0);
  box-sizing: border-box;
  min-width: 120px;
  min-height: 120px;

  /* This is needed so that all font sizing of children done in ems is
     * relative to this base size */
  font-size: var(--jp-ui-font-size1);
}

.jp-NewLauncher-body {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  overflow: auto;
  display: flex;
  justify-content: center;
  flex-direction: column;

  background-color: var(--background);
}

/* Toolbar, search bar */
.jp-NewLauncher-toolbar {
  height: 50px;
  border-bottom: var(--jp-border-width) solid var(--jp-toolbar-border-color);
  box-shadow: var(--jp-toolbar-box-shadow);
  background: var(--jp-toolbar-background);
  display: flex;
  align-items: center;
}

.jp-NewLauncher-search {
  padding-left: var(--jp-private-new-launcher-side-padding);
  position: relative;
  margin-right: 20px;
}

.jp-NewLauncher-search-wrapper {
  height: 32px;
}

.jp-NewLauncher-search-wrapper::after {
  content: ' ';
  position: absolute;
  height: 32px;
  width: 12px;
  padding: 0 12px;
  background-image: var(--jp-icon-search);
  background-size: 20px;
  background-repeat: no-repeat;
  background-position: center;
  left: 164px;
}

.jp-NewLauncher-search-input {
  padding: 0 25px 0 9px;
  background-color: var(--jp-input-active-background);
  box-shadow: inset 0 0 0 var(--jp-border-width) var(--jp-input-border-color);
  width: 150px;
  height: 32px;
  border: none;
  outline: none;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color0);
  line-height: var(--jp-private-commandpalette-search-height);
}

.jp-NewLauncher-search-input:active,
.jp-NewLauncher-search-input:focus,
.jp-NewLauncher-search-input:hover {
  box-shadow:
    inset 0 0 0 1px var(--jp-input-active-box-shadow-color),
    inset 0 0 0 3px var(--jp-input-active-box-shadow-color);
}

.jp-NewLauncher-search-input:-webkit-input-placeholder {
  color: var(--jp-ui-font-color3);
  font-size: var(--jp-ui-font-size1);
}

.jp-NewLauncher-search-input:-moz-placeholder {
  color: var(--jp-ui-font-color3);
  font-size: var(--jp-ui-font-size1);
}

.jp-NewLauncher-search-input:-ms-input-placeholder {
  color: var(--jp-ui-font-color3);
  font-size: var(--jp-ui-font-size1);
}

.jp-NewLauncher-home {
  display: flex;
  align-items: center;
}

.jp-NewLauncher-cwd {
  display: flex;
  width: calc(100% - 210px - 40px);
}

.jp-NewLauncher-cwd h3 {
  font-size: var(--jp-ui-font-size2);
  font-weight: normal;
  color: var(--jp-ui-font-color1);
  margin: 1em 0;
  overflow: hidden;
  direction: rtl;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.jp-NewLauncher-view {
  display: flex;
  flex-direction: row;
  align-items: center;
  border: var(--jp-border-width) solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  margin: 0 2px;
}

.jp-NewLauncher-view button {
  border: none;
  border-radius: unset;
  background: transparent;
  cursor: pointer;
  flex: 0 0 auto;
  width: 18px;
  padding: 0;
}

.jp-NewLauncher-view button:hover {
  background: var(--jp-layout-color2);
}

.jp-NewLauncher-view button:disabled {
  cursor: not-allowed;
  background: var(--jp-layout-color3);
}

.jp-NewLauncher-content {
  height: 100%;
  padding-top: var(--jp-private-new-launcher-top-padding);
  padding-left: var(--jp-private-new-launcher-side-padding);
  padding-right: var(--jp-private-new-launcher-side-padding);
  box-sizing: border-box;
}

/* Launcher section */

.jp-NewLauncher-section {
  width: 100%;
  box-sizing: border-box;
  padding-bottom: 12px;
}

.jp-NewLauncher-sectionHeader {
  display: flex;
  flex-direction: row;
  align-items: center;
  box-sizing: border-box;

  /* This is custom tuned to get the section header to align with the cards */
  margin-left: 5px;
  /* border-bottom: 1px solid var(--jp-border-color2); */
  padding-bottom: 0;
  margin-bottom: 8px;
}

.jp-NewLauncher-sectionHeader .jp-NewLauncher-sectionIcon {
  box-sizing: border-box;
  margin-right: 12px;
  height: var(--jp-private-new-launcher-small-icon-size);
  width: var(--jp-private-new-launcher-small-icon-size);
  background-size: var(--jp-private-new-launcher-small-icon-size)
    var(--jp-private-new-launcher-small-icon-size);
}

.jp-NewLauncher-sectionTitle {
  font-size: var(--jp-ui-font-size2);
  font-weight: normal;
  color: var(--jp-ui-font-color1);
  box-sizing: border-box;
}

/* Launcher cards */

.jp-NewLauncher-cardContainer {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  flex-flow: row wrap;
}

.jp-NewLauncher-item {
  display: flex;
  flex-direction: column;
  justify-content: center;
  cursor: pointer;
  width: var(--jp-private-new-launcher-card-size);
  height: var(--jp-private-new-launcher-card-size);
  margin: 8px;
  padding: 0;
  border: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color0);
  box-shadow: var(--jp-elevation-z2);
  transition: 0.2s box-shadow;
  border-radius: 10px;
}

.jp-NewLauncher-item:hover {
  box-shadow: var(--jp-elevation-z6);
  background: var(--jp-layout-color1);
}

.jp-NewLauncherCard-icon {
  width: 100%;
  height: var(--jp-private-new-launcher-card-icon-height);
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
}

.jp-NewLauncher-label {
  width: 100%;
  height: var(--jp-private-new-launcher-card-label-height);
  padding: 0 4px 4px;
  box-sizing: border-box;
  word-break: break-word;
  text-align: center;
  color: var(--jp-ui-font-color1);
  line-height: 14px;
  font-size: 12px;
  overflow: hidden;
}

.jp-NewLauncher-options {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  width: 100%;
}

.jp-NewLauncher-option-button {
  flex: 1 1 auto;
  height: 20px;
  color: rgb(0 132 255);
  font-size: 12px;
  text-align: center;
}

.jp-NewLauncher-option-button-text {
  width: 100%;
}

.jp-NewLauncher-item:hover .jp-NewLauncher-options {
  background: var(--jp-layout-color2);
}

.jp-NewLauncher-item .jp-NewLauncher-options:hover {
  background: transparent;
}

.jp-NewLauncher-option-button:hover {
  background: var(--jp-layout-color2) !important;
}

.jp-NewLauncher-item .jp-NewLauncher-option-button:nth-child(2) {
  background: var(--jp-layout-color0);
}

.jp-NewLauncher-item:hover .jp-NewLauncher-option-button:nth-child(2) {
  background: var(--jp-layout-color1);
}

/* Icons, kernel icons */

.jp-NewLauncher-icon {
  width: 100%;
  height: var(--jp-private-new-launcher-card-icon-height);
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
}

.jp-NewLauncher-kernelIcon {
  width: var(--jp-private-new-launcher-large-icon-size);
  height: var(--jp-private-new-launcher-large-icon-size);
  margin: 0;
  padding: 0;
}
`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;+EAG+E;;AAE/E,kBAAkB;AAClB;EACE,kBAAkB;EAClB,kBAAkB;EAClB,YAAY;;EAEZ,oEAAoE;EACpE,kBAAkB;EAClB,iBAAiB;EACjB,yBAAyB;EACzB,0BAA0B;EAC1B,oBAAoB;EACpB,mBAAmB;EACnB,eAAe;EACf,6DAA6D;EAC7D,6BAA6B;EAC7B,WAAW,EAAE,+BAA+B;EAC5C;;wDAEsD;AACxD;;AAEA;EACE,wBAAwB;AAC1B;;AAEA,gBAAgB;AAChB;EACE,kBAAkB;EAClB,kBAAkB;EAClB,YAAY;EACZ,WAAW;EACX,oEAAoE;EACpE,kBAAkB;EAClB,iBAAiB;EACjB,yBAAyB;EACzB,0BAA0B;EAC1B,oBAAoB;EACpB,mBAAmB;EACnB,eAAe;EACf,6DAA6D;EAC7D,6BAA6B;EAC7B;;wDAEsD;AACxD;;AAEA;EACE,wBAAwB;AAC1B;;AAEA,0BAA0B;;AAE1B;EACE,2CAA2C;EAC3C,4CAA4C;EAC5C,0CAA0C;EAC1C,iDAAiD;EACjD,gDAAgD;EAChD,+CAA+C;EAC/C,+CAA+C;EAC/C,kBAAkB;EAClB,wBAAwB;EACxB,eAAe;EACf,qBAAqB;EACrB,qBAAqB;EACrB,kBAAkB;EAClB,iBAAiB;EACjB,gBAAgB;AAClB;;AAEA;EACE,iBAAiB;EACjB,cAAc;EACd,kBAAkB;EAClB,mCAAmC;EACnC,kBAAkB;EAClB,gBAAgB;EAChB,aAAa;EACb,0EAA0E;AAC5E;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,kBAAkB;EAClB,mBAAmB;AACrB;;AAEA,eAAe;AACf;EACE,0BAA0B;EAC1B,mBAAmB;EACnB,0CAA0C;EAC1C,YAAY;EACZ,mBAAmB;EACnB,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,OAAO;EACP,YAAY;EACZ,aAAa;EACb,eAAe;EACf,uBAAuB;EACvB,aAAa;EACb,kBAAkB;AACpB;;AAEA;EACE,wBAAwB;AAC1B;;AAEA;EACE,yBAAyB;EACzB,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,WAAW;EACX,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;EACf,iBAAiB;EACjB,iCAAiC;AACnC;;AAEA;EACE,yBAAyB;AAC3B;;AAEA,oBAAoB;AACpB;EACE,aAAa;EACb,SAAS;EACT,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE,0BAA0B;EAC1B,+BAA+B;EAC/B,8BAA8B;EAC9B,iBAAiB;EACjB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,aAAa;EACb,mBAAmB;EACnB,kBAAkB;EAClB,iCAAiC;AACnC;;AAEA;EACE,8BAA8B;AAChC;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,YAAY;EACZ,eAAe;EACf,gBAAgB;AAClB;;AAEA,mBAAmB;AACnB;EACE,aAAa;EACb,4DAA4D;EAC5D,SAAS;EACT,mBAAmB;AACrB;;AAEA;EACE,0BAA0B;EAC1B,mBAAmB;EACnB,aAAa;EACb;;mBAEiB;EACjB,eAAe;EACf,yCAAyC;EACzC,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,+BAA+B;AACjC;;AAEA;EACE,2BAA2B;EAC3B,0CAA0C;AAC5C;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,sCAAsC;EACtC,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,mBAAmB;EACnB,qBAAqB;AACvB;;AAEA;EACE,gBAAgB;EAChB,eAAe;EACf,kBAAkB;EAClB,kBAAkB;AACpB;;AAEA;EACE,wBAAwB;EACxB,eAAe;EACf,mBAAmB;EACnB,YAAY;AACd;;AAEA;EACE,wBAAwB;EACxB,eAAe;EACf,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,iBAAiB;AACnB;;AAEA,aAAa;;AAEb;EACE,SAAS;EACT,UAAU;EACV,aAAa;EACb,mCAAmC;EACnC,sBAAsB;EACtB,gBAAgB;EAChB,iBAAiB;;EAEjB;mCACiC;EACjC,kCAAkC;AACpC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,sBAAsB;EACtB,cAAc;EACd,aAAa;EACb,uBAAuB;EACvB,sBAAsB;;EAEtB,mCAAmC;AACrC;;AAEA,wBAAwB;AACxB;EACE,YAAY;EACZ,0EAA0E;EAC1E,wCAAwC;EACxC,wCAAwC;EACxC,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,yDAAyD;EACzD,kBAAkB;EAClB,kBAAkB;AACpB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,YAAY;EACZ,kBAAkB;EAClB,YAAY;EACZ,WAAW;EACX,eAAe;EACf,uCAAuC;EACvC,qBAAqB;EACrB,4BAA4B;EAC5B,2BAA2B;EAC3B,WAAW;AACb;;AAEA;EACE,qBAAqB;EACrB,mDAAmD;EACnD,2EAA2E;EAC3E,YAAY;EACZ,YAAY;EACZ,YAAY;EACZ,aAAa;EACb,kCAAkC;EAClC,+BAA+B;EAC/B,2DAA2D;AAC7D;;AAEA;;;EAGE;;2DAEyD;AAC3D;;AAEA;EACE,+BAA+B;EAC/B,kCAAkC;AACpC;;AAEA;EACE,+BAA+B;EAC/B,kCAAkC;AACpC;;AAEA;EACE,+BAA+B;EAC/B,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,gCAAgC;AAClC;;AAEA;EACE,kCAAkC;EAClC,mBAAmB;EACnB,+BAA+B;EAC/B,aAAa;EACb,gBAAgB;EAChB,cAAc;EACd,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,4DAA4D;EAC5D,sCAAsC;EACtC,aAAa;AACf;;AAEA;EACE,YAAY;EACZ,oBAAoB;EACpB,uBAAuB;EACvB,eAAe;EACf,cAAc;EACd,WAAW;EACX,UAAU;AACZ;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,mBAAmB;EACnB,mCAAmC;AACrC;;AAEA;EACE,YAAY;EACZ,uDAAuD;EACvD,yDAAyD;EACzD,0DAA0D;EAC1D,sBAAsB;AACxB;;AAEA,qBAAqB;;AAErB;EACE,WAAW;EACX,sBAAsB;EACtB,oBAAoB;AACtB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,sBAAsB;;EAEtB,2EAA2E;EAC3E,gBAAgB;EAChB,sDAAsD;EACtD,iBAAiB;EACjB,kBAAkB;AACpB;;AAEA;EACE,sBAAsB;EACtB,kBAAkB;EAClB,sDAAsD;EACtD,qDAAqD;EACrD;kDACgD;AAClD;;AAEA;EACE,kCAAkC;EAClC,mBAAmB;EACnB,+BAA+B;EAC/B,sBAAsB;AACxB;;AAEA,mBAAmB;;AAEnB;EACE,SAAS;EACT,UAAU;EACV,sBAAsB;EACtB,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,eAAe;EACf,+CAA+C;EAC/C,gDAAgD;EAChD,WAAW;EACX,UAAU;EACV,yCAAyC;EACzC,mCAAmC;EACnC,kCAAkC;EAClC,2BAA2B;EAC3B,mBAAmB;AACrB;;AAEA;EACE,kCAAkC;EAClC,mCAAmC;AACrC;;AAEA;EACE,WAAW;EACX,uDAAuD;EACvD,sBAAsB;EACtB,SAAS;EACT,UAAU;EACV,aAAa;EACb,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,WAAW;EACX,wDAAwD;EACxD,kBAAkB;EAClB,sBAAsB;EACtB,sBAAsB;EACtB,kBAAkB;EAClB,+BAA+B;EAC/B,iBAAiB;EACjB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,6BAA6B;EAC7B,WAAW;AACb;;AAEA;EACE,cAAc;EACd,YAAY;EACZ,qBAAqB;EACrB,eAAe;EACf,kBAAkB;AACpB;;AAEA;EACE,WAAW;AACb;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,8CAA8C;AAChD;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,mCAAmC;AACrC;;AAEA,wBAAwB;;AAExB;EACE,WAAW;EACX,uDAAuD;EACvD,sBAAsB;EACtB,SAAS;EACT,UAAU;EACV,aAAa;EACb,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,qDAAqD;EACrD,sDAAsD;EACtD,SAAS;EACT,UAAU;AACZ","sourcesContent":["/* -----------------------------------------------------------------------------\n| Copyright (c) Jupyter Development Team.\n| Distributed under the terms of the Modified BSD License.\n|---------------------------------------------------------------------------- */\n\n/* Yellow Button */\n.mljarPoCButton {\n  padding: 10px 14px;\n  border-radius: 6px;\n  border: none;\n\n  font-family: -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif;\n  font-size: 0.85rem;\n  user-select: none;\n  -webkit-user-select: none;\n  touch-action: manipulation;\n  display: inline-flex;\n  align-items: center;\n  cursor: pointer;\n  background: linear-gradient(180deg, #ffeb3b 0%, #fbc02d 100%);\n  background-origin: border-box;\n  color: #000; /* better contrast for yellow */\n  box-shadow:\n    0px 0.5px 1.5px rgba(251, 192, 45, 0.25),\n    inset 0px 0.8px 0px -0.25px rgba(255, 255, 255, 0.2);\n}\n\n.mljarPoCButton:hover {\n  filter: brightness(1.05);\n}\n\n/* Blue Button */\n.mljarAskAIButton {\n  padding: 10px 14px;\n  border-radius: 6px;\n  border: none;\n  color: #fff;\n  font-family: -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif;\n  font-size: 0.85rem;\n  user-select: none;\n  -webkit-user-select: none;\n  touch-action: manipulation;\n  display: inline-flex;\n  align-items: center;\n  cursor: pointer;\n  background: linear-gradient(180deg, #2196f3 0%, #1976d2 100%);\n  background-origin: border-box;\n  box-shadow:\n    0px 0.5px 1.5px rgba(25, 118, 210, 0.25),\n    inset 0px 0.8px 0px -0.25px rgba(255, 255, 255, 0.2);\n}\n\n.mljarAskAIButton:hover {\n  filter: brightness(1.05);\n}\n\n/* Private CSS variables */\n\n:root {\n  --jp-private-new-launcher-top-padding: 16px;\n  --jp-private-new-launcher-side-padding: 16px;\n  --jp-private-new-launcher-card-size: 130px;\n  --jp-private-new-launcher-card-label-height: 32px;\n  --jp-private-new-launcher-card-icon-height: 68px;\n  --jp-private-new-launcher-large-icon-size: 52px;\n  --jp-private-new-launcher-small-icon-size: 32px;\n  --primary: #0099cc;\n  --primary-light: #e6f5fa;\n  --text: #1a1a2e;\n  --text-light: #4f4f6f;\n  --background: #f8f9fc;\n  --card-bg: #ffffff;\n  --border: #e5e7eb;\n  --hover: #f1f3ff;\n}\n\n.mljar-launcher-container {\n  max-width: 1100px;\n  margin: 0 auto;\n  padding: 40px 20px;\n  background-color: var(--background);\n  color: var(--text);\n  line-height: 1.6;\n  padding: 20px;\n  /* font-family: -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif; */\n}\n\n.mljar-launcher-header {\n  font-size: 32px;\n  font-weight: 600;\n  color: var(--text);\n}\n\n.mljar-launcher-subheader {\n  font-size: 24px;\n  font-weight: 600;\n  color: var(--text);\n  margin-bottom: 10px;\n}\n\n/* Input area */\n.mljar-launcher-input-container {\n  background: var(--card-bg);\n  border-radius: 16px;\n  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);\n  padding: 8px;\n  margin-bottom: 20px;\n  display: flex;\n  align-items: center;\n}\n\n.mljar-launcher-input-field {\n  flex: 1;\n  border: none;\n  padding: 15px;\n  font-size: 16px;\n  background: transparent;\n  outline: none;\n  color: var(--text);\n}\n\n.mljar-launcher-input-field::placeholder {\n  color: var(--text-light);\n}\n\n.mljar-launcher-send-button {\n  background-color: #0099cc;\n  color: white;\n  border: none;\n  border-radius: 50%;\n  width: 48px;\n  height: 48px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  margin-left: 10px;\n  transition: background-color 0.2s;\n}\n\n.mljar-launcher-send-button:hover {\n  background-color: #00aacc;\n}\n\n/* Control buttons */\n.mljar-launcher-controls {\n  display: flex;\n  gap: 10px;\n  flex-wrap: wrap;\n  margin-bottom: 30px;\n}\n\n.mljar-launcher-control-button {\n  background: var(--card-bg);\n  border: 1px solid var(--border);\n  border-radius: 30px !important;\n  padding: 8px 16px;\n  font-size: 14px;\n  font-weight: 500;\n  cursor: pointer;\n  display: flex;\n  align-items: center;\n  color: var(--text);\n  transition: background-color 0.2s;\n}\n\n.mljar-launcher-control-button:hover {\n  background-color: var(--hover);\n}\n\n.mljar-launcher-control-button svg {\n  margin-right: 8px;\n}\n\n.mljar-launcher-control-button.dropdown::after {\n  content: '▼';\n  font-size: 10px;\n  margin-left: 8px;\n}\n\n/* Workflow cards */\n.workflows {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));\n  gap: 20px;\n  margin-bottom: 30px;\n}\n\n.workflow-card {\n  background: var(--card-bg);\n  border-radius: 12px;\n  padding: 20px;\n  transition:\n    transform 0.2s,\n    box-shadow 0.2s;\n  cursor: pointer;\n  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  border: 1px solid var(--border);\n}\n\n.workflow-card:hover {\n  transform: translateY(-4px);\n  box-shadow: 0 8px 15px rgba(0, 0, 0, 0.08);\n}\n\n.workflow-icon {\n  width: 50px;\n  height: 50px;\n  background-color: var(--primary-light);\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 15px;\n  color: var(--primary);\n}\n\n.workflow-title {\n  font-weight: 600;\n  font-size: 16px;\n  margin-bottom: 5px;\n  color: var(--text);\n}\n\n.workflow-description {\n  color: var(--text-light);\n  font-size: 14px;\n  margin-bottom: 15px;\n  flex-grow: 1;\n}\n\n.workflow-stats {\n  color: var(--text-light);\n  font-size: 12px;\n  display: flex;\n  align-items: center;\n}\n\n.workflow-stats svg {\n  margin-right: 5px;\n}\n\n/* Launcher */\n\n.jp-NewLauncher {\n  margin: 0;\n  padding: 0;\n  outline: none;\n  background: var(--jp-layout-color0);\n  box-sizing: border-box;\n  min-width: 120px;\n  min-height: 120px;\n\n  /* This is needed so that all font sizing of children done in ems is\n     * relative to this base size */\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-NewLauncher-body {\n  width: 100%;\n  height: 100%;\n  box-sizing: border-box;\n  overflow: auto;\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n\n  background-color: var(--background);\n}\n\n/* Toolbar, search bar */\n.jp-NewLauncher-toolbar {\n  height: 50px;\n  border-bottom: var(--jp-border-width) solid var(--jp-toolbar-border-color);\n  box-shadow: var(--jp-toolbar-box-shadow);\n  background: var(--jp-toolbar-background);\n  display: flex;\n  align-items: center;\n}\n\n.jp-NewLauncher-search {\n  padding-left: var(--jp-private-new-launcher-side-padding);\n  position: relative;\n  margin-right: 20px;\n}\n\n.jp-NewLauncher-search-wrapper {\n  height: 32px;\n}\n\n.jp-NewLauncher-search-wrapper::after {\n  content: ' ';\n  position: absolute;\n  height: 32px;\n  width: 12px;\n  padding: 0 12px;\n  background-image: var(--jp-icon-search);\n  background-size: 20px;\n  background-repeat: no-repeat;\n  background-position: center;\n  left: 164px;\n}\n\n.jp-NewLauncher-search-input {\n  padding: 0 25px 0 9px;\n  background-color: var(--jp-input-active-background);\n  box-shadow: inset 0 0 0 var(--jp-border-width) var(--jp-input-border-color);\n  width: 150px;\n  height: 32px;\n  border: none;\n  outline: none;\n  font-size: var(--jp-ui-font-size1);\n  color: var(--jp-ui-font-color0);\n  line-height: var(--jp-private-commandpalette-search-height);\n}\n\n.jp-NewLauncher-search-input:active,\n.jp-NewLauncher-search-input:focus,\n.jp-NewLauncher-search-input:hover {\n  box-shadow:\n    inset 0 0 0 1px var(--jp-input-active-box-shadow-color),\n    inset 0 0 0 3px var(--jp-input-active-box-shadow-color);\n}\n\n.jp-NewLauncher-search-input:-webkit-input-placeholder {\n  color: var(--jp-ui-font-color3);\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-NewLauncher-search-input:-moz-placeholder {\n  color: var(--jp-ui-font-color3);\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-NewLauncher-search-input:-ms-input-placeholder {\n  color: var(--jp-ui-font-color3);\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-NewLauncher-home {\n  display: flex;\n  align-items: center;\n}\n\n.jp-NewLauncher-cwd {\n  display: flex;\n  width: calc(100% - 210px - 40px);\n}\n\n.jp-NewLauncher-cwd h3 {\n  font-size: var(--jp-ui-font-size2);\n  font-weight: normal;\n  color: var(--jp-ui-font-color1);\n  margin: 1em 0;\n  overflow: hidden;\n  direction: rtl;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n\n.jp-NewLauncher-view {\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  border: var(--jp-border-width) solid var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  margin: 0 2px;\n}\n\n.jp-NewLauncher-view button {\n  border: none;\n  border-radius: unset;\n  background: transparent;\n  cursor: pointer;\n  flex: 0 0 auto;\n  width: 18px;\n  padding: 0;\n}\n\n.jp-NewLauncher-view button:hover {\n  background: var(--jp-layout-color2);\n}\n\n.jp-NewLauncher-view button:disabled {\n  cursor: not-allowed;\n  background: var(--jp-layout-color3);\n}\n\n.jp-NewLauncher-content {\n  height: 100%;\n  padding-top: var(--jp-private-new-launcher-top-padding);\n  padding-left: var(--jp-private-new-launcher-side-padding);\n  padding-right: var(--jp-private-new-launcher-side-padding);\n  box-sizing: border-box;\n}\n\n/* Launcher section */\n\n.jp-NewLauncher-section {\n  width: 100%;\n  box-sizing: border-box;\n  padding-bottom: 12px;\n}\n\n.jp-NewLauncher-sectionHeader {\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  box-sizing: border-box;\n\n  /* This is custom tuned to get the section header to align with the cards */\n  margin-left: 5px;\n  /* border-bottom: 1px solid var(--jp-border-color2); */\n  padding-bottom: 0;\n  margin-bottom: 8px;\n}\n\n.jp-NewLauncher-sectionHeader .jp-NewLauncher-sectionIcon {\n  box-sizing: border-box;\n  margin-right: 12px;\n  height: var(--jp-private-new-launcher-small-icon-size);\n  width: var(--jp-private-new-launcher-small-icon-size);\n  background-size: var(--jp-private-new-launcher-small-icon-size)\n    var(--jp-private-new-launcher-small-icon-size);\n}\n\n.jp-NewLauncher-sectionTitle {\n  font-size: var(--jp-ui-font-size2);\n  font-weight: normal;\n  color: var(--jp-ui-font-color1);\n  box-sizing: border-box;\n}\n\n/* Launcher cards */\n\n.jp-NewLauncher-cardContainer {\n  margin: 0;\n  padding: 0;\n  box-sizing: border-box;\n  display: flex;\n  flex-flow: row wrap;\n}\n\n.jp-NewLauncher-item {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  cursor: pointer;\n  width: var(--jp-private-new-launcher-card-size);\n  height: var(--jp-private-new-launcher-card-size);\n  margin: 8px;\n  padding: 0;\n  border: 1px solid var(--jp-border-color2);\n  background: var(--jp-layout-color0);\n  box-shadow: var(--jp-elevation-z2);\n  transition: 0.2s box-shadow;\n  border-radius: 10px;\n}\n\n.jp-NewLauncher-item:hover {\n  box-shadow: var(--jp-elevation-z6);\n  background: var(--jp-layout-color1);\n}\n\n.jp-NewLauncherCard-icon {\n  width: 100%;\n  height: var(--jp-private-new-launcher-card-icon-height);\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.jp-NewLauncher-label {\n  width: 100%;\n  height: var(--jp-private-new-launcher-card-label-height);\n  padding: 0 4px 4px;\n  box-sizing: border-box;\n  word-break: break-word;\n  text-align: center;\n  color: var(--jp-ui-font-color1);\n  line-height: 14px;\n  font-size: 12px;\n  overflow: hidden;\n}\n\n.jp-NewLauncher-options {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-around;\n  width: 100%;\n}\n\n.jp-NewLauncher-option-button {\n  flex: 1 1 auto;\n  height: 20px;\n  color: rgb(0 132 255);\n  font-size: 12px;\n  text-align: center;\n}\n\n.jp-NewLauncher-option-button-text {\n  width: 100%;\n}\n\n.jp-NewLauncher-item:hover .jp-NewLauncher-options {\n  background: var(--jp-layout-color2);\n}\n\n.jp-NewLauncher-item .jp-NewLauncher-options:hover {\n  background: transparent;\n}\n\n.jp-NewLauncher-option-button:hover {\n  background: var(--jp-layout-color2) !important;\n}\n\n.jp-NewLauncher-item .jp-NewLauncher-option-button:nth-child(2) {\n  background: var(--jp-layout-color0);\n}\n\n.jp-NewLauncher-item:hover .jp-NewLauncher-option-button:nth-child(2) {\n  background: var(--jp-layout-color1);\n}\n\n/* Icons, kernel icons */\n\n.jp-NewLauncher-icon {\n  width: 100%;\n  height: var(--jp-private-new-launcher-card-icon-height);\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.jp-NewLauncher-kernelIcon {\n  width: var(--jp-private-new-launcher-large-icon-size);\n  height: var(--jp-private-new-launcher-large-icon-size);\n  margin: 0;\n  padding: 0;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./style/table.css":
/*!***************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/table.css ***!
  \***************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `.jp-NewLauncher-content-main-Table {
  width: 100%;
}

.jp-NewLauncher-Table-cardContainer {
  display: table;
  table-layout: fixed;
  width: 100%;
}

.jp-NewLauncher-item-Table {
  display: table-row;
}

.jp-NewLauncher-item-Table:hover {
  background: var(--jp-layout-color2);
}

.jp-NewLauncher-item-Table:hover .jp-NewLauncher-options {
  background: var(--jp-layout-color3);
}

.jp-NewLauncher-item-Table .jp-NewLauncher-options:hover {
  background: transparent;
}

.jp-NewLauncher-item-Table .jp-NewLauncher-option-button:nth-child(2) {
  background: var(--jp-layout-color0);
}

.jp-NewLauncher-item-Table .jp-NewLauncher-option-button:hover {
  background: var(--jp-layout-color3) !important;
}

.jp-NewLauncher-item-Table:hover .jp-NewLauncher-option-button:nth-child(2) {
  background: var(--jp-layout-color2);
}

.jp-NewLauncher-Table-Cell.jp-NewLauncher-label {
  width: auto;
  height: auto;
  font-size: var(--jp-ui-font-size1);
  text-align: left;
}

.jp-NewLauncher-Table-Cell.jp-NewLauncher-options-wrapper {
  width: 25%;
}

.jp-NewLauncher-Table-Cell.jp-NewLauncherCard-icon {
  width: 18px;
  height: 18px;
}

.jp-NewLauncher-Table-Cell.jp-NewLauncherCard-icon > div {
  width: 16px;
  height: 16px;
}

.jp-NewLauncher-item-Table .jp-NewLauncher-kernelIcon {
  width: 16px;
  height: 16px;
}

.jp-NewLauncher-Table-Cell {
  display: table-cell;
  vertical-align: middle;
}
`, "",{"version":3,"sources":["webpack://./style/table.css"],"names":[],"mappings":"AAAA;EACE,WAAW;AACb;;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,WAAW;AACb;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,8CAA8C;AAChD;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,mBAAmB;EACnB,sBAAsB;AACxB","sourcesContent":[".jp-NewLauncher-content-main-Table {\n  width: 100%;\n}\n\n.jp-NewLauncher-Table-cardContainer {\n  display: table;\n  table-layout: fixed;\n  width: 100%;\n}\n\n.jp-NewLauncher-item-Table {\n  display: table-row;\n}\n\n.jp-NewLauncher-item-Table:hover {\n  background: var(--jp-layout-color2);\n}\n\n.jp-NewLauncher-item-Table:hover .jp-NewLauncher-options {\n  background: var(--jp-layout-color3);\n}\n\n.jp-NewLauncher-item-Table .jp-NewLauncher-options:hover {\n  background: transparent;\n}\n\n.jp-NewLauncher-item-Table .jp-NewLauncher-option-button:nth-child(2) {\n  background: var(--jp-layout-color0);\n}\n\n.jp-NewLauncher-item-Table .jp-NewLauncher-option-button:hover {\n  background: var(--jp-layout-color3) !important;\n}\n\n.jp-NewLauncher-item-Table:hover .jp-NewLauncher-option-button:nth-child(2) {\n  background: var(--jp-layout-color2);\n}\n\n.jp-NewLauncher-Table-Cell.jp-NewLauncher-label {\n  width: auto;\n  height: auto;\n  font-size: var(--jp-ui-font-size1);\n  text-align: left;\n}\n\n.jp-NewLauncher-Table-Cell.jp-NewLauncher-options-wrapper {\n  width: 25%;\n}\n\n.jp-NewLauncher-Table-Cell.jp-NewLauncherCard-icon {\n  width: 18px;\n  height: 18px;\n}\n\n.jp-NewLauncher-Table-Cell.jp-NewLauncherCard-icon > div {\n  width: 16px;\n  height: 16px;\n}\n\n.jp-NewLauncher-item-Table .jp-NewLauncher-kernelIcon {\n  width: 16px;\n  height: 16px;\n}\n\n.jp-NewLauncher-Table-Cell {\n  display: table-cell;\n  vertical-align: middle;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js":
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
/***/ ((module) => {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
/***/ ((module) => {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js":
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
/***/ ((module) => {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js":
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js":
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js":
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");
/* harmony import */ var _table_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./table.css */ "./style/table.css");




/***/ }),

/***/ "./style/table.css":
/*!*************************!*\
  !*** ./style/table.css ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_table_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./table.css */ "./node_modules/css-loader/dist/cjs.js!./style/table.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_table_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_table_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_table_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_table_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ })

}]);
//# sourceMappingURL=style_index_js.17df9abf3da05d000466.js.map