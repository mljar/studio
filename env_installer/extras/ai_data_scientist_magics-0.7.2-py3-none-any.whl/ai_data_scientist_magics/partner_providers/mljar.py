import os
import requests 

from ..providers import BaseProvider, TextField

from .llm import MLJARStreaming
from .utils import MLJAR_ADDRESS, MLJAR_AUTH_KEY


def set_auth_token(email, password):
    if os.getenv(MLJAR_AUTH_KEY) is None:
        login_url = "/api/auth/login/"
        response = requests.post(f"{MLJAR_ADDRESS}{login_url}", {"email": email, "password": password})
        if response.status_code == 200:
            key = response.json().get("key")
            if key is not None:
                os.environ[MLJAR_AUTH_KEY] = key


class ChatMLJARProvider(BaseProvider, MLJARStreaming):
    id = "provider-mljar"
    """ID for this provider class."""

    name = "MLJAR"
    """User-facing name of this provider."""

    models = ["turbo"]
    """List of supported models by their IDs. For registry providers, this will
    be just ["*"]."""

    help = None
    """Text to display in lieu of a model list for a registry provider that does
    not provide a list of models."""

    model_id_key = "model_id"
    """Kwarg expected by the upstream LangChain provider."""

    model_id_label = "Model ID"
    """Human-readable label of the model ID."""

    pypi_package_deps = []
    """List of PyPi package dependencies."""

    auth_strategy = None 
        
    """Authentication/authorization strategy. Declares what credentials are
    required to use this model provider. Generally should not be `None`."""

    registry = False
    """Whether this provider is a registry provider."""

    fields = [
        TextField(key="mljar_email", label="Email", format="text"),
        TextField(key="mljar_password", label="Password", format="password"),
    ]
    """User inputs expected by this provider when initializing it. Each `Field` `f`
    should be passed in the constructor as a keyword argument, keyed by `f.key`."""

    def __init__(self, *args, **kwargs):
        mljar_email = kwargs.pop("mljar_email")
        mljar_password = kwargs.pop("mljar_password")
        set_auth_token(mljar_email, mljar_password)

        super().__init__(*args, **kwargs)
