"use strict";
(self["webpackChunkpackage_manager"] = self["webpackChunkpackage_manager"] || []).push([["style_index_js"],{

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js":
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
/***/ ((module) => {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
/***/ ((module) => {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js":
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
/***/ ((module) => {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js":
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js":
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js":
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ }),

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");



/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
    See the JupyterLab Developer Guide for useful CSS Patterns:

    https://jupyterlab.readthedocs.io/en/stable/developer/css.html
*/

/*
    See the JupyterLab Developer Guide for useful CSS Patterns:

    https://jupyterlab.readthedocs.io/en/stable/developer/css.html
*/

/* containers */

.mljar-sidebar-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow-y: auto;
}

.mljar-search-bar-container {
  margin-bottom: 10px;
  background-color: lightblue;
  margin-right: 10px;
}

.mljar-search-bar-input {
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  border: 1px solid var(--jp-border-color2);
}

.mljar-search-bar-input::placeholder {
  color: var(--jp-ui-font-color2);
}

.mljar-package-container {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.mljar-package-header-container {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 8px;
  margin-right: 8px;
  border-bottom: 2px solid #ddd;
}

.mljar-package-header {
  flex:4;
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--jp-ui-font-color1);
  text-align: left;
  padding-bottom: 8px;
  margin: 0;
}

.mljar-logo-container {
  display: flex;
  align-items: flex-end;
}

.mljar-logo-container img {
  max-height: 30px;
  width: auto;
}

.mljar-actions-container {
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
  margin-right: 10px;
}

.mljar-package-list-container {
  flex: 1;
  overflow-y: hidden;
  padding-right: 10px;
}

.mljar-package-list {
  list-style: none;
  padding: 0;
  margin: 0;
}


.mljar-package-list-container::-webkit-scrollbar {
  width: 8px;
}

.mljar-package-list-container::-webkit-scrollbar-thumb {
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 4px;
}

.mljar-package-list-container::-webkit-scrollbar-track {
  background-color: rgba(0, 0, 0, 0.05);
}

.mljar-plugin-sidebar-widget {
  background-color: #ffffff;
  padding: 10px;
}



/* containers */

/* buttons */
.mljar-back-button,
.mljar-install-button,
.mljar-refresh-button {
  flex: 1;
  text-align: right;
  max-width: 30px;
  display: flex;
  margin-right: 1px;
  align-items: center;
  justify-content: center;
  /* background-color: #0099cc; */
  gap: 8px;
  color: #0099cc;
  border: none;
  border-radius: 4px;
  padding: 8px 0px;
  cursor: pointer;
  font-size: 0.75rem;
  transition: background-color 0.3s ease;
}

.mljar-back-button {
  max-width: 70px !important;
  text-align: center;
  padding-right: 4px;
}

.mljar-back-button:hover:not(:disabled),
.mljar-refresh-button:hover:not(:disabled),
.mljar-install-button:hover:not(:disabled) {
  background-color: #0099cc;
  color: #ffffff;
}


/* .mljar-back-button {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #0099cc;
  gap: 8px;
  color: white;
  border: none;
  border-radius: 4px;
  padding: 8px 0px;
  cursor: pointer;
  font-size: 0.75rem;
  transition: background-color 0.3s ease;
} */

.mljar-delete-button {
  visibility: hidden;
  background: none; 
  position: relative;
  border: none;
  cursor: pointer;
  padding: 4px;
  margin-bottom: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #dc3545;
  transition: color 0.3s ease;
}

.mljar-delete-button[data-tooltip]:hover::after {
  content: attr(data-tooltip);
  position: absolute;
  bottom: 110%;
  left: -110%;
  transform: translateX(-50%);
  background: #333;
  color: #fff;
  padding: 5px 8px;
  border-radius: 4px;
  white-space: nowrap;
  font-size: 0.8em;
  z-index: 10;
  opacity: 0.9;
}


.mljar-refresh-button:disabled,
.mljar-install-button:disabled,
.mljar-back-button:disabled {
  background-color: #a0c4e3;
  cursor: not-allowed;
}

/* .mljar-back-button:hover:not(:disabled) {
  background-color: #005fa3;
} */

.mljar-install-submit-button {
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 4px;
  padding: 8px 12px;
  cursor: pointer;
  font-size: 0.75rem;
  transition: background-color 0.3s ease;
}

.mljar-install-submit-button:disabled {
  background-color: #94d3a2;
  cursor: not-allowed;
}

.mljar-install-submit-button:hover:not(:disabled) {
  background-color: #1e7e34;
}

.mljar-delete-button:hover {
  color: #a71d2a;
}

.mljar-package-item:hover .mljar-delete-button {
  visibility: visible;
}
/* buttons */

/* icons */

.mljar-refresh-icon,
.mljar-install-icon,
.mljar-back-icon {
  display: flex;
  align-items: center;
  width: 15px;
  height: 15px;
}

.mljar-delete-icon {
  width: 15px;
  height: 15px;
}

.mljar-error-icon {
  color: #dc3545;
  width: 15px;
  height: 15px;
}


.mljar-info-icon-container {
  position: relative;
  display: inline-block;
  cursor: pointer;
}

.mljar-info-icon-container span:first-child {
  display: inline-flex;
  align-items: center;
  color: #0099cc;
  margin: 0px;
  width: 18px;
  height: 18px;
}

.mljar-info-icon-container .mljar-tooltip {
  visibility: hidden;
  width: 150px;
  background-color: #28a745;
  color: white;
  text-align: center;
  border-radius: 4px;
  padding: 5px;
  position: absolute;
  left: -160px;
  top: 100%;
  z-index: 1;
  opacity: 0;
  transition: opacity 0.3s;
  white-space: pre-line;
}

.mljar-info-icon-container:hover .mljar-tooltip {
  visibility: visible;
  opacity: 1;
}

/* icons */

.mljar-install-form {
  display: flex;
  flex-direction: column;
  margin-right: 8px;
}

.mljar-install-form h4 {
  margin-top: 0px;
  margin-bottom: 4px;
  padding: 0;
}

.mljar-usage-span {
  margin-bottom: 4px;
  font-size: 0.55rem;
}


.mljar-install-input {
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  border: 1px solid var(--jp-border-color2);
  margin-bottom: 8px;
}

.mljar-install-input::placeholder {
  color: var(--jp-ui-font-color2);
}

.mljar-install-message {
  color: #28a745;
  font-weight: bold;
}

.mljar-install-message.error {
  color: #dc3545;
}

.mljar-error-message {
  color: #dc3545;
  font-weight: bold;
}


/* spinner */

.mljar-spinner-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  padding: 20px;
}


.mljar-spinner {
  border: 4px solid rgba(0, 0, 0, 0.1);
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border-left-color: #ffffff;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* spinner */

/* list */

.mljar-package-item {
  flex: 1;
  display: grid;
  grid-template-columns: 1fr 1fr 2rem;
  align-items: center;
  column-gap: 1rem;
  padding-left: 8px;
  padding-right: 8px;
  border: 1px solid var(--jp-border-color2);
  margin-bottom: 0px;
  margin-right: 0px;
  width: 100%;
  box-sizing: border-box;
  background-color: var(--jp-layout-color0);
  font-size: 0.7rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.mljar-package-item.active .mljar-package-name,
.mljar-package-item.active .mljar-package-version {
  color: #fff;
}


.mljar-package-item:hover {
  background-color: var(--jp-layout-color2);
  cursor: pointer;
}

.mljar-package-item.active {
  background-color: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.mljar-package-name,
.mljar-package-version {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mljar-package-header-list {
  display: grid;
  grid-template-columns: 1fr 1fr 2rem;
  align-items: center;
  font-size: 0.85rem;
  padding-left: 8px;
  padding-right: 8px;
  padding-top: 10px;
  padding-bottom: 10px;
  border-bottom: 2px solid var(--jp-layout-color0);
  background-color: #0099cc;
  color: #fff;
}




/* list */



/* scrollbar */

.mljar-sidebar-container::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.mljar-sidebar-container::-webkit-scrollbar-track {
  background: #d3d3d3;
  border-radius: 8px;
}

.mljar-sidebar-container::-webkit-scrollbar-thumb {
  background-color: rgba(255, 255, 255, 0.6); 
  border-radius: 8px;
  border: 2px solid transparent;
  background-clip: padding-box;
}

.mljar-install-form-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0;
}


`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC;;AAED;;;;CAIC;;AAED,eAAe;;AAEf;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;EACnB,2BAA2B;EAC3B,kBAAkB;AACpB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,sBAAsB;EACtB,yCAAyC;EACzC,+BAA+B;EAC/B,yCAAyC;AAC3C;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;AACd;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,qBAAqB;EACrB,kBAAkB;EAClB,iBAAiB;EACjB,6BAA6B;AAC/B;;AAEA;EACE,MAAM;EACN,kBAAkB;EAClB,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;EAChB,mBAAmB;EACnB,SAAS;AACX;;AAEA;EACE,aAAa;EACb,qBAAqB;AACvB;;AAEA;EACE,gBAAgB;EAChB,WAAW;AACb;;AAEA;EACE,aAAa;EACb,SAAS;EACT,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;EACE,OAAO;EACP,kBAAkB;EAClB,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;EAChB,UAAU;EACV,SAAS;AACX;;;AAGA;EACE,UAAU;AACZ;;AAEA;EACE,oCAAoC;EACpC,kBAAkB;AACpB;;AAEA;EACE,qCAAqC;AACvC;;AAEA;EACE,yBAAyB;EACzB,aAAa;AACf;;;;AAIA,eAAe;;AAEf,YAAY;AACZ;;;EAGE,OAAO;EACP,iBAAiB;EACjB,eAAe;EACf,aAAa;EACb,iBAAiB;EACjB,mBAAmB;EACnB,uBAAuB;EACvB,+BAA+B;EAC/B,QAAQ;EACR,cAAc;EACd,YAAY;EACZ,kBAAkB;EAClB,gBAAgB;EAChB,eAAe;EACf,kBAAkB;EAClB,sCAAsC;AACxC;;AAEA;EACE,0BAA0B;EAC1B,kBAAkB;EAClB,kBAAkB;AACpB;;AAEA;;;EAGE,yBAAyB;EACzB,cAAc;AAChB;;;AAGA;;;;;;;;;;;;;;GAcG;;AAEH;EACE,kBAAkB;EAClB,gBAAgB;EAChB,kBAAkB;EAClB,YAAY;EACZ,eAAe;EACf,YAAY;EACZ,mBAAmB;EACnB,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;EACd,2BAA2B;AAC7B;;AAEA;EACE,2BAA2B;EAC3B,kBAAkB;EAClB,YAAY;EACZ,WAAW;EACX,2BAA2B;EAC3B,gBAAgB;EAChB,WAAW;EACX,gBAAgB;EAChB,kBAAkB;EAClB,mBAAmB;EACnB,gBAAgB;EAChB,WAAW;EACX,YAAY;AACd;;;AAGA;;;EAGE,yBAAyB;EACzB,mBAAmB;AACrB;;AAEA;;GAEG;;AAEH;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,yBAAyB;EACzB,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,iBAAiB;EACjB,eAAe;EACf,kBAAkB;EAClB,sCAAsC;AACxC;;AAEA;EACE,yBAAyB;EACzB,mBAAmB;AACrB;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,mBAAmB;AACrB;AACA,YAAY;;AAEZ,UAAU;;AAEV;;;EAGE,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,YAAY;AACd;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,cAAc;EACd,WAAW;EACX,YAAY;AACd;;;AAGA;EACE,kBAAkB;EAClB,qBAAqB;EACrB,eAAe;AACjB;;AAEA;EACE,oBAAoB;EACpB,mBAAmB;EACnB,cAAc;EACd,WAAW;EACX,WAAW;EACX,YAAY;AACd;;AAEA;EACE,kBAAkB;EAClB,YAAY;EACZ,yBAAyB;EACzB,YAAY;EACZ,kBAAkB;EAClB,kBAAkB;EAClB,YAAY;EACZ,kBAAkB;EAClB,YAAY;EACZ,SAAS;EACT,UAAU;EACV,UAAU;EACV,wBAAwB;EACxB,qBAAqB;AACvB;;AAEA;EACE,mBAAmB;EACnB,UAAU;AACZ;;AAEA,UAAU;;AAEV;EACE,aAAa;EACb,sBAAsB;EACtB,iBAAiB;AACnB;;AAEA;EACE,eAAe;EACf,kBAAkB;EAClB,UAAU;AACZ;;AAEA;EACE,kBAAkB;EAClB,kBAAkB;AACpB;;;AAGA;EACE,WAAW;EACX,YAAY;EACZ,sBAAsB;EACtB,yCAAyC;EACzC,+BAA+B;EAC/B,yCAAyC;EACzC,kBAAkB;AACpB;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,cAAc;EACd,iBAAiB;AACnB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,iBAAiB;AACnB;;;AAGA,YAAY;;AAEZ;EACE,aAAa;EACb,uBAAuB;EACvB,mBAAmB;EACnB,YAAY;EACZ,aAAa;AACf;;;AAGA;EACE,oCAAoC;EACpC,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,0BAA0B;EAC1B,kCAAkC;AACpC;;AAEA;EACE;IACE,yBAAyB;EAC3B;AACF;;AAEA,YAAY;;AAEZ,SAAS;;AAET;EACE,OAAO;EACP,aAAa;EACb,mCAAmC;EACnC,mBAAmB;EACnB,gBAAgB;EAChB,iBAAiB;EACjB,kBAAkB;EAClB,yCAAyC;EACzC,kBAAkB;EAClB,iBAAiB;EACjB,WAAW;EACX,sBAAsB;EACtB,yCAAyC;EACzC,iBAAiB;EACjB,wCAAwC;AAC1C;;AAEA;;EAEE,WAAW;AACb;;;AAGA;EACE,yCAAyC;EACzC,eAAe;AACjB;;AAEA;EACE,wCAAwC;EACxC,uCAAuC;AACzC;;AAEA;;EAEE,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,mCAAmC;EACnC,mBAAmB;EACnB,kBAAkB;EAClB,iBAAiB;EACjB,kBAAkB;EAClB,iBAAiB;EACjB,oBAAoB;EACpB,gDAAgD;EAChD,yBAAyB;EACzB,WAAW;AACb;;;;;AAKA,SAAS;;;;AAIT,cAAc;;AAEd;EACE,UAAU;EACV,WAAW;AACb;;AAEA;EACE,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;EACE,0CAA0C;EAC1C,kBAAkB;EAClB,6BAA6B;EAC7B,4BAA4B;AAC9B;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,UAAU;AACZ","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n\n/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n\n/* containers */\n\n.mljar-sidebar-container {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  overflow-y: auto;\n}\n\n.mljar-search-bar-container {\n  margin-bottom: 10px;\n  background-color: lightblue;\n  margin-right: 10px;\n}\n\n.mljar-search-bar-input {\n  width: 100%;\n  padding: 8px;\n  box-sizing: border-box;\n  background-color: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  border: 1px solid var(--jp-border-color2);\n}\n\n.mljar-search-bar-input::placeholder {\n  color: var(--jp-ui-font-color2);\n}\n\n.mljar-package-container {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n}\n\n.mljar-package-header-container {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-end;\n  margin-bottom: 8px;\n  margin-right: 8px;\n  border-bottom: 2px solid #ddd;\n}\n\n.mljar-package-header {\n  flex:4;\n  font-size: 0.85rem;\n  font-weight: 700;\n  color: var(--jp-ui-font-color1);\n  text-align: left;\n  padding-bottom: 8px;\n  margin: 0;\n}\n\n.mljar-logo-container {\n  display: flex;\n  align-items: flex-end;\n}\n\n.mljar-logo-container img {\n  max-height: 30px;\n  width: auto;\n}\n\n.mljar-actions-container {\n  display: flex;\n  gap: 10px;\n  margin-bottom: 10px;\n  margin-right: 10px;\n}\n\n.mljar-package-list-container {\n  flex: 1;\n  overflow-y: hidden;\n  padding-right: 10px;\n}\n\n.mljar-package-list {\n  list-style: none;\n  padding: 0;\n  margin: 0;\n}\n\n\n.mljar-package-list-container::-webkit-scrollbar {\n  width: 8px;\n}\n\n.mljar-package-list-container::-webkit-scrollbar-thumb {\n  background-color: rgba(0, 0, 0, 0.2);\n  border-radius: 4px;\n}\n\n.mljar-package-list-container::-webkit-scrollbar-track {\n  background-color: rgba(0, 0, 0, 0.05);\n}\n\n.mljar-plugin-sidebar-widget {\n  background-color: #ffffff;\n  padding: 10px;\n}\n\n\n\n/* containers */\n\n/* buttons */\n.mljar-back-button,\n.mljar-install-button,\n.mljar-refresh-button {\n  flex: 1;\n  text-align: right;\n  max-width: 30px;\n  display: flex;\n  margin-right: 1px;\n  align-items: center;\n  justify-content: center;\n  /* background-color: #0099cc; */\n  gap: 8px;\n  color: #0099cc;\n  border: none;\n  border-radius: 4px;\n  padding: 8px 0px;\n  cursor: pointer;\n  font-size: 0.75rem;\n  transition: background-color 0.3s ease;\n}\n\n.mljar-back-button {\n  max-width: 70px !important;\n  text-align: center;\n  padding-right: 4px;\n}\n\n.mljar-back-button:hover:not(:disabled),\n.mljar-refresh-button:hover:not(:disabled),\n.mljar-install-button:hover:not(:disabled) {\n  background-color: #0099cc;\n  color: #ffffff;\n}\n\n\n/* .mljar-back-button {\n  flex: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background-color: #0099cc;\n  gap: 8px;\n  color: white;\n  border: none;\n  border-radius: 4px;\n  padding: 8px 0px;\n  cursor: pointer;\n  font-size: 0.75rem;\n  transition: background-color 0.3s ease;\n} */\n\n.mljar-delete-button {\n  visibility: hidden;\n  background: none; \n  position: relative;\n  border: none;\n  cursor: pointer;\n  padding: 4px;\n  margin-bottom: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #dc3545;\n  transition: color 0.3s ease;\n}\n\n.mljar-delete-button[data-tooltip]:hover::after {\n  content: attr(data-tooltip);\n  position: absolute;\n  bottom: 110%;\n  left: -110%;\n  transform: translateX(-50%);\n  background: #333;\n  color: #fff;\n  padding: 5px 8px;\n  border-radius: 4px;\n  white-space: nowrap;\n  font-size: 0.8em;\n  z-index: 10;\n  opacity: 0.9;\n}\n\n\n.mljar-refresh-button:disabled,\n.mljar-install-button:disabled,\n.mljar-back-button:disabled {\n  background-color: #a0c4e3;\n  cursor: not-allowed;\n}\n\n/* .mljar-back-button:hover:not(:disabled) {\n  background-color: #005fa3;\n} */\n\n.mljar-install-submit-button {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background-color: #28a745;\n  color: white;\n  border: none;\n  border-radius: 4px;\n  padding: 8px 12px;\n  cursor: pointer;\n  font-size: 0.75rem;\n  transition: background-color 0.3s ease;\n}\n\n.mljar-install-submit-button:disabled {\n  background-color: #94d3a2;\n  cursor: not-allowed;\n}\n\n.mljar-install-submit-button:hover:not(:disabled) {\n  background-color: #1e7e34;\n}\n\n.mljar-delete-button:hover {\n  color: #a71d2a;\n}\n\n.mljar-package-item:hover .mljar-delete-button {\n  visibility: visible;\n}\n/* buttons */\n\n/* icons */\n\n.mljar-refresh-icon,\n.mljar-install-icon,\n.mljar-back-icon {\n  display: flex;\n  align-items: center;\n  width: 15px;\n  height: 15px;\n}\n\n.mljar-delete-icon {\n  width: 15px;\n  height: 15px;\n}\n\n.mljar-error-icon {\n  color: #dc3545;\n  width: 15px;\n  height: 15px;\n}\n\n\n.mljar-info-icon-container {\n  position: relative;\n  display: inline-block;\n  cursor: pointer;\n}\n\n.mljar-info-icon-container span:first-child {\n  display: inline-flex;\n  align-items: center;\n  color: #0099cc;\n  margin: 0px;\n  width: 18px;\n  height: 18px;\n}\n\n.mljar-info-icon-container .mljar-tooltip {\n  visibility: hidden;\n  width: 150px;\n  background-color: #28a745;\n  color: white;\n  text-align: center;\n  border-radius: 4px;\n  padding: 5px;\n  position: absolute;\n  left: -160px;\n  top: 100%;\n  z-index: 1;\n  opacity: 0;\n  transition: opacity 0.3s;\n  white-space: pre-line;\n}\n\n.mljar-info-icon-container:hover .mljar-tooltip {\n  visibility: visible;\n  opacity: 1;\n}\n\n/* icons */\n\n.mljar-install-form {\n  display: flex;\n  flex-direction: column;\n  margin-right: 8px;\n}\n\n.mljar-install-form h4 {\n  margin-top: 0px;\n  margin-bottom: 4px;\n  padding: 0;\n}\n\n.mljar-usage-span {\n  margin-bottom: 4px;\n  font-size: 0.55rem;\n}\n\n\n.mljar-install-input {\n  width: 100%;\n  padding: 8px;\n  box-sizing: border-box;\n  background-color: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  border: 1px solid var(--jp-border-color2);\n  margin-bottom: 8px;\n}\n\n.mljar-install-input::placeholder {\n  color: var(--jp-ui-font-color2);\n}\n\n.mljar-install-message {\n  color: #28a745;\n  font-weight: bold;\n}\n\n.mljar-install-message.error {\n  color: #dc3545;\n}\n\n.mljar-error-message {\n  color: #dc3545;\n  font-weight: bold;\n}\n\n\n/* spinner */\n\n.mljar-spinner-container {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 100%;\n  padding: 20px;\n}\n\n\n.mljar-spinner {\n  border: 4px solid rgba(0, 0, 0, 0.1);\n  width: 10px;\n  height: 10px;\n  border-radius: 50%;\n  border-left-color: #ffffff;\n  animation: spin 1s linear infinite;\n}\n\n@keyframes spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n/* spinner */\n\n/* list */\n\n.mljar-package-item {\n  flex: 1;\n  display: grid;\n  grid-template-columns: 1fr 1fr 2rem;\n  align-items: center;\n  column-gap: 1rem;\n  padding-left: 8px;\n  padding-right: 8px;\n  border: 1px solid var(--jp-border-color2);\n  margin-bottom: 0px;\n  margin-right: 0px;\n  width: 100%;\n  box-sizing: border-box;\n  background-color: var(--jp-layout-color0);\n  font-size: 0.7rem;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n}\n\n.mljar-package-item.active .mljar-package-name,\n.mljar-package-item.active .mljar-package-version {\n  color: #fff;\n}\n\n\n.mljar-package-item:hover {\n  background-color: var(--jp-layout-color2);\n  cursor: pointer;\n}\n\n.mljar-package-item.active {\n  background-color: var(--jp-brand-color1);\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n.mljar-package-name,\n.mljar-package-version {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.mljar-package-header-list {\n  display: grid;\n  grid-template-columns: 1fr 1fr 2rem;\n  align-items: center;\n  font-size: 0.85rem;\n  padding-left: 8px;\n  padding-right: 8px;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  border-bottom: 2px solid var(--jp-layout-color0);\n  background-color: #0099cc;\n  color: #fff;\n}\n\n\n\n\n/* list */\n\n\n\n/* scrollbar */\n\n.mljar-sidebar-container::-webkit-scrollbar {\n  width: 8px;\n  height: 8px;\n}\n\n.mljar-sidebar-container::-webkit-scrollbar-track {\n  background: #d3d3d3;\n  border-radius: 8px;\n}\n\n.mljar-sidebar-container::-webkit-scrollbar-thumb {\n  background-color: rgba(255, 255, 255, 0.6); \n  border-radius: 8px;\n  border: 2px solid transparent;\n  background-clip: padding-box;\n}\n\n.mljar-install-form-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 0;\n}\n\n\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ })

}]);
//# sourceMappingURL=style_index_js.84cba85b22b743361003.js.map