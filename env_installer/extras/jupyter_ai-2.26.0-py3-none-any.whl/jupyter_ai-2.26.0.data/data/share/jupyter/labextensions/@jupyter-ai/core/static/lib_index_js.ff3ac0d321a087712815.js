(self["webpackChunk_jupyter_ai_core"] = self["webpackChunk_jupyter_ai_core"] || []).push([["lib_index_js"],{

/***/ "../../node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**************************************************************************!*\
  !*** ../../node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**************************************************************************/
/***/ ((module) => {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}
module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../../node_modules/@mui/icons-material/Add.js":
/*!*****************************************************!*\
  !*** ../../node_modules/@mui/icons-material/Add.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "../../node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"
}), 'Add');

/***/ }),

/***/ "../../node_modules/@mui/icons-material/ArrowBack.js":
/*!***********************************************************!*\
  !*** ../../node_modules/@mui/icons-material/ArrowBack.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "../../node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20z"
}), 'ArrowBack');

/***/ }),

/***/ "../../node_modules/@mui/icons-material/KeyboardArrowDown.js":
/*!*******************************************************************!*\
  !*** ../../node_modules/@mui/icons-material/KeyboardArrowDown.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "../../node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z"
}), 'KeyboardArrowDown');

/***/ }),

/***/ "../../node_modules/@mui/icons-material/Send.js":
/*!******************************************************!*\
  !*** ../../node_modules/@mui/icons-material/Send.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "../../node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M2.01 21 23 12 2.01 3 2 10l15 2-15 2z"
}), 'Send');

/***/ }),

/***/ "../../node_modules/@mui/icons-material/Settings.js":
/*!**********************************************************!*\
  !*** ../../node_modules/@mui/icons-material/Settings.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "../../node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6"
}), 'Settings');

/***/ }),

/***/ "../../node_modules/@mui/icons-material/Stop.js":
/*!******************************************************!*\
  !*** ../../node_modules/@mui/icons-material/Stop.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "../../node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M6 6h12v12H6z"
}), 'Stop');

/***/ }),

/***/ "../../node_modules/@mui/icons-material/WarningAmber.js":
/*!**************************************************************!*\
  !*** ../../node_modules/@mui/icons-material/WarningAmber.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "../../node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "../../node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)([/*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M12 5.99 19.53 19H4.47zM12 2 1 21h22z"
}, "0"), /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M13 16h-2v2h2zm0-6h-2v5h2z"
}, "1")], 'WarningAmber');

/***/ }),

/***/ "../../node_modules/@mui/icons-material/utils/createSvgIcon.js":
/*!*********************************************************************!*\
  !*** ../../node_modules/@mui/icons-material/utils/createSvgIcon.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

'use client';

Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "default", ({
  enumerable: true,
  get: function () {
    return _utils.createSvgIcon;
  }
}));
var _utils = __webpack_require__(/*! @mui/material/utils */ "../../node_modules/@mui/material/utils/index.js");

/***/ }),

/***/ "../../node_modules/@mui/system/esm/Box/Box.js":
/*!*****************************************************!*\
  !*** ../../node_modules/@mui/system/esm/Box/Box.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "../../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/utils */ "../../node_modules/@mui/utils/ClassNameGenerator/ClassNameGenerator.js");
/* harmony import */ var _createBox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../createBox */ "../../node_modules/@mui/system/esm/createBox.js");
/* harmony import */ var _boxClasses__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./boxClasses */ "../../node_modules/@mui/system/esm/Box/boxClasses.js");
'use client';





const Box = (0,_createBox__WEBPACK_IMPORTED_MODULE_0__["default"])({
  defaultClassName: _boxClasses__WEBPACK_IMPORTED_MODULE_1__["default"].root,
  generateClassName: _mui_utils__WEBPACK_IMPORTED_MODULE_2__["default"].generate
});
 true ? Box.propTypes /* remove-proptypes */ = {
  // ┌────────────────────────────── Warning ──────────────────────────────┐
  // │ These PropTypes are generated from the TypeScript type definitions. │
  // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
  // └─────────────────────────────────────────────────────────────────────┘
  /**
   * @ignore
   */
  children: (prop_types__WEBPACK_IMPORTED_MODULE_3___default().node),
  /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */
  component: (prop_types__WEBPACK_IMPORTED_MODULE_3___default().elementType),
  /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */
  sx: prop_types__WEBPACK_IMPORTED_MODULE_3___default().oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_3___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_3___default().oneOfType([(prop_types__WEBPACK_IMPORTED_MODULE_3___default().func), (prop_types__WEBPACK_IMPORTED_MODULE_3___default().object), (prop_types__WEBPACK_IMPORTED_MODULE_3___default().bool)])), (prop_types__WEBPACK_IMPORTED_MODULE_3___default().func), (prop_types__WEBPACK_IMPORTED_MODULE_3___default().object)])
} : 0;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Box);

/***/ }),

/***/ "../../node_modules/@mui/system/esm/Box/boxClasses.js":
/*!************************************************************!*\
  !*** ../../node_modules/@mui/system/esm/Box/boxClasses.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/utils */ "../../node_modules/@mui/utils/generateUtilityClasses/generateUtilityClasses.js");

const boxClasses = (0,_mui_utils__WEBPACK_IMPORTED_MODULE_0__["default"])('MuiBox', ['root']);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (boxClasses);

/***/ }),

/***/ "./lib/chat_handler.js":
/*!*****************************!*\
  !*** ./lib/chat_handler.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatHandler: () => (/* binding */ ChatHandler)
/* harmony export */ });
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_2__);



const CHAT_SERVICE_URL = 'api/ai/chats';
class ChatHandler {
    /**
     * Create a new chat handler.
     */
    constructor(options = {}) {
        var _a;
        /**
         * ID of the connection. Requires `await initialize()`.
         */
        this.id = '';
        /**
         * Queue of Promise resolvers pushed onto by `send()`
         */
        this._sendResolverQueue = [];
        /**
         * Dictionary mapping message IDs to Promise resolvers, inserted into by
         * `replyFor()`.
         */
        this._replyForResolverDict = {};
        this._isDisposed = false;
        this._socket = null;
        this._listeners = [];
        /**
         * The list of chat messages
         */
        this._messages = [];
        this._pendingMessages = [];
        /**
         * Signal for when the chat history is changed. Components rendering the chat
         * history should subscribe to this signal and update their state when this
         * signal is triggered.
         */
        this._historyChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_2__.Signal(this);
        this.serverSettings =
            (_a = options.serverSettings) !== null && _a !== void 0 ? _a : _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeSettings();
    }
    /**
     * Initializes the WebSocket connection to the Chat backend. Promise is
     * resolved when server acknowledges connection and sends the client ID. This
     * must be awaited before calling any other method.
     */
    async initialize() {
        await this._initialize();
    }
    /**
     * Sends a message across the WebSocket. Promise resolves to the message ID
     * when the server sends the same message back, acknowledging receipt.
     */
    sendMessage(message) {
        return new Promise(resolve => {
            var _a;
            (_a = this._socket) === null || _a === void 0 ? void 0 : _a.send(JSON.stringify(message));
            this._sendResolverQueue.push(resolve);
        });
    }
    /**
     * Returns a Promise that resolves to the agent's reply, given the message ID
     * of the human message. Should only be called once per message.
     */
    replyFor(messageId) {
        return new Promise(resolve => {
            this._replyForResolverDict[messageId] = resolve;
        });
    }
    addListener(handler) {
        this._listeners.push(handler);
    }
    removeListener(handler) {
        const index = this._listeners.indexOf(handler);
        if (index > -1) {
            this._listeners.splice(index, 1);
        }
    }
    /**
     * Whether the chat handler is disposed.
     */
    get isDisposed() {
        return this._isDisposed;
    }
    /**
     * Dispose the chat handler.
     */
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this._isDisposed = true;
        this._listeners = [];
        // Clean up socket.
        const socket = this._socket;
        if (socket) {
            this._socket = null;
            socket.onopen = () => undefined;
            socket.onerror = () => undefined;
            socket.onmessage = () => undefined;
            socket.onclose = () => undefined;
            socket.close();
        }
    }
    get history() {
        return {
            messages: this._messages,
            pending_messages: this._pendingMessages
        };
    }
    get historyChanged() {
        return this._historyChanged;
    }
    _onMessage(newMessage) {
        var _a;
        // resolve promise from `sendMessage()`
        if (newMessage.type === 'human' && newMessage.client.id === this.id) {
            (_a = this._sendResolverQueue.shift()) === null || _a === void 0 ? void 0 : _a(newMessage.id);
        }
        // resolve promise from `replyFor()` if it exists
        if (newMessage.type === 'agent' &&
            newMessage.reply_to in this._replyForResolverDict) {
            this._replyForResolverDict[newMessage.reply_to](newMessage);
            delete this._replyForResolverDict[newMessage.reply_to];
        }
        // call listeners in serial
        this._listeners.forEach(listener => listener(newMessage));
        // append message to chat history. this block should always set `_messages`
        // or `_pendingMessages` to a new array instance rather than modifying
        // in-place so consumer React components re-render.
        switch (newMessage.type) {
            case 'connection':
                break;
            case 'clear':
                if (newMessage.targets) {
                    const targets = newMessage.targets;
                    this._messages = this._messages.filter(msg => !targets.includes(msg.id) &&
                        !('reply_to' in msg && targets.includes(msg.reply_to)));
                    this._pendingMessages = this._pendingMessages.filter(msg => !targets.includes(msg.reply_to));
                }
                else {
                    this._messages = [];
                    this._pendingMessages = [];
                }
                break;
            case 'pending':
                this._pendingMessages = [...this._pendingMessages, newMessage];
                break;
            case 'close-pending':
                this._pendingMessages = this._pendingMessages.filter(p => p.id !== newMessage.id);
                break;
            case 'agent-stream-chunk': {
                const target = newMessage.id;
                const streamMessage = this._messages.find((m) => m.type === 'agent-stream' && m.id === target);
                if (!streamMessage) {
                    console.error(`Received stream chunk with ID ${target}, but no agent-stream message with that ID exists. ` +
                        'Ignoring this stream chunk.');
                    break;
                }
                streamMessage.body += newMessage.content;
                streamMessage.metadata = newMessage.metadata;
                if (newMessage.stream_complete) {
                    streamMessage.complete = true;
                }
                this._messages = [...this._messages];
                break;
            }
            default:
                // human or agent chat message
                this._messages = [...this._messages, newMessage];
                break;
        }
        // finally, trigger `historyChanged` signal
        this._historyChanged.emit({
            messages: this._messages,
            pending_messages: this._pendingMessages
        });
    }
    _onClose(e, reject) {
        reject(new Error('Chat UI websocket disconnected'));
        console.error('Chat UI websocket disconnected');
        // only attempt re-connect if there was an abnormal closure
        // WebSocket status codes defined in RFC 6455: https://www.rfc-editor.org/rfc/rfc6455.html#section-7.4.1
        if (e.code === 1006) {
            const delaySeconds = 1;
            console.info(`Will try to reconnect in ${delaySeconds} s.`);
            setTimeout(async () => await this._initialize(), delaySeconds * 1000);
        }
    }
    _initialize() {
        return new Promise((resolve, reject) => {
            if (this.isDisposed) {
                return;
            }
            console.log('Creating a new websocket connection for chat...');
            const { token, WebSocket, wsUrl } = this.serverSettings;
            const url = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.join(wsUrl, CHAT_SERVICE_URL) +
                (token ? `?token=${encodeURIComponent(token)}` : '');
            const socket = (this._socket = new WebSocket(url));
            socket.onclose = e => this._onClose(e, reject);
            socket.onerror = e => reject(e);
            socket.onmessage = msg => msg.data && this._onMessage(JSON.parse(msg.data));
            const listenForConnection = (message) => {
                if (message.type !== 'connection') {
                    return;
                }
                this.id = message.client_id;
                // initialize chat history from `ConnectionMessage`
                this._messages = message.history.messages;
                this._pendingMessages = message.history.pending_messages;
                resolve();
                this.removeListener(listenForConnection);
            };
            this.addListener(listenForConnection);
        });
    }
}


/***/ }),

/***/ "./lib/completions/handler.js":
/*!************************************!*\
  !*** ./lib/completions/handler.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CompletionWebsocketHandler: () => (/* binding */ CompletionWebsocketHandler)
/* harmony export */ });
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_3__);




const SERVICE_URL = 'api/ai/completion/inline';
class CompletionWebsocketHandler {
    /**
     * Create a new completion handler.
     */
    constructor(options = {}) {
        var _a;
        /**
         * Dictionary mapping message IDs to Promise resolvers.
         */
        this._replyForResolver = {};
        this._isDisposed = false;
        this._socket = null;
        this._streamed = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this._initialized = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.PromiseDelegate();
        this.serverSettings =
            (_a = options.serverSettings) !== null && _a !== void 0 ? _a : _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    }
    /**
     * Initializes the WebSocket connection to the completion backend. Promise is
     * resolved when server acknowledges connection and sends the client ID. This
     * must be awaited before calling any other method.
     */
    async initialize() {
        await this._initialize();
    }
    /**
     * Sends a message across the WebSocket. Promise resolves to the message ID
     * when the server sends the same message back, acknowledging receipt.
     */
    sendMessage(message) {
        return new Promise(resolve => {
            var _a;
            (_a = this._socket) === null || _a === void 0 ? void 0 : _a.send(JSON.stringify(message));
            this._replyForResolver[message.number] = resolve;
        });
    }
    /**
     * Signal emitted when a new chunk of completion is streamed.
     */
    get streamed() {
        return this._streamed;
    }
    /**
     * Whether the completion handler is disposed.
     */
    get isDisposed() {
        return this._isDisposed;
    }
    /**
     * Dispose the completion handler.
     */
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this._isDisposed = true;
        // Clean up socket.
        const socket = this._socket;
        if (socket) {
            this._socket = null;
            socket.onopen = () => undefined;
            socket.onerror = () => undefined;
            socket.onmessage = () => undefined;
            socket.onclose = () => undefined;
            socket.close();
        }
    }
    _onMessage(message) {
        switch (message.type) {
            case 'connection': {
                this._initialized.resolve();
                break;
            }
            case 'stream': {
                this._streamed.emit(message);
                break;
            }
            default: {
                if (message.reply_to in this._replyForResolver) {
                    this._replyForResolver[message.reply_to](message);
                    delete this._replyForResolver[message.reply_to];
                }
                else {
                    console.warn('Unhandled message', message);
                }
                break;
            }
        }
    }
    _onClose(e, reject) {
        reject(new Error('Inline completion websocket disconnected'));
        console.error('Inline completion websocket disconnected');
        // only attempt re-connect if there was an abnormal closure
        // WebSocket status codes defined in RFC 6455: https://www.rfc-editor.org/rfc/rfc6455.html#section-7.4.1
        if (e.code === 1006) {
            const delaySeconds = 1;
            console.info(`Will try to reconnect in ${delaySeconds} s.`);
            setTimeout(async () => await this._initialize(), delaySeconds * 1000);
        }
    }
    async _initialize() {
        if (this.isDisposed) {
            return;
        }
        const promise = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.PromiseDelegate();
        this._initialized = promise;
        console.log('Creating a new websocket connection for inline completions...');
        const { token, WebSocket, wsUrl } = this.serverSettings;
        const url = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.URLExt.join(wsUrl, SERVICE_URL) +
            (token ? `?token=${encodeURIComponent(token)}` : '');
        const socket = (this._socket = new WebSocket(url));
        socket.onclose = e => this._onClose(e, promise.reject.bind(promise));
        socket.onerror = e => promise.reject(e);
        socket.onmessage = msg => msg.data && this._onMessage(JSON.parse(msg.data));
    }
}


/***/ }),

/***/ "./lib/completions/plugin.js":
/*!***********************************!*\
  !*** ./lib/completions/plugin.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CommandIDs: () => (/* binding */ CommandIDs),
/* harmony export */   completionPlugin: () => (/* binding */ completionPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/completer */ "webpack/sharing/consume/default/@jupyterlab/completer");
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _selection_watcher__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../selection-watcher */ "./lib/selection-watcher.js");
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../tokens */ "./lib/tokens.js");
/* harmony import */ var _provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./provider */ "./lib/completions/provider.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./handler */ "./lib/completions/handler.js");







var CommandIDs;
(function (CommandIDs) {
    /**
     * Command to toggle completions globally.
     */
    CommandIDs.toggleCompletions = 'jupyter-ai:toggle-completions';
    /**
     * Command to toggle completions for specific language.
     */
    CommandIDs.toggleLanguageCompletions = 'jupyter-ai:toggle-language-completions';
})(CommandIDs || (CommandIDs = {}));
const INLINE_COMPLETER_PLUGIN = '@jupyterlab/completer-extension:inline-completer';
const completionPlugin = {
    id: '@jupyter-ai/core:inline-completions',
    autoStart: true,
    requires: [
        _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__.ICompletionProviderManager,
        _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__.IEditorLanguageRegistry,
        _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__.ISettingRegistry
    ],
    optional: [_tokens__WEBPACK_IMPORTED_MODULE_3__.IJaiStatusItem],
    provides: _tokens__WEBPACK_IMPORTED_MODULE_3__.IJaiCompletionProvider,
    activate: async (app, completionManager, languageRegistry, settingRegistry, statusItem) => {
        if (typeof completionManager.registerInlineProvider === 'undefined') {
            // Gracefully short-circuit on JupyterLab 4.0 and Notebook 7.0
            console.warn('Inline completions are only supported in JupyterLab 4.1+ and Jupyter Notebook 7.1+');
            return null;
        }
        const completionHandler = new _handler__WEBPACK_IMPORTED_MODULE_4__.CompletionWebsocketHandler();
        const provider = new _provider__WEBPACK_IMPORTED_MODULE_5__.JaiInlineProvider({
            completionHandler,
            languageRegistry
        });
        await completionHandler.initialize();
        completionManager.registerInlineProvider(provider);
        const findCurrentLanguage = () => {
            const widget = app.shell.currentWidget;
            const editor = (0,_selection_watcher__WEBPACK_IMPORTED_MODULE_6__.getEditor)(widget);
            if (!editor) {
                return null;
            }
            return languageRegistry.findByMIME(editor.model.mimeType);
        };
        // ic := inline completion
        async function getIcSettings() {
            return (await settingRegistry.load(INLINE_COMPLETER_PLUGIN));
        }
        /**
         * Gets the composite settings for the Jupyter AI inline completion provider
         * (JaiIcp).
         *
         * This reads from the `ISettings.composite` property, which merges the user
         * settings with the provider defaults, defined in
         * `JaiInlineProvider.DEFAULT_SETTINGS`.
         */
        async function getJaiIcpSettings() {
            const icSettings = await getIcSettings();
            return icSettings.composite.providers[_provider__WEBPACK_IMPORTED_MODULE_5__.JaiInlineProvider.ID];
        }
        /**
         * Updates the JaiIcp user settings.
         */
        async function updateJaiIcpSettings(newJaiIcpSettings) {
            const icSettings = await getIcSettings();
            const oldUserIcpSettings = icSettings.user.providers;
            const newUserIcpSettings = {
                ...oldUserIcpSettings,
                [_provider__WEBPACK_IMPORTED_MODULE_5__.JaiInlineProvider.ID]: {
                    ...oldUserIcpSettings === null || oldUserIcpSettings === void 0 ? void 0 : oldUserIcpSettings[_provider__WEBPACK_IMPORTED_MODULE_5__.JaiInlineProvider.ID],
                    ...newJaiIcpSettings
                }
            };
            icSettings.set('providers', newUserIcpSettings);
        }
        app.commands.addCommand(CommandIDs.toggleCompletions, {
            execute: async () => {
                const jaiIcpSettings = await getJaiIcpSettings();
                updateJaiIcpSettings({
                    enabled: !jaiIcpSettings.enabled
                });
            },
            label: 'Enable completions by Jupyternaut',
            isToggled: () => {
                return provider.isEnabled();
            }
        });
        app.commands.addCommand(CommandIDs.toggleLanguageCompletions, {
            execute: async () => {
                const jaiIcpSettings = await getJaiIcpSettings();
                const language = findCurrentLanguage();
                if (!language) {
                    return;
                }
                const disabledLanguages = [...jaiIcpSettings.disabledLanguages];
                const newDisabledLanguages = disabledLanguages.includes(language.name)
                    ? disabledLanguages.filter(l => l !== language.name)
                    : disabledLanguages.concat(language.name);
                updateJaiIcpSettings({
                    disabledLanguages: newDisabledLanguages
                });
            },
            label: () => {
                const language = findCurrentLanguage();
                return language
                    ? `Disable completions in ${(0,_provider__WEBPACK_IMPORTED_MODULE_5__.displayName)(language)}`
                    : 'Disable completions in <language> files';
            },
            isToggled: () => {
                const language = findCurrentLanguage();
                return !!language && !provider.isLanguageEnabled(language.name);
            },
            isVisible: () => {
                const language = findCurrentLanguage();
                return !!language;
            },
            isEnabled: () => {
                const language = findCurrentLanguage();
                return !!language && provider.isEnabled();
            }
        });
        if (statusItem) {
            statusItem.addItem({
                command: CommandIDs.toggleCompletions,
                rank: 1
            });
            statusItem.addItem({
                command: CommandIDs.toggleLanguageCompletions,
                rank: 2
            });
        }
        return provider;
    }
};


/***/ }),

/***/ "./lib/completions/provider.js":
/*!*************************************!*\
  !*** ./lib/completions/provider.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JaiInlineProvider: () => (/* binding */ JaiInlineProvider),
/* harmony export */   displayName: () => (/* binding */ displayName)
/* harmony export */ });
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/completer */ "webpack/sharing/consume/default/@jupyterlab/completer");
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../icons */ "./lib/icons.js");







/**
 * Format the language name nicely.
 */
function displayName(language) {
    var _a;
    if (language.name === 'ipythongfm') {
        return 'Markdown (IPython)';
    }
    if (language.name === 'ipython') {
        return 'IPython';
    }
    return (_a = language.displayName) !== null && _a !== void 0 ? _a : language.name;
}
class JaiInlineProvider {
    constructor(options) {
        this.options = options;
        this.identifier = JaiInlineProvider.ID;
        this.icon = _icons__WEBPACK_IMPORTED_MODULE_6__.jupyternautIcon.bindprops({ width: 16, top: 1 });
        this._settings = JaiInlineProvider.DEFAULT_SETTINGS;
        this._settingsChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this._streamPromises = new Map();
        this._counter = 0;
        options.completionHandler.streamed.connect(this._receiveStreamChunk, this);
    }
    get name() {
        return 'JupyterAI';
    }
    async fetch(request, context) {
        var _a, _b, _c;
        const allowedTriggerKind = this._settings.triggerKind;
        const triggerKind = context.triggerKind;
        if (allowedTriggerKind === 'manual' &&
            triggerKind !== _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__.InlineCompletionTriggerKind.Invoke) {
            // Short-circuit if user requested to only invoke inline completions
            // on manual trigger for jupyter-ai. Users may still get completions
            // from other (e.g. less expensive or faster) providers.
            return { items: [] };
        }
        const mime = (_a = request.mimeType) !== null && _a !== void 0 ? _a : 'text/plain';
        const language = this.options.languageRegistry.findByMIME(mime);
        if (!language) {
            console.warn(`Could not recognise language for ${mime} - cannot complete`);
            return { items: [] };
        }
        if (!this.isLanguageEnabled(language === null || language === void 0 ? void 0 : language.name)) {
            // Do not offer suggestions if disabled.
            return { items: [] };
        }
        let cellId = undefined;
        let path = (_b = context.session) === null || _b === void 0 ? void 0 : _b.path;
        if (context.widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_4__.NotebookPanel) {
            const activeCell = context.widget.content.activeCell;
            if (activeCell) {
                cellId = activeCell.model.id;
            }
        }
        if (!path && context.widget instanceof _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_5__.DocumentWidget) {
            path = context.widget.context.path;
        }
        const number = ++this._counter;
        const streamPreference = this._settings.streaming;
        const stream = streamPreference === 'always'
            ? true
            : streamPreference === 'never'
                ? false
                : context.triggerKind === _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__.InlineCompletionTriggerKind.Invoke;
        if (stream) {
            // Reset stream promises handler
            this._streamPromises.clear();
        }
        const result = await this.options.completionHandler.sendMessage({
            path: (_c = context.session) === null || _c === void 0 ? void 0 : _c.path,
            mime,
            prefix: this._prefixFromRequest(request),
            suffix: this._suffixFromRequest(request),
            language: this._resolveLanguage(language),
            number,
            stream,
            cell_id: cellId
        });
        const error = result.error;
        if (error) {
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.emit(`Inline completion failed: ${error.type}`, 'error', {
                autoClose: false,
                actions: [
                    {
                        label: 'Show Traceback',
                        callback: () => {
                            (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Inline completion failed on the server side', {
                                message: error.traceback
                            });
                        }
                    }
                ]
            });
            throw new Error(`Inline completion failed: ${error.type}\n${error.traceback}`);
        }
        return result.list;
    }
    /**
     * Stream a reply for completion identified by given `token`.
     */
    async *stream(token) {
        let done = false;
        while (!done) {
            const delegate = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_2__.PromiseDelegate();
            this._streamPromises.set(token, delegate);
            const promise = delegate.promise;
            yield promise;
            done = (await promise).done;
        }
    }
    get schema() {
        const knownLanguages = this.options.languageRegistry.getLanguages();
        return {
            properties: {
                triggerKind: {
                    title: 'Inline completions trigger',
                    type: 'string',
                    oneOf: [
                        { const: 'any', title: 'Automatic (on typing or invocation)' },
                        { const: 'manual', title: 'Only when invoked manually' }
                    ],
                    description: 'When to trigger inline completions when using jupyter-ai.'
                },
                maxPrefix: {
                    title: 'Maximum prefix length',
                    minimum: 1,
                    type: 'number',
                    description: 'At most how many prefix characters should be provided to the model.'
                },
                maxSuffix: {
                    title: 'Maximum suffix length',
                    minimum: 0,
                    type: 'number',
                    description: 'At most how many suffix characters should be provided to the model.'
                },
                disabledLanguages: {
                    title: 'Disabled languages',
                    type: 'array',
                    items: {
                        type: 'string',
                        oneOf: knownLanguages.map(language => {
                            return { const: language.name, title: displayName(language) };
                        })
                    },
                    description: 'Languages for which the completions should not be shown.'
                },
                streaming: {
                    title: 'Streaming',
                    type: 'string',
                    oneOf: [
                        { const: 'always', title: 'Always' },
                        { const: 'manual', title: 'When invoked manually' },
                        { const: 'never', title: 'Never' }
                    ],
                    description: 'Whether to show suggestions as they are generated'
                }
            },
            default: JaiInlineProvider.DEFAULT_SETTINGS
        };
    }
    async configure(settings) {
        this._settings = settings;
        this._settingsChanged.emit();
    }
    isEnabled() {
        return this._settings.enabled;
    }
    isLanguageEnabled(language) {
        return !this._settings.disabledLanguages.includes(language);
    }
    get settingsChanged() {
        return this._settingsChanged;
    }
    /**
     * Process the stream chunk to make it available in the awaiting generator.
     */
    _receiveStreamChunk(_emitter, chunk) {
        const token = chunk.response.token;
        if (!token) {
            throw Error('Stream chunks must return define `token` in `response`');
        }
        const delegate = this._streamPromises.get(token);
        if (!delegate) {
            console.warn('Unhandled stream chunk');
        }
        else {
            delegate.resolve(chunk);
            if (chunk.done) {
                this._streamPromises.delete(token);
            }
        }
    }
    /**
     * Extract prefix from request, accounting for context window limit.
     */
    _prefixFromRequest(request) {
        const textBefore = request.text.slice(0, request.offset);
        const prefix = textBefore.slice(-Math.min(this._settings.maxPrefix, textBefore.length));
        return prefix;
    }
    /**
     * Extract suffix from request, accounting for context window limit.
     */
    _suffixFromRequest(request) {
        const textAfter = request.text.slice(request.offset);
        const prefix = textAfter.slice(0, Math.min(this._settings.maxPrefix, textAfter.length));
        return prefix;
    }
    _resolveLanguage(language) {
        if (!language) {
            return 'plain English';
        }
        if (language.name === 'ipython') {
            return 'python';
        }
        else if (language.name === 'ipythongfm') {
            return 'markdown';
        }
        return language.name;
    }
}
(function (JaiInlineProvider) {
    JaiInlineProvider.ID = '@jupyterlab/jupyter-ai';
    JaiInlineProvider.DEFAULT_SETTINGS = {
        triggerKind: 'any',
        maxPrefix: 10000,
        maxSuffix: 10000,
        // The debouncer delay handling is implemented upstream in JupyterLab;
        // here we just increase the default from 0, as compared to kernel history
        // the external AI models may have a token cost associated.
        debouncerDelay: 250,
        enabled: false,
        // ipythongfm means "IPython GitHub Flavoured Markdown"
        disabledLanguages: ['ipythongfm'],
        streaming: 'manual'
    };
})(JaiInlineProvider || (JaiInlineProvider = {}));


/***/ }),

/***/ "./lib/components/chat-input.js":
/*!**************************************!*\
  !*** ./lib/components/chat-input.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatInput: () => (/* binding */ ChatInput)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material */ "webpack/sharing/consume/default/@mui/icons-material/@mui/icons-material");
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../handler */ "./lib/handler.js");
/* harmony import */ var _chat_input_send_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./chat-input/send-button */ "./lib/components/chat-input/send-button.js");
/* harmony import */ var _contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../contexts/active-cell-context */ "./lib/contexts/active-cell-context.js");






/**
 * List of icons per slash command, shown in the autocomplete popup.
 *
 * This list of icons should eventually be made configurable. However, it is
 * unclear whether custom icons should be defined within a Lumino plugin (in the
 * frontend) or served from a static server route (in the backend).
 */
const DEFAULT_COMMAND_ICONS = {
    '/ask': react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.FindInPage, null),
    '/clear': react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.HideSource, null),
    '/export': react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.Download, null),
    '/fix': react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.AutoFixNormal, null),
    '/generate': react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.MenuBook, null),
    '/help': react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.Help, null),
    '/learn': react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.School, null),
    '@file': react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.FindInPage, null),
    unknown: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.MoreHoriz, null)
};
/**
 * Renders an option shown in the slash command autocomplete.
 */
function renderAutocompleteOption(optionProps, option) {
    const icon = option.id in DEFAULT_COMMAND_ICONS
        ? DEFAULT_COMMAND_ICONS[option.id]
        : DEFAULT_COMMAND_ICONS.unknown;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", { ...optionProps },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { lineHeight: 0, marginRight: 4, opacity: 0.618 } }, icon),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { flexGrow: 1 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { component: "span", sx: {
                    fontSize: 'var(--jp-ui-font-size1)'
                } }, option.label),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { component: "span", sx: { opacity: 0.618, fontSize: 'var(--jp-ui-font-size0)' } }, ' — ' + option.description))));
}
function ChatInput(props) {
    const [input, setInput] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [autocompleteOptions, setAutocompleteOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [autocompleteCommandOptions, setAutocompleteCommandOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [autocompleteArgOptions, setAutocompleteArgOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [currSlashCommand, setCurrSlashCommand] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const activeCell = (0,_contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_3__.useActiveCellContext)();
    /**
     * Effect: fetch the list of available slash commands from the backend on
     * initial mount to populate the slash command autocomplete.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        async function getAutocompleteCommandOptions() {
            const response = await _handler__WEBPACK_IMPORTED_MODULE_4__.AiService.listAutocompleteOptions();
            setAutocompleteCommandOptions(response.options);
        }
        getAutocompleteCommandOptions();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        async function getAutocompleteArgOptions() {
            let options = [];
            const lastWord = getLastWord(input);
            if (lastWord.includes(':')) {
                const id = lastWord.split(':', 1)[0];
                // get option that matches the command
                const option = autocompleteCommandOptions.find(option => option.id === id);
                if (option) {
                    const response = await _handler__WEBPACK_IMPORTED_MODULE_4__.AiService.listAutocompleteArgOptions(lastWord);
                    options = response.options;
                }
            }
            setAutocompleteArgOptions(options);
        }
        getAutocompleteArgOptions();
    }, [autocompleteCommandOptions, input]);
    // Combine the fixed options with the argument options
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (autocompleteArgOptions.length > 0) {
            setAutocompleteOptions(autocompleteArgOptions);
        }
        else {
            setAutocompleteOptions(autocompleteCommandOptions);
        }
    }, [autocompleteCommandOptions, autocompleteArgOptions]);
    // whether any option is highlighted in the autocomplete
    const [highlighted, setHighlighted] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // controls whether the autocomplete is open
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // store reference to the input element to enable focusing it easily
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    /**
     * Effect: connect the signal emitted on input focus request.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const focusInputElement = () => {
            if (inputRef.current) {
                inputRef.current.focus();
            }
        };
        props.focusInputSignal.connect(focusInputElement);
        return () => {
            props.focusInputSignal.disconnect(focusInputElement);
        };
    }, []);
    /**
     * Effect: Open the autocomplete when the user types a slash into an empty
     * chat input. Close the autocomplete when the user clears the chat input.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (filterAutocompleteOptions(autocompleteOptions, input).length > 0) {
            setOpen(true);
            return;
        }
        if (input === '') {
            setOpen(false);
            return;
        }
    }, [input]);
    /**
     * Effect: Set current slash command
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const matchedSlashCommand = input.match(/^\s*\/\w+/);
        setCurrSlashCommand(matchedSlashCommand && matchedSlashCommand[0]);
    }, [input]);
    /**
     * Effect: ensure that the `highlighted` is never `true` when `open` is
     * `false`.
     *
     * For context: https://github.com/jupyterlab/jupyter-ai/issues/849
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!open && highlighted) {
            setHighlighted(false);
        }
    }, [open, highlighted]);
    function onSend(selection) {
        const prompt = input;
        setInput('');
        // if the current slash command is `/fix`, we always include a code cell
        // with error output in the selection.
        if (currSlashCommand === '/fix') {
            const cellWithError = activeCell.manager.getContent(true);
            if (!cellWithError) {
                return;
            }
            props.chatHandler.sendMessage({
                prompt,
                selection: { ...cellWithError, type: 'cell-with-error' }
            });
            return;
        }
        // otherwise, send a ChatRequest with the prompt and selection
        props.chatHandler.sendMessage({ prompt, selection });
    }
    const inputExists = !!input.trim();
    function handleKeyDown(event) {
        if (event.key !== 'Enter') {
            return;
        }
        // do not send the message if the user was just trying to select a suggested
        // slash command from the Autocomplete component.
        if (highlighted) {
            return;
        }
        if (!inputExists) {
            event.stopPropagation();
            event.preventDefault();
            return;
        }
        if (event.key === 'Enter' &&
            ((props.sendWithShiftEnter && event.shiftKey) ||
                (!props.sendWithShiftEnter && !event.shiftKey))) {
            onSend();
            event.stopPropagation();
            event.preventDefault();
        }
    }
    // Set the helper text based on whether Shift+Enter is used for sending.
    const helperText = props.sendWithShiftEnter ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        "Press ",
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("b", null, "Shift"),
        "+",
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("b", null, "Enter"),
        " to send message")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        "Press ",
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("b", null, "Shift"),
        "+",
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("b", null, "Enter"),
        " to add a new line"));
    const sendButtonProps = {
        onSend,
        onStop: () => {
            props.chatHandler.sendMessage({
                type: 'stop'
            });
        },
        streamingReplyHere: props.streamingReplyHere,
        sendWithShiftEnter: props.sendWithShiftEnter,
        inputExists,
        activeCellHasError: activeCell.hasError,
        currSlashCommand
    };
    function filterAutocompleteOptions(options, inputValue) {
        const lastWord = getLastWord(inputValue);
        if (lastWord === '') {
            return [];
        }
        const isStart = lastWord === inputValue;
        return options.filter(option => option.label.startsWith(lastWord) && (!option.only_start || isStart));
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: props.sx },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Autocomplete, { autoHighlight: true, freeSolo: true, inputValue: input, filterOptions: (options, { inputValue }) => {
                return filterAutocompleteOptions(options, inputValue);
            }, onChange: (_, option) => {
                const value = typeof option === 'string' ? option : option.label;
                let matchLength = 0;
                for (let i = 1; i <= value.length; i++) {
                    if (input.endsWith(value.slice(0, i))) {
                        matchLength = i;
                    }
                }
                setInput(input + value.slice(matchLength));
            }, onInputChange: (_, newValue) => {
                setInput(newValue);
            }, onHighlightChange: 
            /**
             * On highlight change: set `highlighted` to whether an option is
             * highlighted by the user.
             */
            (_, highlightedOption) => {
                setHighlighted(!!highlightedOption);
            }, onClose: (_, reason) => {
                if (reason !== 'selectOption' || input.endsWith(' ')) {
                    setOpen(false);
                }
            }, 
            // set this to an empty string to prevent the last selected slash
            // command from being shown in blue
            value: "", open: open, options: autocompleteOptions, 
            // hide default extra right padding in the text field
            disableClearable: true, 
            // ensure the autocomplete popup always renders on top
            componentsProps: {
                popper: {
                    placement: 'top'
                },
                paper: {
                    sx: {
                        border: '1px solid lightgray'
                    }
                }
            }, renderOption: renderAutocompleteOption, ListboxProps: {
                sx: {
                    '& .MuiAutocomplete-option': {
                        padding: 2
                    }
                }
            }, renderInput: params => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { ...params, fullWidth: true, variant: "outlined", maxRows: 20, multiline: true, placeholder: `Ask ${props.personaName}`, onKeyDown: handleKeyDown, inputRef: inputRef, InputProps: {
                    ...params.InputProps,
                    endAdornment: (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputAdornment, { position: "end", sx: { height: 'unset', alignSelf: 'flex-end' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_chat_input_send_button__WEBPACK_IMPORTED_MODULE_5__.SendButton, { ...sendButtonProps })))
                }, FormHelperTextProps: {
                    sx: { marginLeft: 'auto', marginRight: 0 }
                }, helperText: input.length > 2 ? helperText : ' ' })) })));
}
function getLastWord(input) {
    return input.split(/(?<!\\)\s+/).pop() || '';
}


/***/ }),

/***/ "./lib/components/chat-input/send-button.js":
/*!**************************************************!*\
  !*** ./lib/components/chat-input/send-button.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SendButton: () => (/* binding */ SendButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/icons-material/KeyboardArrowDown */ "../../node_modules/@mui/icons-material/KeyboardArrowDown.js");
/* harmony import */ var _mui_icons_material_Send__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/icons-material/Send */ "../../node_modules/@mui/icons-material/Send.js");
/* harmony import */ var _mui_icons_material_Stop__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/icons-material/Stop */ "../../node_modules/@mui/icons-material/Stop.js");
/* harmony import */ var _mui_extras_tooltipped_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../mui-extras/tooltipped-button */ "./lib/components/mui-extras/tooltipped-button.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../contexts/active-cell-context */ "./lib/contexts/active-cell-context.js");
/* harmony import */ var _contexts_selection_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../contexts/selection-context */ "./lib/contexts/selection-context.js");
/* harmony import */ var _contexts_all_notebook_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../contexts/all-notebook-context */ "./lib/contexts/all-notebook-context.js");










const FIX_TOOLTIP = '/fix requires an active code cell with an error';
function SendButton(props) {
    const [menuAnchorEl, setMenuAnchorEl] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [menuOpen, setMenuOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [textSelection] = (0,_contexts_selection_context__WEBPACK_IMPORTED_MODULE_2__.useSelectionContext)();
    const [notebookSelection] = (0,_contexts_all_notebook_context__WEBPACK_IMPORTED_MODULE_3__.useNotebookSelectionContext)();
    const activeCell = (0,_contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_4__.useActiveCellContext)();
    const openMenu = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((el) => {
        setMenuAnchorEl(el);
        setMenuOpen(true);
    }, []);
    const closeMenu = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        setMenuOpen(false);
    }, []);
    let action = props.inputExists
        ? 'send'
        : props.streamingReplyHere
            ? 'stop'
            : 'send';
    if (props.currSlashCommand === '/fix') {
        action = 'fix';
    }
    let disabled = false;
    if (action === 'send' && !props.inputExists) {
        disabled = true;
    }
    if (action === 'fix' && !props.activeCellHasError) {
        disabled = true;
    }
    const includeSelectionDisabled = !(activeCell.exists || textSelection);
    const includeSelectionTooltip = action === 'fix'
        ? FIX_TOOLTIP
        : textSelection
            ? `${textSelection.text.split('\n').length} lines selected`
            : activeCell.exists
                ? 'Code from 1 active cell'
                : 'No selection or active cell';
    const defaultTooltip = props.sendWithShiftEnter
        ? 'Send message (SHIFT+ENTER)'
        : 'Send message (ENTER)';
    const tooltip = action === 'fix' && !props.activeCellHasError
        ? FIX_TOOLTIP
        : action === 'stop'
            ? 'Stop streaming'
            : !props.inputExists
                ? 'Message must not be empty'
                : defaultTooltip;
    function sendWithNotebook() {
        if (Array.isArray(notebookSelection) && notebookSelection.every(item => item.text)) {
            const combinedText = notebookSelection
                .map(item => `[CELL]\n${item.text}`)
                .join('\n');
            props.onSend({
                type: 'text',
                source: combinedText
            });
            closeMenu();
            return;
        }
        closeMenu();
    }
    function sendWithSelection() {
        // if the current slash command is `/fix`, `props.onSend()` should always
        // include the code cell with error output, so the `selection` argument does
        // not need to be defined.
        if (action === 'fix') {
            props.onSend();
            closeMenu();
            return;
        }
        // otherwise, parse the text selection or active cell, with the text
        // selection taking precedence.
        if (textSelection === null || textSelection === void 0 ? void 0 : textSelection.text) {
            props.onSend({
                type: 'text',
                source: textSelection.text
            });
            closeMenu();
            return;
        }
        if (activeCell.exists) {
            props.onSend({
                type: 'cell',
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                source: activeCell.manager.getContent(false).source
            });
            closeMenu();
            return;
        }
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { display: 'flex', flexWrap: 'nowrap' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_tooltipped_button__WEBPACK_IMPORTED_MODULE_5__.TooltippedButton, { onClick: () => (action === 'stop' ? props.onStop() : props.onSend()), disabled: disabled, tooltip: tooltip, buttonProps: {
                size: 'small',
                title: defaultTooltip,
                variant: 'contained'
            }, sx: {
                minWidth: 'unset',
                borderRadius: '2px 0px 0px 2px'
            } }, action === 'stop' ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Stop__WEBPACK_IMPORTED_MODULE_6__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Send__WEBPACK_IMPORTED_MODULE_7__["default"], null)),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_tooltipped_button__WEBPACK_IMPORTED_MODULE_5__.TooltippedButton, { onClick: e => {
                openMenu(e.currentTarget);
            }, disabled: disabled, tooltip: "", buttonProps: {
                variant: 'contained',
                onKeyDown: e => {
                    if (e.key !== 'Enter' && e.key !== ' ') {
                        return;
                    }
                    openMenu(e.currentTarget);
                    // stopping propagation of this event prevents the prompt from being
                    // sent when the dropdown button is selected and clicked via 'Enter'.
                    e.stopPropagation();
                }
            }, sx: {
                minWidth: 'unset',
                padding: '4px 0px',
                borderRadius: '0px 2px 2px 0px',
                borderLeft: '1px solid white'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_8__["default"], null)),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Menu, { open: menuOpen, onClose: closeMenu, anchorEl: menuAnchorEl, anchorOrigin: {
                vertical: 'top',
                horizontal: 'right'
            }, transformOrigin: {
                vertical: 'bottom',
                horizontal: 'right'
            }, sx: {
                '& .MuiMenuItem-root': {
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                },
                '& svg': {
                    lineHeight: 0
                }
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { onClick: e => {
                    sendWithSelection();
                    // prevent sending second message with no selection
                    e.stopPropagation();
                }, disabled: includeSelectionDisabled },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_9__.includeSelectionIcon.react, null),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { display: "block" }, "Send message with selection"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { display: "block", sx: { opacity: 0.618 } }, includeSelectionTooltip))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { onClick: e => {
                    sendWithNotebook();
                    e.stopPropagation();
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_9__.includeSelectionIcon.react, null),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { display: "block" }, "Send all notebook"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { display: "block", sx: { opacity: 0.618 } }, "Sending to AI all notebook."))))));
}


/***/ }),

/***/ "./lib/components/chat-messages.js":
/*!*****************************************!*\
  !*** ./lib/components/chat-messages.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatMessageHeader: () => (/* binding */ ChatMessageHeader),
/* harmony export */   ChatMessages: () => (/* binding */ ChatMessages)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _rendermime_markdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./rendermime-markdown */ "./lib/components/rendermime-markdown.js");
/* harmony import */ var _contexts_collaborators_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../contexts/collaborators-context */ "./lib/contexts/collaborators-context.js");
/* harmony import */ var _chat_messages_chat_message_menu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./chat-messages/chat-message-menu */ "./lib/components/chat-messages/chat-message-menu.js");
/* harmony import */ var _chat_messages_chat_message_delete__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./chat-messages/chat-message-delete */ "./lib/components/chat-messages/chat-message-delete.js");







function sortMessages(messages) {
    const timestampsById = {};
    for (const message of messages) {
        timestampsById[message.id] = message.time;
    }
    return [...messages].sort((a, b) => {
        /**
         * Use the *origin timestamp* as the primary sort key. This ensures that
         * each agent reply is grouped with the human message that triggered it.
         *
         * - If the message is from an agent, the origin timestamp is the timestamp
         * of the message it is replying to.
         *
         * - Otherwise, the origin timestamp is the *message timestamp*, i.e.
         * `message.time` itself.
         */
        const aOriginTimestamp = 'reply_to' in a && a.reply_to in timestampsById
            ? timestampsById[a.reply_to]
            : a.time;
        const bOriginTimestamp = 'reply_to' in b && b.reply_to in timestampsById
            ? timestampsById[b.reply_to]
            : b.time;
        /**
         * Use the message timestamp as a secondary sort key. This ensures that each
         * agent reply is shown after the human message that triggered it.
         */
        const aMessageTimestamp = a.time;
        const bMessageTimestamp = b.time;
        return (aOriginTimestamp - bOriginTimestamp ||
            aMessageTimestamp - bMessageTimestamp);
    });
}
function ChatMessageHeader(props) {
    var _a;
    const collaborators = (0,_contexts_collaborators_context__WEBPACK_IMPORTED_MODULE_3__.useCollaboratorsContext)();
    const sharedStyles = {
        height: '24px',
        width: '24px'
    };
    let avatar;
    if (props.message.type === 'human') {
        const bgcolor = (_a = collaborators === null || collaborators === void 0 ? void 0 : collaborators[props.message.client.username]) === null || _a === void 0 ? void 0 : _a.color;
        avatar = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, { sx: {
                ...sharedStyles,
                ...(bgcolor && { bgcolor })
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: {
                    fontSize: 'var(--jp-ui-font-size1)',
                    color: 'var(--jp-ui-inverse-font-color1)'
                } }, props.message.client.initials)));
    }
    else {
        const baseUrl = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__.ServerConnection.makeSettings().baseUrl;
        const avatar_url = baseUrl + props.message.persona.avatar_route;
        avatar = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, { sx: { ...sharedStyles, bgcolor: 'var(--jp-layout-color-1)' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: avatar_url })));
    }
    const name = props.message.type === 'human'
        ? props.message.client.display_name
        : props.message.persona.name;
    const shouldShowMenu = props.message.type === 'agent' ||
        (props.message.type === 'agent-stream' && props.message.complete);
    const shouldShowDelete = props.message.type === 'human';
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
            display: 'flex',
            alignItems: 'center',
            '& > :not(:last-child)': {
                marginRight: 3
            },
            ...props.sx
        } },
        avatar,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
                display: 'flex',
                flexGrow: 1,
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                alignItems: 'center'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: { fontWeight: 700, color: 'var(--jp-ui-font-color1)' } }, name),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { display: 'flex', alignItems: 'center' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: {
                        fontSize: '0.8em',
                        color: 'var(--jp-ui-font-color2)',
                        fontWeight: 300
                    } }, props.timestamp),
                shouldShowMenu && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_chat_messages_chat_message_menu__WEBPACK_IMPORTED_MODULE_4__.ChatMessageMenu, { message: props.message, sx: { marginLeft: '4px', marginRight: '-8px' } })),
                shouldShowDelete && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_chat_messages_chat_message_delete__WEBPACK_IMPORTED_MODULE_5__.ChatMessageDelete, { message: props.message, chatHandler: props.chatHandler, sx: { marginLeft: '4px', marginRight: '-8px' } }))))));
}
function ChatMessages(props) {
    const [timestamps, setTimestamps] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [sortedMessages, setSortedMessages] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    /**
     * Effect: update cached timestamp strings upon receiving a new message.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const newTimestamps = { ...timestamps };
        let timestampAdded = false;
        for (const message of props.messages) {
            if (!(message.id in newTimestamps)) {
                // Use the browser's default locale
                newTimestamps[message.id] = new Date(message.time * 1000) // Convert message time to milliseconds
                    .toLocaleTimeString([], {
                    hour: 'numeric',
                    minute: '2-digit'
                });
                timestampAdded = true;
            }
        }
        if (timestampAdded) {
            setTimestamps(newTimestamps);
        }
    }, [props.messages]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setSortedMessages(sortMessages(props.messages));
    }, [props.messages]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
            '& > :not(:last-child)': {
                borderBottom: '1px solid var(--jp-border-color2)'
            }
        } }, sortedMessages.map(message => {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { key: message.id, sx: { padding: 4 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ChatMessageHeader, { message: message, timestamp: timestamps[message.id], chatHandler: props.chatHandler, sx: { marginBottom: 3 } }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rendermime_markdown__WEBPACK_IMPORTED_MODULE_6__.RendermimeMarkdown, { markdownStr: message.body, rmRegistry: props.rmRegistry, parentMessage: message, complete: message.type === 'agent-stream' ? !!message.complete : true }),
            props.messageFooter && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(props.messageFooter.component, { message: message }))));
    })));
}


/***/ }),

/***/ "./lib/components/chat-messages/chat-message-delete.js":
/*!*************************************************************!*\
  !*** ./lib/components/chat-messages/chat-message-delete.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatMessageDelete: () => (/* binding */ ChatMessageDelete),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/icons-material */ "webpack/sharing/consume/default/@mui/icons-material/@mui/icons-material");
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../mui-extras/tooltipped-icon-button */ "./lib/components/mui-extras/tooltipped-icon-button.js");



function ChatMessageDelete(props) {
    const request = {
        type: 'clear',
        target: props.message.id
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_2__.TooltippedIconButton, { onClick: () => props.chatHandler.sendMessage(request), sx: props.sx, tooltip: "Delete this exchange" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_1__.Close, null)));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatMessageDelete);


/***/ }),

/***/ "./lib/components/chat-messages/chat-message-menu.js":
/*!***********************************************************!*\
  !*** ./lib/components/chat-messages/chat-message-menu.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatMessageMenu: () => (/* binding */ ChatMessageMenu)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material */ "webpack/sharing/consume/default/@mui/icons-material/@mui/icons-material");
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_use_copy__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hooks/use-copy */ "./lib/hooks/use-copy.js");
/* harmony import */ var _hooks_use_replace__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../hooks/use-replace */ "./lib/hooks/use-replace.js");
/* harmony import */ var _contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../contexts/active-cell-context */ "./lib/contexts/active-cell-context.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");








function ChatMessageMenu(props) {
    const menuButtonRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const { copy, copyLabel } = (0,_hooks_use_copy__WEBPACK_IMPORTED_MODULE_4__.useCopy)({
        labelOverrides: { [_hooks_use_copy__WEBPACK_IMPORTED_MODULE_4__.CopyStatus.None]: 'Copy response' }
    });
    const { replace, replaceLabel } = (0,_hooks_use_replace__WEBPACK_IMPORTED_MODULE_5__.useReplace)();
    const activeCell = (0,_contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_6__.useActiveCellContext)();
    const [menuOpen, setMenuOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(null);
    const openMenu = (event) => {
        setAnchorEl(event.currentTarget);
        setMenuOpen(true);
    };
    const insertAboveLabel = activeCell.exists
        ? 'Insert response above active cell'
        : 'Insert response above active cell (no active cell)';
    const insertBelowLabel = activeCell.exists
        ? 'Insert response below active cell'
        : 'Insert response below active cell (no active cell)';
    const menuItemSx = {
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        lineHeight: 0
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { onClick: openMenu, ref: menuButtonRef, sx: props.sx },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.MoreVert, null)),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Menu, { open: menuOpen, onClose: () => setMenuOpen(false), anchorEl: anchorEl },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { onClick: () => copy(props.message.body), sx: menuItemSx },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.copyIcon.react, null),
                copyLabel),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { onClick: () => replace(props.message.body), sx: menuItemSx },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_7__.replaceCellIcon.react, null),
                replaceLabel),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { onClick: () => activeCell.manager.insertAbove(props.message.body), disabled: !activeCell.exists, sx: menuItemSx },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.addAboveIcon.react, null),
                insertAboveLabel),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { onClick: () => activeCell.manager.insertBelow(props.message.body), disabled: !activeCell.exists, sx: menuItemSx },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.addBelowIcon.react, null),
                insertBelowLabel))));
}


/***/ }),

/***/ "./lib/components/chat-settings.js":
/*!*****************************************!*\
  !*** ./lib/components/chat-settings.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatSettings: () => (/* binding */ ChatSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/system */ "../../node_modules/@mui/system/esm/Box/Box.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @mui/icons-material/Settings */ "../../node_modules/@mui/icons-material/Settings.js");
/* harmony import */ var _mui_icons_material_WarningAmber__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @mui/icons-material/WarningAmber */ "../../node_modules/@mui/icons-material/WarningAmber.js");
/* harmony import */ var _select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./select */ "./lib/components/select.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../handler */ "./lib/handler.js");
/* harmony import */ var _settings_model_fields__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./settings/model-fields */ "./lib/components/settings/model-fields.js");
/* harmony import */ var _settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./settings/use-server-info */ "./lib/components/settings/use-server-info.js");
/* harmony import */ var _settings_existing_api_keys__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./settings/existing-api-keys */ "./lib/components/settings/existing-api-keys.js");
/* harmony import */ var _settings_minify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./settings/minify */ "./lib/components/settings/minify.js");
/* harmony import */ var _mui_extras_stacking_alert__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mui-extras/stacking-alert */ "./lib/components/mui-extras/stacking-alert.js");
/* harmony import */ var _rendermime_markdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./rendermime-markdown */ "./lib/components/rendermime-markdown.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils */ "./lib/utils.js");














/**
 * Component that returns the settings view in the chat panel.
 */
function ChatSettings(props) {
    // state fetched on initial render
    const server = (0,_settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__.useServerInfo)();
    // initialize alert helper
    const alert = (0,_mui_extras_stacking_alert__WEBPACK_IMPORTED_MODULE_3__.useStackingAlert)();
    const apiKeysAlert = (0,_mui_extras_stacking_alert__WEBPACK_IMPORTED_MODULE_3__.useStackingAlert)();
    // user inputs
    const [lmProvider, setLmProvider] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [clmProvider, setClmProvider] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [showLmLocalId, setShowLmLocalId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [showClmLocalId, setShowClmLocalId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [chatHelpMarkdown, setChatHelpMarkdown] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [completionHelpMarkdown, setCompletionHelpMarkdown] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [lmLocalId, setLmLocalId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [clmLocalId, setClmLocalId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const lmGlobalId = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        if (!lmProvider) {
            return null;
        }
        return lmProvider.id + ':' + lmLocalId;
    }, [lmProvider, lmLocalId]);
    const clmGlobalId = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        if (!clmProvider) {
            return null;
        }
        return clmProvider.id + ':' + clmLocalId;
    }, [clmProvider, clmLocalId]);
    const [emGlobalId, setEmGlobalId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const emProvider = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        if (emGlobalId === null || server.state !== _settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__.ServerInfoState.Ready) {
            return null;
        }
        return getProvider(emGlobalId, server.emProviders);
    }, [emGlobalId, server]);
    const [apiKeys, setApiKeys] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [sendWse, setSendWse] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [fields, setFields] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [isCompleterEnabled, setIsCompleterEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(props.completionProvider && props.completionProvider.isEnabled());
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        var _a;
        const refreshCompleterState = () => {
            setIsCompleterEnabled(props.completionProvider && props.completionProvider.isEnabled());
        };
        (_a = props.completionProvider) === null || _a === void 0 ? void 0 : _a.settingsChanged.connect(refreshCompleterState);
        return () => {
            var _a;
            (_a = props.completionProvider) === null || _a === void 0 ? void 0 : _a.settingsChanged.disconnect(refreshCompleterState);
        };
    }, [props.completionProvider]);
    // whether the form is currently saving
    const [saving, setSaving] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    /**
     * Effect: initialize inputs after fetching server info.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        var _a, _b, _c, _d, _e, _f;
        if (server.state !== _settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__.ServerInfoState.Ready) {
            return;
        }
        setLmLocalId(server.chat.lmLocalId);
        setClmLocalId(server.completions.lmLocalId);
        setEmGlobalId(server.config.embeddings_provider_id);
        setSendWse(server.config.send_with_shift_enter);
        setChatHelpMarkdown((_b = (_a = server.chat.lmProvider) === null || _a === void 0 ? void 0 : _a.help) !== null && _b !== void 0 ? _b : null);
        setCompletionHelpMarkdown((_d = (_c = server.completions.lmProvider) === null || _c === void 0 ? void 0 : _c.help) !== null && _d !== void 0 ? _d : null);
        if ((_e = server.chat.lmProvider) === null || _e === void 0 ? void 0 : _e.registry) {
            setShowLmLocalId(true);
        }
        if ((_f = server.completions.lmProvider) === null || _f === void 0 ? void 0 : _f.registry) {
            setShowClmLocalId(true);
        }
        setLmProvider(server.chat.lmProvider);
        setClmProvider(server.completions.lmProvider);
    }, [server]);
    /**
     * Effect: re-initialize apiKeys object whenever the selected LM/EM changes.
     * Properties with a value of '' indicate necessary user input.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (server.state !== _settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__.ServerInfoState.Ready) {
            return;
        }
        const newApiKeys = {};
        const lmAuth = lmProvider === null || lmProvider === void 0 ? void 0 : lmProvider.auth_strategy;
        const emAuth = emProvider === null || emProvider === void 0 ? void 0 : emProvider.auth_strategy;
        if ((lmAuth === null || lmAuth === void 0 ? void 0 : lmAuth.type) === 'env' &&
            !server.config.api_keys.includes(lmAuth.name)) {
            newApiKeys[lmAuth.name] = '';
        }
        if ((lmAuth === null || lmAuth === void 0 ? void 0 : lmAuth.type) === 'multienv') {
            lmAuth.names.forEach(apiKey => {
                if (!server.config.api_keys.includes(apiKey)) {
                    newApiKeys[apiKey] = '';
                }
            });
        }
        if ((emAuth === null || emAuth === void 0 ? void 0 : emAuth.type) === 'env' &&
            !server.config.api_keys.includes(emAuth.name)) {
            newApiKeys[emAuth.name] = '';
        }
        if ((emAuth === null || emAuth === void 0 ? void 0 : emAuth.type) === 'multienv') {
            emAuth.names.forEach(apiKey => {
                if (!server.config.api_keys.includes(apiKey)) {
                    newApiKeys[apiKey] = '';
                }
            });
        }
        setApiKeys(newApiKeys);
    }, [lmProvider, emProvider, server]);
    /**
     * Effect: re-initialize fields object whenever the selected LM changes.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        var _a, _b;
        if (server.state !== _settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__.ServerInfoState.Ready || !lmGlobalId) {
            return;
        }
        const currFields = (_b = (_a = server.config.fields) === null || _a === void 0 ? void 0 : _a[lmGlobalId]) !== null && _b !== void 0 ? _b : {};
        setFields(currFields);
    }, [server, lmProvider]);
    const handleSave = async () => {
        // compress fields with JSON values
        if (server.state !== _settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__.ServerInfoState.Ready) {
            return;
        }
        for (const fieldKey in fields) {
            const fieldVal = fields[fieldKey];
            if (typeof fieldVal !== 'string' || !fieldVal.trim().startsWith('{')) {
                continue;
            }
            try {
                const parsedFieldVal = JSON.parse(fieldVal);
                const compressedFieldVal = JSON.stringify(parsedFieldVal);
                fields[fieldKey] = compressedFieldVal;
            }
            catch (e) {
                continue;
            }
        }
        let updateRequest = {
            model_provider_id: lmGlobalId,
            embeddings_provider_id: emGlobalId,
            api_keys: apiKeys,
            ...((lmGlobalId || clmGlobalId) && {
                fields: {
                    ...(lmGlobalId && {
                        [lmGlobalId]: fields
                    }),
                    ...(clmGlobalId && {
                        [clmGlobalId]: fields
                    })
                }
            }),
            completions_model_provider_id: clmGlobalId,
            send_with_shift_enter: sendWse
        };
        updateRequest = (0,_settings_minify__WEBPACK_IMPORTED_MODULE_4__.minifyUpdate)(server.config, updateRequest);
        updateRequest.last_read = server.config.last_read;
        setSaving(true);
        try {
            await apiKeysAlert.clear();
            await _handler__WEBPACK_IMPORTED_MODULE_5__.AiService.updateConfig(updateRequest);
        }
        catch (e) {
            console.error(e);
            const msg = e instanceof Error || typeof e === 'string'
                ? e.toString()
                : 'An unknown error occurred. Check the console for more details.';
            alert.show('error', msg);
            return;
        }
        finally {
            setSaving(false);
        }
        await server.refetchAll();
        alert.show('success', 'Settings saved successfully.');
    };
    if (server.state === _settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__.ServerInfoState.Loading) {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_6__["default"], { sx: {
                width: '100%',
                height: '100%',
                boxSizing: 'border-box',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-around'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, null)));
    }
    if (server.state === _settings_use_server_info__WEBPACK_IMPORTED_MODULE_2__.ServerInfoState.Error) {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_6__["default"], { sx: {
                width: '100%',
                height: '100%',
                padding: 4,
                boxSizing: 'border-box'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Alert, { severity: "error" }, server.error ||
                'An unknown error occurred. Check the console for more details.')));
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_6__["default"], { sx: {
            padding: '0 12px 12px',
            boxSizing: 'border-box',
            '& .MuiAlert-root': {
                marginTop: 2
            },
            overflowY: 'auto'
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "jp-ai-ChatSettings-header", title: "The language model used in the chat panel" }, "Language model"),
        server.lmProviders.providers
            .map(lmp => lmp.chat_models.length)
            .reduce((partialSum, num) => partialSum + num, 0) > 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_6__["default"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_select__WEBPACK_IMPORTED_MODULE_7__.Select, { value: (lmProvider === null || lmProvider === void 0 ? void 0 : lmProvider.registry) ? lmProvider.id + ':*' : lmGlobalId, label: "Completion model", onChange: e => {
                    var _a;
                    const lmGid = e.target.value === 'null' ? null : e.target.value;
                    if (lmGid === null) {
                        setLmProvider(null);
                        return;
                    }
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    const nextLmProvider = getProvider(lmGid, server.lmProviders);
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    const nextLmLocalId = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getModelLocalId)(lmGid);
                    setLmProvider(nextLmProvider);
                    setChatHelpMarkdown((_a = nextLmProvider === null || nextLmProvider === void 0 ? void 0 : nextLmProvider.help) !== null && _a !== void 0 ? _a : null);
                    if (nextLmProvider.registry) {
                        setLmLocalId('');
                        setShowLmLocalId(true);
                    }
                    else {
                        setLmLocalId(nextLmLocalId);
                        setShowLmLocalId(false);
                    }
                }, MenuProps: { sx: { maxHeight: '50%', minHeight: 400 } } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: "null" }, "None"),
                server.lmProviders.providers.map(lmp => lmp.models
                    .filter(lm => lmp.chat_models.includes(lm))
                    .map(lm => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: `${lmp.id}:${lm}` },
                    lmp.name,
                    " :: ",
                    lm))))),
            showLmLocalId && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { label: (lmProvider === null || lmProvider === void 0 ? void 0 : lmProvider.model_id_label) || 'Local model ID', value: lmLocalId, onChange: e => setLmLocalId(e.target.value), fullWidth: true })),
            chatHelpMarkdown && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rendermime_markdown__WEBPACK_IMPORTED_MODULE_9__.RendermimeMarkdown, { rmRegistry: props.rmRegistry, markdownStr: chatHelpMarkdown, complete: true })),
            lmGlobalId && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_settings_model_fields__WEBPACK_IMPORTED_MODULE_10__.ModelFields, { fields: lmProvider === null || lmProvider === void 0 ? void 0 : lmProvider.fields, values: fields, onChange: setFields })))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "No language models available.")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "jp-ai-ChatSettings-header" }, "Embedding model"),
        server.emProviders.providers.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_select__WEBPACK_IMPORTED_MODULE_7__.Select, { value: emGlobalId, label: "Embedding model", onChange: e => {
                const emGid = e.target.value === 'null' ? null : e.target.value;
                setEmGlobalId(emGid);
            }, MenuProps: { sx: { maxHeight: '50%', minHeight: 400 } } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: "null" }, "None"),
            server.emProviders.providers.map(emp => emp.models
                .filter(em => em !== '*') // TODO: support registry providers
                .map(em => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: `${emp.id}:${em}` },
                emp.name,
                " :: ",
                em)))))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "No embedding models available.")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "jp-ai-ChatSettings-header" },
            "Inline completions model",
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(CompleterSettingsButton, { provider: props.completionProvider, openSettings: props.openInlineCompleterSettings, isCompleterEnabled: isCompleterEnabled, selection: clmProvider })),
        server.lmProviders.providers
            .map(lmp => lmp.completion_models.length)
            .reduce((partialSum, num) => partialSum + num, 0) > 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_6__["default"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_select__WEBPACK_IMPORTED_MODULE_7__.Select, { value: (clmProvider === null || clmProvider === void 0 ? void 0 : clmProvider.registry) ? clmProvider.id + ':*' : clmGlobalId, label: "Inline completion model", disabled: !isCompleterEnabled, onChange: e => {
                    var _a;
                    const clmGid = e.target.value === 'null' ? null : e.target.value;
                    if (clmGid === null) {
                        setClmProvider(null);
                        return;
                    }
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    const nextClmProvider = getProvider(clmGid, server.lmProviders);
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    const nextClmLocalId = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getModelLocalId)(clmGid);
                    setClmProvider(nextClmProvider);
                    setCompletionHelpMarkdown((_a = nextClmProvider === null || nextClmProvider === void 0 ? void 0 : nextClmProvider.help) !== null && _a !== void 0 ? _a : null);
                    if (nextClmProvider.registry) {
                        setClmLocalId('');
                        setShowClmLocalId(true);
                    }
                    else {
                        setClmLocalId(nextClmLocalId);
                        setShowClmLocalId(false);
                    }
                }, MenuProps: { sx: { maxHeight: '50%', minHeight: 400 } } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: "null" }, "None"),
                server.lmProviders.providers.map(lmp => lmp.models
                    .filter(lm => lmp.completion_models.includes(lm))
                    .map(lm => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: `${lmp.id}:${lm}` },
                    lmp.name,
                    " :: ",
                    lm))))),
            showClmLocalId && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { label: (clmProvider === null || clmProvider === void 0 ? void 0 : clmProvider.model_id_label) || 'Local model ID', value: clmLocalId, onChange: e => setClmLocalId(e.target.value), fullWidth: true })),
            completionHelpMarkdown && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rendermime_markdown__WEBPACK_IMPORTED_MODULE_9__.RendermimeMarkdown, { rmRegistry: props.rmRegistry, markdownStr: completionHelpMarkdown, complete: true })),
            clmGlobalId && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_settings_model_fields__WEBPACK_IMPORTED_MODULE_10__.ModelFields, { fields: clmProvider === null || clmProvider === void 0 ? void 0 : clmProvider.fields, values: fields, onChange: setFields })))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "No Inline Completion models.")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "jp-ai-ChatSettings-header" }, "API Keys"),
        Object.entries(apiKeys).length === 0 &&
            server.config.api_keys.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "No API keys are required by the selected models.")) : null,
        Object.entries(apiKeys).map(([apiKeyName, apiKeyValue], idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { key: idx, label: apiKeyName, value: apiKeyValue, fullWidth: true, type: "password", onChange: e => setApiKeys(apiKeys => ({
                ...apiKeys,
                [apiKeyName]: e.target.value
            })) }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_settings_existing_api_keys__WEBPACK_IMPORTED_MODULE_11__.ExistingApiKeys, { alert: apiKeysAlert, apiKeys: server.config.api_keys, onSuccess: server.refetchApiKeys }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "jp-ai-ChatSettings-header" }, "Input"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormLabel, { id: "send-radio-buttons-group-label" },
                "When writing a message, press ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("kbd", null, "Enter"),
                " to:"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.RadioGroup, { "aria-labelledby": "send-radio-buttons-group-label", value: sendWse ? 'newline' : 'send', name: "send-radio-buttons-group", onChange: e => {
                    setSendWse(e.target.value === 'newline');
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, { value: "send", control: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, null), label: "Send the message" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, { value: "newline", control: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, null), label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        "Start a new line (use ",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("kbd", null, "Shift"),
                        "+",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("kbd", null, "Enter"),
                        " to send)") }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_6__["default"], { sx: { display: 'flex', justifyContent: 'flex-end' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "contained", onClick: handleSave, disabled: saving }, saving ? 'Saving...' : 'Save changes')),
        alert.jsx));
}
function CompleterSettingsButton(props) {
    if (props.selection && !props.isCompleterEnabled) {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: 'A completer model is selected, but ' +
                (props.provider === null
                    ? 'the completion provider plugin is not available.'
                    : 'the inline completion provider is not enabled in the settings: click to open settings.') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { onClick: props.openSettings },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_WarningAmber__WEBPACK_IMPORTED_MODULE_12__["default"], null))));
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Completer settings" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { onClick: props.openSettings },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_13__["default"], null))));
}
function getProvider(globalModelId, providers) {
    const providerId = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getProviderId)(globalModelId);
    const provider = providers.providers.find(p => p.id === providerId);
    return provider !== null && provider !== void 0 ? provider : null;
}


/***/ }),

/***/ "./lib/components/chat.js":
/*!********************************!*\
  !*** ./lib/components/chat.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Chat: () => (/* binding */ Chat)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/system */ "../../node_modules/@mui/system/esm/Box/Box.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/icons-material/Settings */ "../../node_modules/@mui/icons-material/Settings.js");
/* harmony import */ var _mui_icons_material_ArrowBack__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @mui/icons-material/ArrowBack */ "../../node_modules/@mui/icons-material/ArrowBack.js");
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @mui/icons-material/Add */ "../../node_modules/@mui/icons-material/Add.js");
/* harmony import */ var _jl_theme_provider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./jl-theme-provider */ "./lib/components/jl-theme-provider.js");
/* harmony import */ var _chat_messages__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./chat-messages */ "./lib/components/chat-messages.js");
/* harmony import */ var _pending_messages__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pending-messages */ "./lib/components/pending-messages.js");
/* harmony import */ var _chat_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./chat-input */ "./lib/components/chat-input.js");
/* harmony import */ var _chat_settings__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./chat-settings */ "./lib/components/chat-settings.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../handler */ "./lib/handler.js");
/* harmony import */ var _contexts_selection_context__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../contexts/selection-context */ "./lib/contexts/selection-context.js");
/* harmony import */ var _contexts_collaborators_context__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../contexts/collaborators-context */ "./lib/contexts/collaborators-context.js");
/* harmony import */ var _contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../contexts/active-cell-context */ "./lib/contexts/active-cell-context.js");
/* harmony import */ var _contexts_user_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../contexts/user-context */ "./lib/contexts/user-context.js");
/* harmony import */ var _scroll_container__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./scroll-container */ "./lib/components/scroll-container.js");
/* harmony import */ var _mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./mui-extras/tooltipped-icon-button */ "./lib/components/mui-extras/tooltipped-icon-button.js");
/* harmony import */ var _contexts_telemetry_context__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../contexts/telemetry-context */ "./lib/contexts/telemetry-context.js");
/* harmony import */ var _contexts_all_notebook_context__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../contexts/all-notebook-context */ "./lib/contexts/all-notebook-context.js");




















/**
 * Determines the name of the current persona based on the message history.
 * Defaults to `'Jupyternaut'` if history is insufficient.
 */
function getPersonaName(messages) {
    for (let i = messages.length - 1; i >= 0; i--) {
        const message = messages[i];
        if (message.type === 'agent' || message.type === 'agent-stream') {
            return message.persona.name;
        }
    }
    return 'Jupyternaut';
}
function ChatBody({ chatHandler, focusInputSignal, openSettingsView, showWelcomeMessage, setShowWelcomeMessage, rmRegistry: renderMimeRegistry, messageFooter }) {
    const [messages, setMessages] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([
        ...chatHandler.history.messages
    ]);
    const [pendingMessages, setPendingMessages] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([...chatHandler.history.pending_messages]);
    const [personaName, setPersonaName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getPersonaName(messages));
    const [sendWithShiftEnter, setSendWithShiftEnter] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const user = (0,_contexts_user_context__WEBPACK_IMPORTED_MODULE_2__.useUserContext)();
    /**
     * Effect: fetch config on initial render
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        async function fetchConfig() {
            var _a;
            try {
                const config = await _handler__WEBPACK_IMPORTED_MODULE_3__.AiService.getConfig();
                setSendWithShiftEnter((_a = config.send_with_shift_enter) !== null && _a !== void 0 ? _a : false);
                if (!config.model_provider_id) {
                    setShowWelcomeMessage(true);
                }
            }
            catch (e) {
                console.error(e);
            }
        }
        fetchConfig();
    }, [chatHandler]);
    /**
     * Effect: listen to chat messages
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        function onHistoryChange(_, history) {
            setMessages([...history.messages]);
            setPendingMessages([...history.pending_messages]);
            setPersonaName(getPersonaName(history.messages));
        }
        chatHandler.historyChanged.connect(onHistoryChange);
        return function cleanup() {
            chatHandler.historyChanged.disconnect(onHistoryChange);
        };
    }, [chatHandler]);
    if (showWelcomeMessage) {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_4__["default"], { sx: {
                padding: 4,
                display: 'flex',
                flexGrow: 1,
                alignItems: 'top',
                justifyContent: 'space-around'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, { spacing: 4 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jp-ai-ChatSettings-welcome" }, "Welcome to Jupyter AI! To get started, please select a language model to chat with from the settings panel. You may also need to provide API credentials, so have those handy."),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "contained", startIcon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_5__["default"], null), size: 'large', onClick: () => openSettingsView() }, "Start Here"))));
    }
    // set of IDs of messages sent by the current user.
    const myHumanMessageIds = new Set(messages
        .filter(m => m.type === 'human' && m.client.username === (user === null || user === void 0 ? void 0 : user.identity.username))
        .map(m => m.id));
    // whether the backend is currently streaming a reply to any message sent by
    // the current user.
    const streamingReplyHere = messages.some(m => m.type === 'agent-stream' &&
        myHumanMessageIds.has(m.reply_to) &&
        !m.complete);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_scroll_container__WEBPACK_IMPORTED_MODULE_6__.ScrollContainer, { sx: { flexGrow: 1 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_chat_messages__WEBPACK_IMPORTED_MODULE_7__.ChatMessages, { messages: messages, chatHandler: chatHandler, rmRegistry: renderMimeRegistry, messageFooter: messageFooter }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_pending_messages__WEBPACK_IMPORTED_MODULE_8__.PendingMessages, { messages: pendingMessages, chatHandler: chatHandler })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_chat_input__WEBPACK_IMPORTED_MODULE_9__.ChatInput, { chatHandler: chatHandler, focusInputSignal: focusInputSignal, streamingReplyHere: streamingReplyHere, sx: {
                paddingLeft: 4,
                paddingRight: 4,
                paddingTop: 3.5,
                paddingBottom: 0,
                borderTop: '1px solid var(--jp-border-color1)'
            }, sendWithShiftEnter: sendWithShiftEnter, personaName: personaName })));
}
var ChatView;
(function (ChatView) {
    ChatView[ChatView["Chat"] = 0] = "Chat";
    ChatView[ChatView["Settings"] = 1] = "Settings";
})(ChatView || (ChatView = {}));
function Chat(props) {
    const [view, setView] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(props.chatView || ChatView.Chat);
    const [showWelcomeMessage, setShowWelcomeMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const openSettingsView = () => {
        setShowWelcomeMessage(false);
        setView(ChatView.Settings);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jl_theme_provider__WEBPACK_IMPORTED_MODULE_10__.JlThemeProvider, { themeManager: props.themeManager },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_selection_context__WEBPACK_IMPORTED_MODULE_11__.SelectionContextProvider, { selectionWatcher: props.selectionWatcher },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_all_notebook_context__WEBPACK_IMPORTED_MODULE_12__.NotebookSelectionContextProvider, { notebookWatcher: props.notebookWatcher },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_collaborators_context__WEBPACK_IMPORTED_MODULE_13__.CollaboratorsContextProvider, { globalAwareness: props.globalAwareness },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_14__.ActiveCellContextProvider, { activeCellManager: props.activeCellManager },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_telemetry_context__WEBPACK_IMPORTED_MODULE_15__.TelemetryContextProvider, { telemetryHandler: props.telemetryHandler },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_user_context__WEBPACK_IMPORTED_MODULE_2__.UserContextProvider, { userManager: props.userManager },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_4__["default"]
                                // root box should not include padding as it offsets the vertical
                                // scrollbar to the left
                                , { 
                                    // root box should not include padding as it offsets the vertical
                                    // scrollbar to the left
                                    sx: {
                                        width: '100%',
                                        height: '100%',
                                        boxSizing: 'border-box',
                                        background: 'var(--jp-layout-color0)',
                                        display: 'flex',
                                        flexDirection: 'column'
                                    } },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_4__["default"], { sx: { display: 'flex', justifyContent: 'space-between' } },
                                        view !== ChatView.Chat ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { onClick: () => setView(ChatView.Chat) },
                                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ArrowBack__WEBPACK_IMPORTED_MODULE_16__["default"], null))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_4__["default"], null)),
                                        view === ChatView.Chat ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_4__["default"], { sx: { display: 'flex' } },
                                            !showWelcomeMessage && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_17__.TooltippedIconButton, { onClick: () => props.chatHandler.sendMessage({ type: 'clear' }), tooltip: "New chat" },
                                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_18__["default"], null))),
                                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { onClick: () => openSettingsView() },
                                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_5__["default"], null)))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_system__WEBPACK_IMPORTED_MODULE_4__["default"], null))),
                                    view === ChatView.Chat && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ChatBody, { chatHandler: props.chatHandler, openSettingsView: openSettingsView, showWelcomeMessage: showWelcomeMessage, setShowWelcomeMessage: setShowWelcomeMessage, rmRegistry: props.rmRegistry, focusInputSignal: props.focusInputSignal, messageFooter: props.messageFooter })),
                                    view === ChatView.Settings && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_chat_settings__WEBPACK_IMPORTED_MODULE_19__.ChatSettings, { rmRegistry: props.rmRegistry, completionProvider: props.completionProvider, openInlineCompleterSettings: props.openInlineCompleterSettings })))))))))));
}


/***/ }),

/***/ "./lib/components/code-blocks/code-toolbar.js":
/*!****************************************************!*\
  !*** ./lib/components/code-blocks/code-toolbar.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeToolbar: () => (/* binding */ CodeToolbar),
/* harmony export */   CopyButton: () => (/* binding */ CopyButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../contexts/active-cell-context */ "./lib/contexts/active-cell-context.js");
/* harmony import */ var _mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../mui-extras/tooltipped-icon-button */ "./lib/components/mui-extras/tooltipped-icon-button.js");
/* harmony import */ var _hooks_use_replace__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../hooks/use-replace */ "./lib/hooks/use-replace.js");
/* harmony import */ var _hooks_use_copy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../hooks/use-copy */ "./lib/hooks/use-copy.js");
/* harmony import */ var _contexts_telemetry_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../contexts/telemetry-context */ "./lib/contexts/telemetry-context.js");









function CodeToolbar(props) {
    const activeCell = (0,_contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_3__.useActiveCellContext)();
    const sharedToolbarButtonProps = {
        code: props.code,
        activeCellManager: activeCell.manager,
        activeCellExists: activeCell.exists,
        parentMessage: props.parentMessage
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
            display: 'flex',
            justifyContent: 'flex-end',
            alignItems: 'center',
            padding: '6px 2px',
            marginBottom: '1em',
            border: '1px solid var(--jp-cell-editor-border-color)',
            borderTop: 'none'
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(InsertAboveButton, { ...sharedToolbarButtonProps }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(InsertBelowButton, { ...sharedToolbarButtonProps }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ReplaceButton, { ...sharedToolbarButtonProps }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(CopyButton, { ...sharedToolbarButtonProps })));
}
function buildTelemetryEvent(type, props) {
    var _a, _b, _c, _d, _e, _f, _g;
    const charCount = props.code.length;
    // number of lines = number of newlines + 1
    const lineCount = ((_a = props.code.match(/\n/g)) !== null && _a !== void 0 ? _a : []).length + 1;
    return {
        type,
        message: {
            id: (_c = (_b = props.parentMessage) === null || _b === void 0 ? void 0 : _b.id) !== null && _c !== void 0 ? _c : '',
            type: (_e = (_d = props.parentMessage) === null || _d === void 0 ? void 0 : _d.type) !== null && _e !== void 0 ? _e : 'human',
            time: (_g = (_f = props.parentMessage) === null || _f === void 0 ? void 0 : _f.time) !== null && _g !== void 0 ? _g : 0,
            metadata: props.parentMessage && 'metadata' in props.parentMessage
                ? props.parentMessage.metadata
                : {}
        },
        code: {
            charCount,
            lineCount
        }
    };
}
function InsertAboveButton(props) {
    const telemetryHandler = (0,_contexts_telemetry_context__WEBPACK_IMPORTED_MODULE_4__.useTelemetry)();
    const tooltip = props.activeCellExists
        ? 'Insert above active cell'
        : 'Insert above active cell (no active cell)';
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_5__.TooltippedIconButton, { tooltip: tooltip, onClick: () => {
            props.activeCellManager.insertAbove(props.code);
            try {
                telemetryHandler.onEvent(buildTelemetryEvent('insert-above', props));
            }
            catch (e) {
                console.error(e);
                return;
            }
        }, disabled: !props.activeCellExists },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.addAboveIcon.react, { height: "16px", width: "16px" })));
}
function InsertBelowButton(props) {
    const telemetryHandler = (0,_contexts_telemetry_context__WEBPACK_IMPORTED_MODULE_4__.useTelemetry)();
    const tooltip = props.activeCellExists
        ? 'Insert below active cell'
        : 'Insert below active cell (no active cell)';
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_5__.TooltippedIconButton, { tooltip: tooltip, disabled: !props.activeCellExists, onClick: () => {
            props.activeCellManager.insertBelow(props.code);
            try {
                telemetryHandler.onEvent(buildTelemetryEvent('insert-below', props));
            }
            catch (e) {
                console.error(e);
                return;
            }
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.addBelowIcon.react, { height: "16px", width: "16px" })));
}
function ReplaceButton(props) {
    const telemetryHandler = (0,_contexts_telemetry_context__WEBPACK_IMPORTED_MODULE_4__.useTelemetry)();
    const { replace, replaceDisabled, replaceLabel } = (0,_hooks_use_replace__WEBPACK_IMPORTED_MODULE_6__.useReplace)();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_5__.TooltippedIconButton, { tooltip: replaceLabel, disabled: replaceDisabled, onClick: () => {
            replace(props.code);
            try {
                telemetryHandler.onEvent(buildTelemetryEvent('replace', props));
            }
            catch (e) {
                console.error(e);
                return;
            }
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_7__.replaceCellIcon.react, { height: "16px", width: "16px" })));
}
function CopyButton(props) {
    const telemetryHandler = (0,_contexts_telemetry_context__WEBPACK_IMPORTED_MODULE_4__.useTelemetry)();
    const { copy, copyLabel } = (0,_hooks_use_copy__WEBPACK_IMPORTED_MODULE_8__.useCopy)();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_tooltipped_icon_button__WEBPACK_IMPORTED_MODULE_5__.TooltippedIconButton, { tooltip: copyLabel, placement: "top", onClick: () => {
            copy(props.code);
            try {
                telemetryHandler.onEvent(buildTelemetryEvent('copy', props));
            }
            catch (e) {
                console.error(e);
                return;
            }
        }, "aria-label": "Copy to clipboard" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.copyIcon.react, { height: "16px", width: "16px" })));
}


/***/ }),

/***/ "./lib/components/jl-theme-provider.js":
/*!*********************************************!*\
  !*** ./lib/components/jl-theme-provider.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JlThemeProvider: () => (/* binding */ JlThemeProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material/styles */ "../../node_modules/@mui/material/styles/createTheme.js");
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/material/styles */ "../../node_modules/@mui/material/styles/ThemeProvider.js");
/* harmony import */ var _theme_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../theme-provider */ "./lib/theme-provider.js");



function JlThemeProvider(props) {
    const [theme, setTheme] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__["default"])());
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        var _a;
        async function setJlTheme() {
            setTheme(await (0,_theme_provider__WEBPACK_IMPORTED_MODULE_2__.getJupyterLabTheme)());
        }
        setJlTheme();
        (_a = props.themeManager) === null || _a === void 0 ? void 0 : _a.themeChanged.connect(setJlTheme);
    }, []);
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__["default"], { theme: theme }, props.children);
}


/***/ }),

/***/ "./lib/components/mui-extras/async-icon-button.js":
/*!********************************************************!*\
  !*** ./lib/components/mui-extras/async-icon-button.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AsyncIconButton: () => (/* binding */ AsyncIconButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contrasting_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contrasting-tooltip */ "./lib/components/mui-extras/contrasting-tooltip.js");



/**
 * A MUI IconButton that indicates whether the click handler is resolving via a
 * circular spinner around the IconButton. Requests user confirmation when
 * `confirm` is set to `true`.
 */
function AsyncIconButton(props) {
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [showConfirm, setShowConfirm] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const shouldConfirm = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => !!props.confirm, []);
    async function handleClick() {
        if (shouldConfirm && !showConfirm) {
            setShowConfirm(true);
            return;
        }
        setLoading(true);
        let thrown = false;
        try {
            await props.onClick();
        }
        catch (e) {
            thrown = true;
            if (e instanceof Error) {
                props.onError(e.toString());
            }
            else {
                // this should never happen.
                // if this happens, it means the thrown value was not of type `Error`.
                props.onError('Unknown error occurred.');
            }
        }
        setLoading(false);
        if (!thrown) {
            props.onSuccess();
        }
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
            position: 'relative',
            display: 'inline-block',
            boxSizing: 'content-box'
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contrasting_tooltip__WEBPACK_IMPORTED_MODULE_2__.ContrastingTooltip, { title: "Click again to confirm", open: showConfirm, onClose: () => setShowConfirm(false), arrow: true, placement: "top" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { disabled: loading, onClick: handleClick, onMouseDown: props.onMouseDown }, props.children)),
        loading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, { size: "100%", sx: {
                position: 'absolute',
                top: 0,
                left: 0
            } }))));
}


/***/ }),

/***/ "./lib/components/mui-extras/contrasting-tooltip.js":
/*!**********************************************************!*\
  !*** ./lib/components/mui-extras/contrasting-tooltip.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ContrastingTooltip: () => (/* binding */ ContrastingTooltip)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


/**
 * A restyled MUI tooltip component that is dark by default to improve contrast
 * against JupyterLab's default light theme. TODO: support dark themes.
 */
const ContrastingTooltip = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(({ className, ...props }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { ...props, arrow: true, classes: { popper: className } })))(({ theme }) => ({
    [`& .${_mui_material__WEBPACK_IMPORTED_MODULE_1__.tooltipClasses.tooltip}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
        boxShadow: theme.shadows[1],
        fontSize: 11
    },
    [`& .${_mui_material__WEBPACK_IMPORTED_MODULE_1__.tooltipClasses.arrow}`]: {
        color: theme.palette.common.black
    }
}));


/***/ }),

/***/ "./lib/components/mui-extras/stacking-alert.js":
/*!*****************************************************!*\
  !*** ./lib/components/mui-extras/stacking-alert.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useStackingAlert: () => (/* binding */ useStackingAlert)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Hook that returns a function to trigger an alert, and a corresponding alert
 * JSX element for the consumer to render. The number of successive identical
 * alerts `X` is indicated in the element via the suffix "(X)".
 */
function useStackingAlert() {
    const [type, setType] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [msg, setMsg] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [repeatCount, setRepeatCount] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const [expand, setExpand] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [exitPromise, setExitPromise] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [exitPromiseResolver, setExitPromiseResolver] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const showAlert = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((nextType, _nextMsg) => {
        // if the alert is identical to the previous alert, increment the
        // `repeatCount` indicator.
        const nextMsg = _nextMsg.toString();
        if (nextType === type && nextMsg === msg) {
            setRepeatCount(currCount => currCount + 1);
            return;
        }
        if (type === null) {
            // if this alert is being shown for the first time, initialize the
            // exitPromise so we can await it on `clear()`.
            setExitPromise(new Promise(res => {
                setExitPromiseResolver(() => res);
            }));
        }
        setType(nextType);
        setMsg(nextMsg);
        setRepeatCount(0);
        setExpand(true);
    }, [msg, type]);
    const alertJsx = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Collapse, { in: expand, onExited: () => {
            exitPromiseResolver === null || exitPromiseResolver === void 0 ? void 0 : exitPromiseResolver();
            // only clear the alert after the Collapse exits, otherwise the alert
            // disappears without any animation.
            setType(null);
            setMsg('');
            setRepeatCount(0);
        }, timeout: 200 }, type !== null && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Alert, { severity: type }, msg + (repeatCount ? ` (${repeatCount})` : ''))))), [msg, repeatCount, type, expand, exitPromiseResolver]);
    const clearAlert = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        setExpand(false);
        return exitPromise;
    }, [expand, exitPromise]);
    return {
        show: showAlert,
        jsx: alertJsx,
        clear: clearAlert
    };
}


/***/ }),

/***/ "./lib/components/mui-extras/tooltipped-button.js":
/*!********************************************************!*\
  !*** ./lib/components/mui-extras/tooltipped-button.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TooltippedButton: () => (/* binding */ TooltippedButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contrasting_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contrasting-tooltip */ "./lib/components/mui-extras/contrasting-tooltip.js");



/**
 * A component that renders an MUI `Button` with a high-contrast tooltip
 * provided by `ContrastingTooltip`. This component differs from the MUI
 * defaults in the following ways:
 *
 * - Shows the tooltip on hover even if disabled.
 * - Renders the tooltip above the button by default.
 * - Renders the tooltip closer to the button by default.
 * - Lowers the opacity of the Button when disabled.
 * - Renders the Button with `line-height: 0` to avoid showing extra
 * vertical space in SVG icons.
 *
 * NOTE TO DEVS: Please keep this component's features synchronized with
 * features available to `TooltippedIconButton`.
 */
function TooltippedButton(props) {
    var _a;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contrasting_tooltip__WEBPACK_IMPORTED_MODULE_2__.ContrastingTooltip, { title: props.tooltip, placement: (_a = props.placement) !== null && _a !== void 0 ? _a : 'top', slotProps: {
            popper: {
                modifiers: [
                    {
                        name: 'offset',
                        options: {
                            offset: [0, -8]
                        }
                    }
                ]
            }
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { cursor: 'default' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { ...props.buttonProps, onClick: props.onClick, disabled: props.disabled, sx: {
                    lineHeight: 0,
                    ...(props.disabled && { opacity: 0.5 }),
                    ...props.sx
                }, "aria-label": props['aria-label'] }, props.children))));
}


/***/ }),

/***/ "./lib/components/mui-extras/tooltipped-icon-button.js":
/*!*************************************************************!*\
  !*** ./lib/components/mui-extras/tooltipped-icon-button.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TooltippedIconButton: () => (/* binding */ TooltippedIconButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contrasting_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contrasting-tooltip */ "./lib/components/mui-extras/contrasting-tooltip.js");



/**
 * A component that renders an MUI `IconButton` with a high-contrast tooltip
 * provided by `ContrastingTooltip`. This component differs from the MUI
 * defaults in the following ways:
 *
 * - Shows the tooltip on hover even if disabled.
 * - Renders the tooltip above the button by default.
 * - Renders the tooltip closer to the button by default.
 * - Lowers the opacity of the IconButton when disabled.
 * - Renders the IconButton with `line-height: 0` to avoid showing extra
 * vertical space in SVG icons.
 *
 * NOTE TO DEVS: Please keep this component's features synchronized with
 * features available to `TooltippedButton`.
 */
function TooltippedIconButton(props) {
    var _a;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contrasting_tooltip__WEBPACK_IMPORTED_MODULE_2__.ContrastingTooltip, { title: props.tooltip, placement: (_a = props.placement) !== null && _a !== void 0 ? _a : 'top', slotProps: {
            popper: {
                modifiers: [
                    {
                        name: 'offset',
                        options: {
                            offset: [0, -8]
                        }
                    }
                ]
            }
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { cursor: 'default' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { ...props.iconButtonProps, onClick: props.onClick, disabled: props.disabled, sx: {
                    lineHeight: 0,
                    ...(props.disabled && { opacity: 0.5 }),
                    ...props.sx
                }, "aria-label": props['aria-label'] }, props.children))));
}


/***/ }),

/***/ "./lib/components/pending-messages.js":
/*!********************************************!*\
  !*** ./lib/components/pending-messages.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PendingMessages: () => (/* binding */ PendingMessages)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chat_messages__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./chat-messages */ "./lib/components/chat-messages.js");



function PendingMessageElement(props) {
    const [dots, setDots] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const interval = setInterval(() => {
            setDots(dots => (dots.length < 3 ? dots + '.' : ''));
        }, 500);
        return () => clearInterval(interval);
    }, []);
    let text = props.text;
    if (props.ellipsis) {
        text = props.text + dots;
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null, text.split('\n').map((line, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { key: index }, line)))));
}
function PendingMessages(props) {
    const [timestamp, setTimestamp] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [agentMessage, setAgentMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (props.messages.length === 0) {
            setAgentMessage(null);
            setTimestamp('');
            return;
        }
        const lastMessage = props.messages[props.messages.length - 1];
        setAgentMessage({
            type: 'agent',
            id: lastMessage.id,
            time: lastMessage.time,
            body: '',
            reply_to: '',
            persona: lastMessage.persona,
            metadata: {}
        });
        // timestamp format copied from ChatMessage
        const newTimestamp = new Date(lastMessage.time * 1000).toLocaleTimeString([], {
            hour: 'numeric',
            minute: '2-digit'
        });
        setTimestamp(newTimestamp);
    }, [props.messages]);
    if (!agentMessage) {
        return null;
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
            padding: 4,
            borderTop: '1px solid var(--jp-border-color2)'
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_chat_messages__WEBPACK_IMPORTED_MODULE_2__.ChatMessageHeader, { message: agentMessage, chatHandler: props.chatHandler, timestamp: timestamp, sx: {
                marginBottom: 4
            } }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
                marginBottom: 1,
                paddingRight: 0,
                color: 'var(--jp-ui-font-color2)',
                '& > :not(:last-child)': {
                    marginBottom: '2em'
                }
            } }, props.messages.map(message => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(PendingMessageElement, { key: message.id, text: message.body, ellipsis: message.ellipsis }))))));
}


/***/ }),

/***/ "./lib/components/rendermime-markdown.js":
/*!***********************************************!*\
  !*** ./lib/components/rendermime-markdown.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RendermimeMarkdown: () => (/* binding */ RendermimeMarkdown)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "webpack/sharing/consume/default/react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _code_blocks_code_toolbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code-blocks/code-toolbar */ "./lib/components/code-blocks/code-toolbar.js");



const MD_MIME_TYPE = 'text/markdown';
const RENDERMIME_MD_CLASS = 'jp-ai-rendermime-markdown';
/**
 * Takes \( and returns \\(. Escapes LaTeX delimeters by adding extra backslashes where needed for proper rendering by @jupyterlab/rendermime.
 */
function escapeLatexDelimiters(text) {
    return text
        .replace(/\\\(/g, '\\\\(')
        .replace(/\\\)/g, '\\\\)')
        .replace(/\\\[/g, '\\\\[')
        .replace(/\\\]/g, '\\\\]');
}
function RendermimeMarkdownBase(props) {
    // create a single renderer object at component mount
    const [renderer] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => {
        return props.rmRegistry.createRenderer(MD_MIME_TYPE);
    });
    // ref that tracks the content container to store the rendermime node in
    const renderingContainer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    // ref that tracks whether the rendermime node has already been inserted
    const renderingInserted = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    // each element is a two-tuple with the structure [codeToolbarRoot, codeToolbarProps].
    const [codeToolbarDefns, setCodeToolbarDefns] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    /**
     * Effect: use Rendermime to render `props.markdownStr` into an HTML element,
     * and insert it into `renderingContainer` if not yet inserted. When the
     * message is completed, add code toolbars.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const renderContent = async () => {
            var _a;
            const mdStr = escapeLatexDelimiters(props.markdownStr);
            const model = props.rmRegistry.createModel({
                data: { [MD_MIME_TYPE]: mdStr }
            });
            await renderer.renderModel(model);
            (_a = props.rmRegistry.latexTypesetter) === null || _a === void 0 ? void 0 : _a.typeset(renderer.node);
            if (!renderer.node) {
                throw new Error('Rendermime was unable to render Markdown content within a chat message. Please report this upstream to Jupyter AI on GitHub.');
            }
            // insert the rendering into renderingContainer if not yet inserted
            if (renderingContainer.current !== null && !renderingInserted.current) {
                renderingContainer.current.appendChild(renderer.node);
                renderingInserted.current = true;
            }
            // if complete, render code toolbars
            if (!props.complete) {
                return;
            }
            const newCodeToolbarDefns = [];
            // Attach CodeToolbar root element to each <pre> block
            const preBlocks = renderer.node.querySelectorAll('pre');
            preBlocks.forEach(preBlock => {
                var _a;
                const codeToolbarRoot = document.createElement('div');
                (_a = preBlock.parentNode) === null || _a === void 0 ? void 0 : _a.insertBefore(codeToolbarRoot, preBlock.nextSibling);
                newCodeToolbarDefns.push([
                    codeToolbarRoot,
                    {
                        code: preBlock.textContent || '',
                        parentMessage: props.parentMessage
                    }
                ]);
            });
            setCodeToolbarDefns(newCodeToolbarDefns);
        };
        renderContent();
    }, [
        props.markdownStr,
        props.complete,
        props.rmRegistry,
        props.parentMessage
    ]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: RENDERMIME_MD_CLASS },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: renderingContainer }),
        // Render a `CodeToolbar` element underneath each code block.
        // We use ReactDOM.createPortal() so each `CodeToolbar` element is able
        // to use the context in the main React tree.
        codeToolbarDefns.map(codeToolbarDefn => {
            const [codeToolbarRoot, codeToolbarProps] = codeToolbarDefn;
            return (0,react_dom__WEBPACK_IMPORTED_MODULE_1__.createPortal)(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_code_blocks_code_toolbar__WEBPACK_IMPORTED_MODULE_2__.CodeToolbar, { ...codeToolbarProps }), codeToolbarRoot);
        })));
}
const RendermimeMarkdown = react__WEBPACK_IMPORTED_MODULE_0___default().memo(RendermimeMarkdownBase);


/***/ }),

/***/ "./lib/components/scroll-container.js":
/*!********************************************!*\
  !*** ./lib/components/scroll-container.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ScrollContainer: () => (/* binding */ ScrollContainer)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Component that handles intelligent scrolling.
 *
 * - If viewport is at the bottom of the overflow container, appending new
 * children keeps the viewport on the bottom of the overflow container.
 *
 * - If viewport is in the middle of the overflow container, appending new
 * children leaves the viewport unaffected.
 *
 * Currently only works for Chrome and Firefox due to reliance on
 * `overflow-anchor`.
 *
 * **References**
 * - https://css-tricks.com/books/greatest-css-tricks/pin-scrolling-to-bottom/
 */
function ScrollContainer(props) {
    const id = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => 'jupyter-ai-scroll-container-' + Date.now().toString(), []);
    /**
     * Effect: Scroll the container to the bottom as soon as it is visible.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const el = document.querySelector(`#${id}`);
        if (!el) {
            return;
        }
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    el.scroll({ top: 999999999 });
                }
            });
        }, { threshold: 1.0 });
        observer.observe(el);
        return () => observer.disconnect();
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { id: id, sx: {
            overflowY: 'scroll',
            '& *': {
                overflowAnchor: 'none'
            },
            ...props.sx
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { minHeight: '100.01%' } }, props.children),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { overflowAnchor: 'auto', height: '1px' } })));
}


/***/ }),

/***/ "./lib/components/select.js":
/*!**********************************!*\
  !*** ./lib/components/select.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Select: () => (/* binding */ Select)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


/**
 * A helpful wrapper around MUI's native `Select` component that provides the
 * following services:
 *
 * - automatically wraps base `Select` component in `FormControl` context and
 * prepends an input label derived from `props.label`.
 *
 * - limits max height of menu
 *
 * - handles `null` values by coercing them to the string `'null'`. The
 * corresponding `MenuItem` should have the value `'null'`.
 */
function Select(props) {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { fullWidth: true },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, null, props.label),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { ...props, value: props.value === null ? 'null' : props.value, label: props.label, onChange: (e, child) => {
                var _a;
                if (e.target.value === 'null') {
                    e.target.value = null;
                }
                (_a = props.onChange) === null || _a === void 0 ? void 0 : _a.call(props, e, child);
            }, MenuProps: { sx: { maxHeight: '50%', minHeight: 400 } } }, props.children)));
}


/***/ }),

/***/ "./lib/components/settings/existing-api-keys.js":
/*!******************************************************!*\
  !*** ./lib/components/settings/existing-api-keys.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExistingApiKeys: () => (/* binding */ ExistingApiKeys)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material */ "webpack/sharing/consume/default/@mui/icons-material/@mui/icons-material");
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_extras_async_icon_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../mui-extras/async-icon-button */ "./lib/components/mui-extras/async-icon-button.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../handler */ "./lib/handler.js");





/**
 * Component that renders a list of existing API keys. Each API key is rendered
 * by a unique `ExistingApiKey` component.
 */
function ExistingApiKeys(props) {
    // current editable API key name, if any.
    const [editableApiKey, setEditableApiKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
            '& > .MuiBox-root:not(:first-child)': {
                marginTop: -2
            }
        } },
        props.apiKeys.map(apiKey => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ExistingApiKey, { key: apiKey, alert: props.alert, apiKey: apiKey, editable: editableApiKey === apiKey, setEditable: setEditableApiKey, onSuccess: props.onSuccess }))),
        props.alert.jsx));
}
/**
 * Component that renders a single existing API key specified by `props.apiKey`.
 * Includes actions for editing and deleting the API key.
 */
function ExistingApiKey(props) {
    const [input, setInput] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [inputVisible, setInputVisible] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    /**
     * Effect: Select the input after `editable` is set to `true`. This needs to
     * be done in an effect because the TextField needs to be rendered with
     * `disabled=false` first. When `editable` is set to `false`, reset any
     * input-related state.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        var _a;
        if (props.editable) {
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }
        else {
            setInput('');
            setInputVisible(false);
            setError(false);
        }
    }, [props.editable]);
    const onEditIntent = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        props.setEditable(props.apiKey);
    }, []);
    const onDelete = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        return _handler__WEBPACK_IMPORTED_MODULE_3__.AiService.deleteApiKey(props.apiKey);
    }, []);
    const toggleInputVisibility = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        setInputVisible(visible => !visible);
    }, []);
    const onEditCancel = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        props.setEditable(null);
    }, []);
    const onEditSubmit = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        return _handler__WEBPACK_IMPORTED_MODULE_3__.AiService.updateConfig({
            api_keys: { [props.apiKey]: input }
        });
    }, [input]);
    const onError = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((emsg) => {
        props.alert.show('error', emsg);
    }, [props.alert]);
    const validateInput = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        if (!props.editable) {
            return;
        }
        setError(!input);
    }, [props.editable, input]);
    const onEditSuccess = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        props.setEditable(null);
        props.alert.show('success', 'API key updated successfully.');
        props.onSuccess();
    }, [props.alert, props.onSuccess]);
    const onDeleteSuccess = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        props.alert.show('success', 'API key deleted successfully.');
        props.onSuccess();
    }, [props.alert, props.onSuccess]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
            display: 'flex',
            alignItems: 'flex-start'
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField
        // core props
        , { 
            // core props
            value: input, onChange: e => setInput(e.target.value), disabled: !props.editable, inputRef: inputRef, 
            // validation props
            onBlur: validateInput, error: error, helperText: 'API key value must not be empty', FormHelperTextProps: {
                sx: {
                    visibility: error ? 'unset' : 'hidden',
                    margin: 0,
                    whiteSpace: 'nowrap'
                }
            }, 
            // style props
            size: "small", variant: "standard", type: inputVisible ? 'text' : 'password', label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("pre", { style: { margin: 0 } }, props.apiKey)), InputProps: {
                endAdornment: props.editable && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputAdornment, { position: "end" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { onClick: toggleInputVisibility, edge: "end", onMouseDown: e => e.preventDefault() }, inputVisible ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.VisibilityOff, null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.Visibility, null))))
            }, sx: {
                flexGrow: 1,
                margin: 0,
                '& .MuiInputBase-input': {
                    padding: 0,
                    paddingBottom: 1
                }
            } }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { marginTop: '11px', marginLeft: 2, whiteSpace: 'nowrap' } }, props.editable ? (
        // 16px margin top - 5px padding
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { onClick: onEditCancel, onMouseDown: e => e.preventDefault() },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.Cancel, null)),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_async_icon_button__WEBPACK_IMPORTED_MODULE_4__.AsyncIconButton, { onClick: onEditSubmit, onError: onError, onSuccess: onEditSuccess, onMouseDown: e => e.preventDefault(), confirm: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.Check, { color: "success" })))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { onClick: onEditIntent },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.Edit, null)),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_extras_async_icon_button__WEBPACK_IMPORTED_MODULE_4__.AsyncIconButton, { onClick: onDelete, onError: onError, onSuccess: onDeleteSuccess, confirm: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material__WEBPACK_IMPORTED_MODULE_2__.DeleteOutline, { color: "error" })))))));
}


/***/ }),

/***/ "./lib/components/settings/minify.js":
/*!*******************************************!*\
  !*** ./lib/components/settings/minify.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   minifyPatchObject: () => (/* binding */ minifyPatchObject),
/* harmony export */   minifyUpdate: () => (/* binding */ minifyUpdate)
/* harmony export */ });
/**
 * Function that minimizes the `UpdateConfigRequest` object prior to submission.
 * Removes properties with values identical to those specified in the server
 * configuration.
 */
function minifyUpdate(config, update) {
    return minifyPatchObject(config, update);
}
/**
 * Function that removes all properties from `patch` that have identical values
 * to `obj` recursively.
 */
function minifyPatchObject(obj, patch) {
    var _a;
    const diffObj = {};
    for (const key in patch) {
        if (!(key in obj) || typeof obj[key] !== typeof patch[key]) {
            // if key is not present in oldObj, or if the value types do not match,
            // use the value of `patch`.
            diffObj[key] = patch[key];
            continue;
        }
        const objVal = obj[key];
        const patchVal = patch[key];
        if (Array.isArray(objVal) && Array.isArray(patchVal)) {
            // if objects are both arrays but are not equal, then use the value
            const areNotEqual = objVal.length !== patchVal.length ||
                !objVal.every((objVal_i, i) => objVal_i === patchVal[i]);
            if (areNotEqual) {
                diffObj[key] = patchVal;
            }
        }
        else if (typeof patchVal === 'object') {
            // if the value is an object, run `diffObjects` recursively.
            const childPatch = minifyPatchObject(objVal, patchVal);
            const isNonEmpty = !!((_a = Object.keys(childPatch)) === null || _a === void 0 ? void 0 : _a.length);
            if (isNonEmpty) {
                diffObj[key] = childPatch;
            }
        }
        else if (objVal !== patchVal) {
            // otherwise, use the value of `patch` only if it differs.
            diffObj[key] = patchVal;
        }
    }
    return diffObj;
}


/***/ }),

/***/ "./lib/components/settings/model-fields.js":
/*!*************************************************!*\
  !*** ./lib/components/settings/model-fields.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ModelField: () => (/* binding */ ModelField),
/* harmony export */   ModelFields: () => (/* binding */ ModelFields)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


function ModelField(props) {
    var _a;
    const [errorMessage, setErrorMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const value = (_a = props.values) === null || _a === void 0 ? void 0 : _a[props.field.key];
    function handleChange(e) {
        if (!('format' in props.field)) {
            return;
        }
        // Perform validation based on the field format
        switch (props.field.format) {
            case 'json':
                try {
                    // JSON.parse does not allow single quotes or trailing commas
                    JSON.parse(e.target.value);
                    setErrorMessage(null);
                }
                catch (exc) {
                    setErrorMessage('You must specify a value in JSON format.');
                }
                break;
            case 'jsonpath':
                // TODO: Do JSONPath validation
                break;
            default:
                // No validation performed
                break;
        }
        props.onChange({
            ...props.values,
            [props.field.key]: e.target.value
        });
    }
    if (props.field.type === 'integer') {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { label: props.field.label, value: value, onChange: handleChange, inputProps: { inputMode: 'numeric', pattern: '[0-9]*' }, fullWidth: true }));
    }
    if (props.field.type === 'text') {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { label: props.field.label, value: value !== null && value !== void 0 ? value : '', onChange: handleChange, error: !!errorMessage, helperText: errorMessage !== null && errorMessage !== void 0 ? errorMessage : undefined, fullWidth: true }));
    }
    if (props.field.type === 'text-multiline') {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { label: props.field.label, value: value !== null && value !== void 0 ? value : '', onChange: handleChange, fullWidth: true, multiline: true, error: !!errorMessage, helperText: errorMessage !== null && errorMessage !== void 0 ? errorMessage : undefined, minRows: 2 }));
    }
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null);
}
function ModelFields(props) {
    var _a;
    if (!((_a = props.fields) === null || _a === void 0 ? void 0 : _a.length)) {
        return null;
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, props.fields.map((field, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ModelField, { ...props, field: field, key: idx, values: props.values, onChange: props.onChange })))));
}


/***/ }),

/***/ "./lib/components/settings/use-server-info.js":
/*!****************************************************!*\
  !*** ./lib/components/settings/use-server-info.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ServerInfoState: () => (/* binding */ ServerInfoState),
/* harmony export */   useServerInfo: () => (/* binding */ useServerInfo)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../handler */ "./lib/handler.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils */ "./lib/utils.js");



var ServerInfoState;
(function (ServerInfoState) {
    /**
     * Server info is being fetched.
     */
    ServerInfoState[ServerInfoState["Loading"] = 0] = "Loading";
    /**
     * Unable to retrieve server info.
     */
    ServerInfoState[ServerInfoState["Error"] = 1] = "Error";
    /**
     * Server info was loaded successfully.
     */
    ServerInfoState[ServerInfoState["Ready"] = 2] = "Ready";
})(ServerInfoState || (ServerInfoState = {}));
/**
 * A hook that fetches the current configuration and provider lists from the
 * server. Returns a `ServerInfo` object that includes methods.
 */
function useServerInfo() {
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(ServerInfoState.Loading);
    const [serverInfoProps, setServerInfoProps] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const fetchServerInfo = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        var _a, _b;
        try {
            const [config, lmProviders, emProviders] = await Promise.all([
                _handler__WEBPACK_IMPORTED_MODULE_1__.AiService.getConfig(),
                _handler__WEBPACK_IMPORTED_MODULE_1__.AiService.listLmProviders(),
                _handler__WEBPACK_IMPORTED_MODULE_1__.AiService.listEmProviders()
            ]);
            const lmGid = config.model_provider_id;
            const emGid = config.embeddings_provider_id;
            const lmProvider = lmGid === null ? null : getProvider(lmGid, lmProviders);
            const emProvider = emGid === null ? null : getProvider(emGid, emProviders);
            const lmLocalId = (_a = (lmGid && (0,_utils__WEBPACK_IMPORTED_MODULE_2__.getModelLocalId)(lmGid))) !== null && _a !== void 0 ? _a : '';
            const cLmGid = config.completions_model_provider_id;
            const cLmProvider = cLmGid === null ? null : getProvider(cLmGid, lmProviders);
            const cLmLocalId = (_b = (cLmGid && (0,_utils__WEBPACK_IMPORTED_MODULE_2__.getModelLocalId)(cLmGid))) !== null && _b !== void 0 ? _b : '';
            setServerInfoProps({
                config,
                lmProviders,
                emProviders,
                chat: {
                    lmProvider,
                    emProvider,
                    lmLocalId
                },
                completions: {
                    lmProvider: cLmProvider,
                    lmLocalId: cLmLocalId
                }
            });
            setState(ServerInfoState.Ready);
        }
        catch (e) {
            console.error(e);
            if (e instanceof Error) {
                setError(e.toString());
            }
            else {
                setError('An unknown error occurred.');
            }
            setState(ServerInfoState.Error);
        }
    }, []);
    const refetchApiKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        if (!serverInfoProps) {
            // this should never happen.
            return;
        }
        const config = await _handler__WEBPACK_IMPORTED_MODULE_1__.AiService.getConfig();
        setServerInfoProps({
            ...serverInfoProps,
            config: {
                ...serverInfoProps.config,
                api_keys: config.api_keys,
                last_read: config.last_read
            }
        });
    }, [serverInfoProps]);
    /**
     * Effect: fetch server info on initial render
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        fetchServerInfo();
    }, []);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        if (state === ServerInfoState.Loading) {
            return { state };
        }
        if (state === ServerInfoState.Error || !serverInfoProps) {
            return { state: ServerInfoState.Error, error };
        }
        return {
            state,
            ...serverInfoProps,
            refetchAll: fetchServerInfo,
            refetchApiKeys
        };
    }, [state, serverInfoProps, error, refetchApiKeys]);
}
function getProvider(gid, providers) {
    const providerId = (0,_utils__WEBPACK_IMPORTED_MODULE_2__.getProviderId)(gid);
    const provider = providers.providers.find(p => p.id === providerId);
    return provider !== null && provider !== void 0 ? provider : null;
}


/***/ }),

/***/ "./lib/components/statusbar-item.js":
/*!******************************************!*\
  !*** ./lib/components/statusbar-item.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JaiStatusItem: () => (/* binding */ JaiStatusItem)
/* harmony export */ });
/* harmony import */ var _jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/statusbar */ "webpack/sharing/consume/default/@jupyterlab/statusbar");
/* harmony import */ var _jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../icons */ "./lib/icons.js");





/**
 * The Jupyter AI status item, shown in the status bar on the bottom right by
 * default.
 */
class JaiStatusItem extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.VDomRenderer {
    constructor(options) {
        super(new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.VDomModel());
        /**
         * Create a menu for viewing status and changing options.
         */
        this._handleClick = () => {
            if (this._popup) {
                this._popup.dispose();
            }
            if (this._menu) {
                this._menu.dispose();
            }
            this._menu = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.RankedMenu({
                commands: this._commandRegistry,
                renderer: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.MenuSvg.defaultRenderer
            });
            for (const item of this._items) {
                this._menu.addItem(item);
            }
            this._popup = (0,_jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_0__.showPopup)({
                body: this._menu,
                anchor: this,
                align: 'left'
            });
        };
        this._menu = null;
        this._popup = null;
        this._commandRegistry = options.commandRegistry;
        this._items = [];
        this.addClass('jp-mod-highlighted');
        this.title.caption = 'Open Jupyternaut status menu';
        this.node.addEventListener('click', this._handleClick);
    }
    /**
     * Adds a menu item to the JAI status item.
     */
    addItem(item) {
        this._items.push(item);
    }
    /**
     * Returns whether the status item has any menu items.
     */
    hasItems() {
        return this._items.length !== 0;
    }
    /**
     * Returns the status item as a JSX element.
     */
    render() {
        if (!this.model) {
            return null;
        }
        return react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_3__.Jupyternaut, { top: '2px', width: '16px', stylesheet: 'statusBar' });
    }
    dispose() {
        this.node.removeEventListener('click', this._handleClick);
        super.dispose();
    }
}


/***/ }),

/***/ "./lib/contexts/active-cell-context.js":
/*!*********************************************!*\
  !*** ./lib/contexts/active-cell-context.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActiveCellContextProvider: () => (/* binding */ ActiveCellContextProvider),
/* harmony export */   ActiveCellManager: () => (/* binding */ ActiveCellManager),
/* harmony export */   useActiveCellContext: () => (/* binding */ useActiveCellContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_3__);




function getNotebook(widget) {
    if (!(widget instanceof _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_1__.DocumentWidget)) {
        return null;
    }
    const { content } = widget;
    if (!(content instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.Notebook)) {
        return null;
    }
    return content;
}
function getActiveCell(widget) {
    const notebook = getNotebook(widget);
    //const cellModels = notebook?.model?.cells;
    // if(cellModels != null)
    // for (let i = 0; i < cellModels.length; i++) {
    //  // const cellModel = cellModels.get(i);
    //  // console.log(cellModel.sharedModel.getSource());
    // }
    if (!notebook) {
        return null;
    }
    return notebook.activeCell;
}
/**
 * A manager that maintains a reference to the current active notebook cell in
 * the main panel (if any), and provides methods for inserting or appending
 * content to the active cell.
 *
 * The current active cell should be obtained by listening to the
 * `activeCellChanged` signal.
 */
class ActiveCellManager {
    constructor(shell) {
        var _a;
        this._mainAreaWidget = null;
        /**
         * The active cell.
         */
        this._activeCell = null;
        /**
         * The execution count of the active cell. This is the number shown on the
         * left in square brackets after running a cell. Changes to this indicate that
         * the error output may have changed.
         */
        this._activeCellExecutionCount = null;
        /**
         * The `CellError` output within the active cell, if any.
         */
        this._activeCellError = null;
        this._activeCellChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this._activeCellErrorChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this._shell = shell;
        (_a = this._shell.currentChanged) === null || _a === void 0 ? void 0 : _a.connect((sender, args) => {
            this._mainAreaWidget = args.newValue;
        });
        setInterval(() => {
            this._pollActiveCell();
        }, 200);
    }
    get activeCellChanged() {
        return this._activeCellChanged;
    }
    get activeCellErrorChanged() {
        return this._activeCellErrorChanged;
    }
    getContent(withError = false) {
        var _a;
        const sharedModel = (_a = this._activeCell) === null || _a === void 0 ? void 0 : _a.model.sharedModel;
        if (!sharedModel) {
            return null;
        }
        // case where withError = false
        if (!withError) {
            return {
                type: sharedModel.cell_type,
                source: sharedModel.getSource()
            };
        }
        // case where withError = true
        const error = this._activeCellError;
        if (error) {
            return {
                type: 'code',
                source: sharedModel.getSource(),
                error: {
                    name: error.ename,
                    value: error.evalue,
                    traceback: error.traceback
                }
            };
        }
        return null;
    }
    /**
     * Inserts `content` in a new cell above the active cell.
     */
    insertAbove(content) {
        const notebook = getNotebook(this._mainAreaWidget);
        if (!notebook) {
            return;
        }
        // create a new cell above the active cell and mark new cell as active
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookActions.insertAbove(notebook);
        // emit activeCellChanged event to consumers
        this._pollActiveCell();
        // replace content of this new active cell
        this.replace(content);
    }
    /**
     * Inserts `content` in a new cell below the active cell.
     */
    insertBelow(content) {
        const notebook = getNotebook(this._mainAreaWidget);
        if (!notebook) {
            return;
        }
        // create a new cell below the active cell and mark new cell as active
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookActions.insertBelow(notebook);
        // emit activeCellChanged event to consumers
        this._pollActiveCell();
        // replace content of this new active cell
        this.replace(content);
    }
    /**
     * Replaces the contents of the active cell.
     */
    async replace(content) {
        var _a, _b;
        // get reference to active cell directly from Notebook API. this avoids the
        // possibility of acting on an out-of-date reference.
        const activeCell = (_a = getNotebook(this._mainAreaWidget)) === null || _a === void 0 ? void 0 : _a.activeCell;
        if (!activeCell) {
            return;
        }
        // wait for editor to be ready
        await activeCell.ready;
        // replace the content of the active cell
        /**
         * NOTE: calling this method sometimes emits an error to the browser console:
         *
         * ```
         * Error: Calls to EditorView.update are not allowed while an update is in progress
         * ```
         *
         * However, there seems to be no impact on the behavior/stability of the
         * JupyterLab application after this error is logged. Furthermore, this is
         * the official API for setting the content of a cell in JupyterLab 4,
         * meaning that this is likely unavoidable.
         */
        (_b = activeCell.editor) === null || _b === void 0 ? void 0 : _b.model.sharedModel.setSource(content);
    }
    _pollActiveCell() {
        const prevActiveCell = this._activeCell;
        const currActiveCell = getActiveCell(this._mainAreaWidget);
        // emit activeCellChanged when active cell changes
        if (prevActiveCell !== currActiveCell) {
            this._activeCell = currActiveCell;
            this._activeCellChanged.emit(currActiveCell);
        }
        const currSharedModel = currActiveCell === null || currActiveCell === void 0 ? void 0 : currActiveCell.model.sharedModel;
        const prevExecutionCount = this._activeCellExecutionCount;
        const currExecutionCount = currSharedModel && 'execution_count' in currSharedModel
            ? currSharedModel === null || currSharedModel === void 0 ? void 0 : currSharedModel.execution_count
            : null;
        this._activeCellExecutionCount = currExecutionCount;
        // emit activeCellErrorChanged when active cell changes or when the
        // execution count changes
        if (prevActiveCell !== currActiveCell ||
            prevExecutionCount !== currExecutionCount) {
            const prevActiveCellError = this._activeCellError;
            let currActiveCellError = null;
            if (currSharedModel && 'outputs' in currSharedModel) {
                currActiveCellError =
                    currSharedModel.outputs.find((output) => output.output_type === 'error') || null;
            }
            // for some reason, the `CellError` object is not referentially stable,
            // meaning that this condition always evaluates to `true` and the
            // `activeCellErrorChanged` signal is emitted every 200ms, even when the
            // error output is unchanged. this is why we have to rely on
            // `execution_count` to track changes to the error output.
            if (prevActiveCellError !== currActiveCellError) {
                this._activeCellError = currActiveCellError;
                this._activeCellErrorChanged.emit(this._activeCellError);
            }
        }
    }
}
const defaultActiveCellContext = {
    exists: false,
    hasError: false,
    manager: null
};
const ActiveCellContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(defaultActiveCellContext);
function ActiveCellContextProvider(props) {
    const [exists, setExists] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [hasError, setHasError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const manager = props.activeCellManager;
        manager.activeCellChanged.connect((_, newActiveCell) => {
            setExists(!!newActiveCell);
        });
        manager.activeCellErrorChanged.connect((_, newActiveCellError) => {
            setHasError(!!newActiveCellError);
        });
    }, [props.activeCellManager]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ActiveCellContext.Provider, { value: {
            exists,
            hasError,
            manager: props.activeCellManager
        } }, props.children));
}
/**
 * Usage: `const activeCell = useActiveCellContext()`
 *
 * Returns an object `activeCell` with the following properties:
 * - `activeCell.exists`: whether an active cell exists
 * - `activeCell.hasError`: whether an active cell exists with an error output
 * - `activeCell.manager`: the `ActiveCellManager` singleton
 */
function useActiveCellContext() {
    const { exists, hasError, manager } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(ActiveCellContext);
    if (!manager) {
        throw new Error('useActiveCellContext() cannot be called outside ActiveCellContextProvider.');
    }
    return {
        exists,
        hasError,
        manager
    };
}


/***/ }),

/***/ "./lib/contexts/all-notebook-context.js":
/*!**********************************************!*\
  !*** ./lib/contexts/all-notebook-context.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotebookSelectionContextProvider: () => (/* binding */ NotebookSelectionContextProvider),
/* harmony export */   useNotebookSelectionContext: () => (/* binding */ useNotebookSelectionContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const NotebookSelectionContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)([
    [],
    () => {
    }
]);
function useNotebookSelectionContext() {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(NotebookSelectionContext);
}
function NotebookSelectionContextProvider({ children, notebookWatcher }) {
    const [selections, setSelections] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        notebookWatcher.selectionChanged.connect((sender, newSelections) => {
            if (newSelections) {
                setSelections(newSelections);
            }
        });
    }, [notebookWatcher]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(NotebookSelectionContext.Provider, { value: [selections, setSelections] }, children));
}


/***/ }),

/***/ "./lib/contexts/collaborators-context.js":
/*!***********************************************!*\
  !*** ./lib/contexts/collaborators-context.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CollaboratorsContextProvider: () => (/* binding */ CollaboratorsContextProvider),
/* harmony export */   useCollaboratorsContext: () => (/* binding */ useCollaboratorsContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const CollaboratorsContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext({});
/**
 * Returns a dictionary mapping each collaborator's username to their associated
 * Collaborator object.
 */
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
function useCollaboratorsContext() {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(CollaboratorsContext);
}
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
function CollaboratorsContextProvider({ globalAwareness, children }) {
    const [collaborators, setCollaborators] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    /**
     * Effect: listen to changes in global awareness and update collaborators
     * dictionary.
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        function handleChange() {
            var _a;
            const states = ((_a = globalAwareness === null || globalAwareness === void 0 ? void 0 : globalAwareness.getStates()) !== null && _a !== void 0 ? _a : new Map());
            const collaboratorsDict = {};
            states.forEach(state => {
                collaboratorsDict[state.user.username] = state.user;
            });
            setCollaborators(collaboratorsDict);
        }
        globalAwareness === null || globalAwareness === void 0 ? void 0 : globalAwareness.on('change', handleChange);
        return () => {
            globalAwareness === null || globalAwareness === void 0 ? void 0 : globalAwareness.off('change', handleChange);
        };
    }, [globalAwareness]);
    if (!globalAwareness) {
        return children;
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(CollaboratorsContext.Provider, { value: collaborators }, children));
}


/***/ }),

/***/ "./lib/contexts/index.js":
/*!*******************************!*\
  !*** ./lib/contexts/index.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActiveCellContextProvider: () => (/* reexport safe */ _active_cell_context__WEBPACK_IMPORTED_MODULE_0__.ActiveCellContextProvider),
/* harmony export */   ActiveCellManager: () => (/* reexport safe */ _active_cell_context__WEBPACK_IMPORTED_MODULE_0__.ActiveCellManager),
/* harmony export */   CollaboratorsContextProvider: () => (/* reexport safe */ _collaborators_context__WEBPACK_IMPORTED_MODULE_1__.CollaboratorsContextProvider),
/* harmony export */   SelectionContextProvider: () => (/* reexport safe */ _selection_context__WEBPACK_IMPORTED_MODULE_2__.SelectionContextProvider),
/* harmony export */   TelemetryContextProvider: () => (/* reexport safe */ _telemetry_context__WEBPACK_IMPORTED_MODULE_3__.TelemetryContextProvider),
/* harmony export */   useActiveCellContext: () => (/* reexport safe */ _active_cell_context__WEBPACK_IMPORTED_MODULE_0__.useActiveCellContext),
/* harmony export */   useCollaboratorsContext: () => (/* reexport safe */ _collaborators_context__WEBPACK_IMPORTED_MODULE_1__.useCollaboratorsContext),
/* harmony export */   useSelectionContext: () => (/* reexport safe */ _selection_context__WEBPACK_IMPORTED_MODULE_2__.useSelectionContext),
/* harmony export */   useTelemetry: () => (/* reexport safe */ _telemetry_context__WEBPACK_IMPORTED_MODULE_3__.useTelemetry)
/* harmony export */ });
/* harmony import */ var _active_cell_context__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./active-cell-context */ "./lib/contexts/active-cell-context.js");
/* harmony import */ var _collaborators_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./collaborators-context */ "./lib/contexts/collaborators-context.js");
/* harmony import */ var _selection_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./selection-context */ "./lib/contexts/selection-context.js");
/* harmony import */ var _telemetry_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./telemetry-context */ "./lib/contexts/telemetry-context.js");






/***/ }),

/***/ "./lib/contexts/selection-context.js":
/*!*******************************************!*\
  !*** ./lib/contexts/selection-context.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectionContextProvider: () => (/* binding */ SelectionContextProvider),
/* harmony export */   useSelectionContext: () => (/* binding */ useSelectionContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const SelectionContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext([
    null,
    () => {
        /* noop */
    }
]);
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
function useSelectionContext() {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(SelectionContext);
}
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
function SelectionContextProvider({ selectionWatcher, children }) {
    const [selection, setSelection] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    /**
     * Effect: subscribe to SelectionWatcher
     */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        selectionWatcher.selectionChanged.connect((sender, newSelection) => {
            setSelection(newSelection);
        });
    }, []);
    const replaceSelection = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((value) => {
        selectionWatcher.replaceSelection(value);
    }, [selectionWatcher]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SelectionContext.Provider, { value: [selection, replaceSelection] }, children));
}


/***/ }),

/***/ "./lib/contexts/telemetry-context.js":
/*!*******************************************!*\
  !*** ./lib/contexts/telemetry-context.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TelemetryContextProvider: () => (/* binding */ TelemetryContextProvider),
/* harmony export */   useTelemetry: () => (/* binding */ useTelemetry)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const defaultTelemetryHandler = {
    onEvent: e => {
        /* no-op */
    }
};
const TelemetryContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(defaultTelemetryHandler);
/**
 * Retrieves a reference to the current telemetry handler for Jupyter AI events
 * returned by another plugin providing the `IJaiTelemetryHandler` token. If
 * none exists, then the default telemetry handler is returned, which does
 * nothing when `onEvent()` is called.
 */
function useTelemetry() {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(TelemetryContext);
}
function TelemetryContextProvider(props) {
    var _a;
    const [telemetryHandler] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((_a = props.telemetryHandler) !== null && _a !== void 0 ? _a : defaultTelemetryHandler);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(TelemetryContext.Provider, { value: telemetryHandler }, props.children));
}


/***/ }),

/***/ "./lib/contexts/user-context.js":
/*!**************************************!*\
  !*** ./lib/contexts/user-context.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserContextProvider: () => (/* binding */ UserContextProvider),
/* harmony export */   useUserContext: () => (/* binding */ useUserContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const UserContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(null);
function useUserContext() {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(UserContext);
}
function UserContextProvider({ userManager, children }) {
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        userManager.ready.then(() => {
            setUser({
                identity: userManager.identity,
                permissions: userManager.permissions
            });
        });
        userManager.userChanged.connect((sender, newUser) => {
            setUser(newUser);
        });
    }, []);
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(UserContext.Provider, { value: user }, children);
}


/***/ }),

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AiService: () => (/* binding */ AiService),
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


const API_NAMESPACE = 'api/ai';
/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, API_NAMESPACE, endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}
var AiService;
(function (AiService) {
    async function getConfig() {
        return requestAPI('config');
    }
    AiService.getConfig = getConfig;
    async function listLmProviders() {
        return requestAPI('providers');
    }
    AiService.listLmProviders = listLmProviders;
    async function listEmProviders() {
        return requestAPI('providers/embeddings');
    }
    AiService.listEmProviders = listEmProviders;
    async function updateConfig(config) {
        return requestAPI('config', {
            method: 'POST',
            body: JSON.stringify(config)
        });
    }
    AiService.updateConfig = updateConfig;
    async function deleteApiKey(keyName) {
        return requestAPI(`api_keys/${keyName}`, {
            method: 'DELETE'
        });
    }
    AiService.deleteApiKey = deleteApiKey;
    async function listSlashCommands() {
        return requestAPI('chats/slash_commands');
    }
    AiService.listSlashCommands = listSlashCommands;
    async function listAutocompleteOptions() {
        return requestAPI('chats/autocomplete_options');
    }
    AiService.listAutocompleteOptions = listAutocompleteOptions;
    async function listAutocompleteArgOptions(partialCommand) {
        return requestAPI('chats/autocomplete_options?partialCommand=' +
            encodeURIComponent(partialCommand));
    }
    AiService.listAutocompleteArgOptions = listAutocompleteArgOptions;
})(AiService || (AiService = {}));


/***/ }),

/***/ "./lib/hooks/use-copy.js":
/*!*******************************!*\
  !*** ./lib/hooks/use-copy.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CopyStatus: () => (/* binding */ CopyStatus),
/* harmony export */   useCopy: () => (/* binding */ useCopy)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var CopyStatus;
(function (CopyStatus) {
    CopyStatus[CopyStatus["None"] = 0] = "None";
    CopyStatus[CopyStatus["Copying"] = 1] = "Copying";
    CopyStatus[CopyStatus["Copied"] = 2] = "Copied";
})(CopyStatus || (CopyStatus = {}));
const DEFAULT_LABELS_BY_COPY_STATUS = {
    [CopyStatus.None]: 'Copy to clipboard',
    [CopyStatus.Copying]: 'Copying…',
    [CopyStatus.Copied]: 'Copied!'
};
/**
 * Hook that provides a function to copy a string to a clipboard and manages
 * related UI state. Should be used by any button that intends to copy text.
 */
function useCopy(props) {
    const [copyStatus, setCopyStatus] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(CopyStatus.None);
    const timeoutId = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const copy = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (value) => {
        // ignore if we are already copying
        if (copyStatus === CopyStatus.Copying) {
            return;
        }
        try {
            await navigator.clipboard.writeText(value);
        }
        catch (err) {
            console.error('Failed to copy text: ', err);
            setCopyStatus(CopyStatus.None);
            return;
        }
        setCopyStatus(CopyStatus.Copied);
        if (timeoutId.current) {
            clearTimeout(timeoutId.current);
        }
        timeoutId.current = setTimeout(() => setCopyStatus(CopyStatus.None), 1000);
    }, [copyStatus]);
    const copyLabel = {
        ...DEFAULT_LABELS_BY_COPY_STATUS,
        ...props === null || props === void 0 ? void 0 : props.labelOverrides
    }[copyStatus];
    return {
        copyStatus,
        copyLabel,
        copy
    };
}


/***/ }),

/***/ "./lib/hooks/use-replace.js":
/*!**********************************!*\
  !*** ./lib/hooks/use-replace.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useReplace: () => (/* binding */ useReplace)
/* harmony export */ });
/* harmony import */ var _contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../contexts/active-cell-context */ "./lib/contexts/active-cell-context.js");
/* harmony import */ var _contexts_selection_context__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../contexts/selection-context */ "./lib/contexts/selection-context.js");


/**
 * Hook that provides a function to either replace a text selection or an active
 * cell. Manages related UI state. Should be used by any button that intends to
 * replace some user selection.
 */
function useReplace() {
    const [textSelection, replaceTextSelection] = (0,_contexts_selection_context__WEBPACK_IMPORTED_MODULE_0__.useSelectionContext)();
    const activeCell = (0,_contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_1__.useActiveCellContext)();
    const replace = (value) => {
        if (textSelection) {
            replaceTextSelection({ ...textSelection, text: value });
        }
        else if (activeCell.exists) {
            activeCell.manager.replace(value);
        }
    };
    const replaceDisabled = !(textSelection || activeCell.exists);
    const numLines = (textSelection === null || textSelection === void 0 ? void 0 : textSelection.text.split('\n').length) || 0;
    const replaceLabel = textSelection
        ? `Replace selection (${numLines} ${numLines === 1 ? 'line' : 'lines'})`
        : activeCell.exists
            ? 'Replace selection (1 active cell)'
            : 'Replace selection (no selection or active cell)';
    return {
        replace,
        replaceDisabled,
        replaceLabel
    };
}


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Jupyternaut: () => (/* binding */ Jupyternaut),
/* harmony export */   chatIcon: () => (/* binding */ chatIcon),
/* harmony export */   includeSelectionIcon: () => (/* binding */ includeSelectionIcon),
/* harmony export */   jupyternautIcon: () => (/* binding */ jupyternautIcon),
/* harmony export */   replaceCellIcon: () => (/* binding */ replaceCellIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_chat_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../style/icons/chat.svg */ "./style/icons/chat.svg");
/* harmony import */ var _style_icons_jupyternaut_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../style/icons/jupyternaut.svg */ "./style/icons/jupyternaut.svg");
/* harmony import */ var _style_icons_replace_cell_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/icons/replace-cell.svg */ "./style/icons/replace-cell.svg");
/* harmony import */ var _style_icons_include_selection_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/icons/include-selection.svg */ "./style/icons/include-selection.svg");
// This file is based on iconimports.ts in @jupyterlab/ui-components, but is manually generated.





const chatIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'jupyter-ai::chat',
    svgstr: _style_icons_chat_svg__WEBPACK_IMPORTED_MODULE_1__
});
const jupyternautIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'jupyter-ai::jupyternaut',
    svgstr: _style_icons_jupyternaut_svg__WEBPACK_IMPORTED_MODULE_2__
});
const replaceCellIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'jupyter-ai::replace-cell',
    svgstr: _style_icons_replace_cell_svg__WEBPACK_IMPORTED_MODULE_3__
});
const includeSelectionIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'jupyter-ai::include-selection',
    svgstr: _style_icons_include_selection_svg__WEBPACK_IMPORTED_MODULE_4__
});
// this icon is only used in the status bar.
// to configure the icon shown on agent replies in the chat UI, please specify a
// custom `Persona`.
const Jupyternaut = jupyternautIcon.react;


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActiveCellContextProvider: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.ActiveCellContextProvider),
/* harmony export */   ActiveCellManager: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.ActiveCellManager),
/* harmony export */   CollaboratorsContextProvider: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.CollaboratorsContextProvider),
/* harmony export */   CommandIDs: () => (/* binding */ CommandIDs),
/* harmony export */   IJaiCompletionProvider: () => (/* reexport safe */ _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiCompletionProvider),
/* harmony export */   IJaiCore: () => (/* reexport safe */ _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiCore),
/* harmony export */   IJaiMessageFooter: () => (/* reexport safe */ _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiMessageFooter),
/* harmony export */   IJaiStatusItem: () => (/* reexport safe */ _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiStatusItem),
/* harmony export */   IJaiTelemetryHandler: () => (/* reexport safe */ _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiTelemetryHandler),
/* harmony export */   SelectionContextProvider: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.SelectionContextProvider),
/* harmony export */   TelemetryContextProvider: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.TelemetryContextProvider),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   useActiveCellContext: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.useActiveCellContext),
/* harmony export */   useCollaboratorsContext: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.useCollaboratorsContext),
/* harmony export */   useSelectionContext: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.useSelectionContext),
/* harmony export */   useTelemetry: () => (/* reexport safe */ _contexts__WEBPACK_IMPORTED_MODULE_15__.useTelemetry)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyter_collaboration__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyter/collaboration */ "webpack/sharing/consume/default/@jupyter/collaboration/@jupyter/collaboration");
/* harmony import */ var _jupyter_collaboration__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyter_collaboration__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _widgets_chat_sidebar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./widgets/chat-sidebar */ "./lib/widgets/chat-sidebar.js");
/* harmony import */ var _selection_watcher__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./selection-watcher */ "./lib/selection-watcher.js");
/* harmony import */ var _chat_handler__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./chat_handler */ "./lib/chat_handler.js");
/* harmony import */ var _widgets_chat_error__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./widgets/chat-error */ "./lib/widgets/chat-error.js");
/* harmony import */ var _completions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./completions */ "./lib/completions/plugin.js");
/* harmony import */ var _status__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./status */ "./lib/status.js");
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tokens */ "./lib/tokens.js");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/rendermime */ "webpack/sharing/consume/default/@jupyterlab/rendermime");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./contexts/active-cell-context */ "./lib/contexts/active-cell-context.js");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _plugins_menu_plugin__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./plugins/menu-plugin */ "./lib/plugins/menu-plugin.js");
/* harmony import */ var _notebook_watcher__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./notebook-watcher */ "./lib/notebook-watcher.js");
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./contexts */ "./lib/contexts/index.js");















var CommandIDs;
(function (CommandIDs) {
    /**
     * Command to focus the input.
     */
    CommandIDs.focusChatInput = 'jupyter-ai:focus-chat-input';
})(CommandIDs || (CommandIDs = {}));
/**
 * Initialization data for the jupyter_ai extension.
 */
const plugin = {
    id: '@jupyter-ai/core:plugin',
    autoStart: true,
    requires: [_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_3__.IRenderMimeRegistry],
    optional: [
        _jupyter_collaboration__WEBPACK_IMPORTED_MODULE_2__.IGlobalAwareness,
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer,
        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.IThemeManager,
        _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiCompletionProvider,
        _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiMessageFooter,
        _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiTelemetryHandler
    ],
    provides: _tokens__WEBPACK_IMPORTED_MODULE_5__.IJaiCore,
    activate: async (app, rmRegistry, globalAwareness, restorer, themeManager, completionProvider, messageFooter, telemetryHandler) => {
        /**
         * Initialize selection watcher singleton
         */
        const selectionWatcher = new _selection_watcher__WEBPACK_IMPORTED_MODULE_6__.SelectionWatcher(app.shell);
        const notebookWatcher = new _notebook_watcher__WEBPACK_IMPORTED_MODULE_7__.NotebookWatcher(app.shell);
        notebookWatcher.selectionChanged.connect((sender, selections) => {
        });
        /**
         * Initialize active cell manager singleton
         */
        const activeCellManager = new _contexts_active_cell_context__WEBPACK_IMPORTED_MODULE_8__.ActiveCellManager(app.shell);
        /**
         * Initialize chat handler, open WS connection
         */
        const chatHandler = new _chat_handler__WEBPACK_IMPORTED_MODULE_9__.ChatHandler();
        const openInlineCompleterSettings = () => {
            app.commands.execute('settingeditor:open', {
                query: 'Inline Completer'
            });
        };
        const focusInputSignal = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_4__.Signal({});
        let chatWidget;
        try {
            await chatHandler.initialize();
            chatWidget = (0,_widgets_chat_sidebar__WEBPACK_IMPORTED_MODULE_10__.buildChatSidebar)(selectionWatcher, notebookWatcher, chatHandler, globalAwareness, themeManager, rmRegistry, completionProvider, openInlineCompleterSettings, activeCellManager, focusInputSignal, messageFooter, telemetryHandler, app.serviceManager.user);
        }
        catch (e) {
            chatWidget = (0,_widgets_chat_error__WEBPACK_IMPORTED_MODULE_11__.buildErrorWidget)(themeManager);
        }
        /**
         * Add Chat widget to right sidebar
         */
        app.shell.add(chatWidget, 'left', { rank: 2000 });
        if (restorer) {
            restorer.add(chatWidget, 'jupyter-ai-chat');
        }
        // Define jupyter-ai commands
        app.commands.addCommand(CommandIDs.focusChatInput, {
            execute: () => {
                app.shell.activateById(chatWidget.id);
                focusInputSignal.emit();
            },
            label: 'Focus the jupyter-ai chat'
        });
        return {
            activeCellManager,
            chatHandler,
            chatWidget,
            selectionWatcher,
            notebookWatcher,
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([plugin, _status__WEBPACK_IMPORTED_MODULE_12__.statusItemPlugin, _completions__WEBPACK_IMPORTED_MODULE_13__.completionPlugin, _plugins_menu_plugin__WEBPACK_IMPORTED_MODULE_14__.menuPlugin]);




/***/ }),

/***/ "./lib/notebook-watcher.js":
/*!*********************************!*\
  !*** ./lib/notebook-watcher.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotebookWatcher: () => (/* binding */ NotebookWatcher),
/* harmony export */   getNotebookSelections: () => (/* binding */ getNotebookSelections)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_2__);



function getNotebook(widget) {
    if (!(widget instanceof _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_2__.DocumentWidget)) {
        return null;
    }
    const { content } = widget;
    if (!(content instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.Notebook)) {
        return null;
    }
    return content;
}
/**
 * Funkcja, która pobiera wszystkie komórki z notatnika i zwraca listę Selection.
 * @param notebook Notebook - instancja notatnika JupyterLab.
 * @returns NotebookSelections - lista obiektów Selection, gdzie każdy odpowiada jednej komórce.
 */
function getNotebookSelections(notebook) {
    var _a;
    const selections = [];
    const cellModels = (_a = notebook.model) === null || _a === void 0 ? void 0 : _a.cells;
    if (cellModels) {
        for (let i = 0; i < cellModels.length; i++) {
            const cell = cellModels.get(i);
            const cellSource = cell === null || cell === void 0 ? void 0 : cell.sharedModel.getSource();
            const cellId = cell === null || cell === void 0 ? void 0 : cell.id;
            if (cellSource && cellId) {
                const numLines = cellSource.split('\n').length;
                const selection = {
                    start: { line: 0, column: 0 },
                    end: { line: numLines - 1, column: cellSource.length },
                    text: cellSource,
                    numLines,
                    widgetId: notebook.id,
                    cellId
                };
                selections.push(selection);
            }
        }
    }
    return selections;
}
class NotebookWatcher {
    constructor(shell) {
        var _a;
        this._mainAreaWidget = null;
        this._selections = [];
        this._selectionChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__.Signal(this);
        this._shell = shell;
        (_a = this._shell.currentChanged) === null || _a === void 0 ? void 0 : _a.connect((sender, args) => {
            this._mainAreaWidget = args.newValue;
        });
        setInterval(this._poll.bind(this), 200);
    }
    get selection() {
        return this._selections;
    }
    get selectionChanged() {
        return this._selectionChanged;
    }
    _poll() {
        const notebook = getNotebook(this._mainAreaWidget);
        const currSelections = notebook ? getNotebookSelections(notebook) : [];
        if (JSON.stringify(this._selections) === JSON.stringify(currSelections)) {
            return;
        }
        this._selections = currSelections;
        this._selectionChanged.emit(currSelections);
    }
}


/***/ }),

/***/ "./lib/plugins/menu-plugin.js":
/*!************************************!*\
  !*** ./lib/plugins/menu-plugin.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CommandIDs: () => (/* binding */ CommandIDs),
/* harmony export */   menuPlugin: () => (/* binding */ menuPlugin)
/* harmony export */ });
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../tokens */ "./lib/tokens.js");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_commands__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/commands */ "webpack/sharing/consume/default/@lumino/commands");
/* harmony import */ var _lumino_commands__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_commands__WEBPACK_IMPORTED_MODULE_1__);



var CommandIDs;
(function (CommandIDs) {
    CommandIDs.explain = 'jupyter-ai:explain';
    CommandIDs.fix = 'jupyter-ai:fix';
    CommandIDs.optimize = 'jupyter-ai:optimize';
    CommandIDs.refactor = 'jupyter-ai:refactor';
})(CommandIDs || (CommandIDs = {}));
/**
 * Optional plugin that adds a "Generative AI" submenu to the context menu.
 * These implement UI shortcuts that explain, fix, refactor, or optimize code in
 * a notebook or file.
 *
 * **This plugin is experimental and may be removed in a future release.**
 */
const menuPlugin = {
    id: '@jupyter-ai/core:menu-plugin',
    autoStart: true,
    requires: [_tokens__WEBPACK_IMPORTED_MODULE_2__.IJaiCore],
    activate: (app, jaiCore) => {
        const { activeCellManager, chatHandler, chatWidget, selectionWatcher } = jaiCore;
        function activateChatSidebar() {
            app.shell.activateById(chatWidget.id);
        }
        function getSelection() {
            const textSelection = selectionWatcher.selection;
            const activeCell = activeCellManager.getContent(false);
            const selection = textSelection
                ? { type: 'text', source: textSelection.text }
                : activeCell
                    ? { type: 'cell', source: activeCell.source }
                    : null;
            return selection;
        }
        function buildLabelFactory(baseLabel) {
            return () => {
                const textSelection = selectionWatcher.selection;
                const activeCell = activeCellManager.getContent(false);
                return textSelection
                    ? `${baseLabel} (${textSelection.numLines} lines selected)`
                    : activeCell
                        ? `${baseLabel} (1 active cell)`
                        : baseLabel;
            };
        }
        // register commands
        const menuCommands = new _lumino_commands__WEBPACK_IMPORTED_MODULE_1__.CommandRegistry();
        menuCommands.addCommand(CommandIDs.explain, {
            execute: () => {
                const selection = getSelection();
                if (!selection) {
                    return;
                }
                activateChatSidebar();
                chatHandler.sendMessage({
                    prompt: 'Explain the code below.',
                    selection
                });
            },
            label: buildLabelFactory('Explain code'),
            isEnabled: () => !!getSelection()
        });
        menuCommands.addCommand(CommandIDs.fix, {
            execute: () => {
                const activeCellWithError = activeCellManager.getContent(true);
                if (!activeCellWithError) {
                    return;
                }
                chatHandler.sendMessage({
                    prompt: '/fix',
                    selection: {
                        type: 'cell-with-error',
                        error: activeCellWithError.error,
                        source: activeCellWithError.source
                    }
                });
            },
            label: () => {
                const activeCellWithError = activeCellManager.getContent(true);
                return activeCellWithError
                    ? 'Fix code cell (1 error cell)'
                    : 'Fix code cell (no error cell)';
            },
            isEnabled: () => {
                const activeCellWithError = activeCellManager.getContent(true);
                return !!activeCellWithError;
            }
        });
        menuCommands.addCommand(CommandIDs.optimize, {
            execute: () => {
                const selection = getSelection();
                if (!selection) {
                    return;
                }
                activateChatSidebar();
                chatHandler.sendMessage({
                    prompt: 'Optimize the code below.',
                    selection
                });
            },
            label: buildLabelFactory('Optimize code'),
            isEnabled: () => !!getSelection()
        });
        menuCommands.addCommand(CommandIDs.refactor, {
            execute: () => {
                const selection = getSelection();
                if (!selection) {
                    return;
                }
                activateChatSidebar();
                chatHandler.sendMessage({
                    prompt: 'Refactor the code below.',
                    selection
                });
            },
            label: buildLabelFactory('Refactor code'),
            isEnabled: () => !!getSelection()
        });
        // add commands as a context menu item containing a "Generative AI" submenu
        const submenu = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Menu({
            commands: menuCommands
        });
        submenu.id = 'jupyter-ai:submenu';
        submenu.title.label = 'Generative AI';
        submenu.addItem({ command: CommandIDs.explain });
        submenu.addItem({ command: CommandIDs.fix });
        submenu.addItem({ command: CommandIDs.optimize });
        submenu.addItem({ command: CommandIDs.refactor });
        app.contextMenu.addItem({
            type: 'submenu',
            selector: '.jp-Editor',
            rank: 1,
            submenu
        });
    }
};


/***/ }),

/***/ "./lib/selection-watcher.js":
/*!**********************************!*\
  !*** ./lib/selection-watcher.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectionWatcher: () => (/* binding */ SelectionWatcher),
/* harmony export */   getEditor: () => (/* binding */ getEditor)
/* harmony export */ });
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils */ "./lib/utils.js");







/**
 * Gets the editor instance used by a document widget. Returns `null` if unable.
 */
function getEditor(widget) {
    var _a;
    if (!(widget instanceof _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__.DocumentWidget)) {
        return null;
    }
    let editor;
    const { content } = widget;
    if (content instanceof _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_2__.FileEditor) {
        editor = content.editor;
    }
    else if (content instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_3__.Notebook) {
        editor = (_a = content.activeCell) === null || _a === void 0 ? void 0 : _a.editor;
    }
    if (!(editor instanceof _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_1__.CodeMirrorEditor)) {
        return undefined;
    }
    return editor;
}
/**
 * Gets a Selection object from a document widget. Returns `null` if unable.
 */
function getTextSelection(widget) {
    var _a;
    const editor = getEditor(widget);
    // widget type check is redundant but hints the type to TypeScript
    if (!editor || !(widget instanceof _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__.DocumentWidget)) {
        return null;
    }
    let cellId = undefined;
    if (widget.content instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_3__.Notebook) {
        cellId = (_a = widget.content.activeCell) === null || _a === void 0 ? void 0 : _a.model.id;
    }
    const selectionObj = editor.getSelection();
    let { start, end } = selectionObj;
    const startOffset = editor.getOffsetAt(start);
    const endOffset = editor.getOffsetAt(end);
    const text = editor.model.sharedModel
        .getSource()
        .substring(startOffset, endOffset);
    // Do not return a Selection object if no text is selected
    if (!text) {
        return null;
    }
    // ensure start <= end
    // required for editor.model.sharedModel.updateSource()
    if (startOffset > endOffset) {
        [start, end] = [end, start];
    }
    return {
        ...selectionObj,
        start,
        end,
        text,
        numLines: text.split('\n').length,
        widgetId: widget.id,
        ...(cellId && {
            cellId
        })
    };
}
class SelectionWatcher {
    constructor(shell) {
        var _a;
        this._mainAreaWidget = null;
        this._selection = null;
        this._selectionChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_5__.Signal(this);
        this._shell = shell;
        (_a = this._shell.currentChanged) === null || _a === void 0 ? void 0 : _a.connect((sender, args) => {
            this._mainAreaWidget = args.newValue;
        });
        setInterval(this._poll.bind(this), 200);
    }
    get selection() {
        return this._selection;
    }
    get selectionChanged() {
        return this._selectionChanged;
    }
    replaceSelection(selection) {
        // unfortunately shell.currentWidget doesn't update synchronously after
        // shell.activateById(), which is why we have to get a reference to the
        // widget manually.
        const widget = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_4__.find)(this._shell.widgets(), widget => widget.id === selection.widgetId);
        if (!(widget instanceof _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__.DocumentWidget)) {
            return;
        }
        // activate the widget if not already active
        this._shell.activateById(selection.widgetId);
        // activate notebook cell if specified
        if (widget.content instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_3__.Notebook && selection.cellId) {
            const cellIndex = (0,_utils__WEBPACK_IMPORTED_MODULE_6__.getCellIndex)(widget.content, selection.cellId);
            if (cellIndex !== -1) {
                widget.content.activeCellIndex = cellIndex;
            }
        }
        // get editor instance
        const editor = getEditor(widget);
        if (!editor) {
            return;
        }
        editor.model.sharedModel.updateSource(editor.getOffsetAt(selection.start), editor.getOffsetAt(selection.end), selection.text);
        const newPosition = editor.getPositionAt(editor.getOffsetAt(selection.start) + selection.text.length);
        editor.setSelection({ start: newPosition, end: newPosition });
    }
    _poll() {
        const prevSelection = this._selection;
        const currSelection = getTextSelection(this._mainAreaWidget);
        if ((prevSelection === null || prevSelection === void 0 ? void 0 : prevSelection.text) === (currSelection === null || currSelection === void 0 ? void 0 : currSelection.text)) {
            return;
        }
        this._selection = currSelection;
        this._selectionChanged.emit(currSelection);
    }
}


/***/ }),

/***/ "./lib/status.js":
/*!***********************!*\
  !*** ./lib/status.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   statusItemPlugin: () => (/* binding */ statusItemPlugin)
/* harmony export */ });
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tokens */ "./lib/tokens.js");
/* harmony import */ var _jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/statusbar */ "webpack/sharing/consume/default/@jupyterlab/statusbar");
/* harmony import */ var _jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_statusbar_item__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/statusbar-item */ "./lib/components/statusbar-item.js");



const statusItemPlugin = {
    id: 'jupyter_ai:status-item',
    description: 'Provides a status item for Jupyter AI.',
    autoStart: true,
    optional: [_jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_0__.IStatusBar],
    provides: _tokens__WEBPACK_IMPORTED_MODULE_1__.IJaiStatusItem,
    activate: (app, statusBar) => {
        const statusItem = new _components_statusbar_item__WEBPACK_IMPORTED_MODULE_2__.JaiStatusItem({
            commandRegistry: app.commands
        });
        if (statusBar) {
            // Add the status item.
            statusBar.registerStatusItem('jupyter_ai:jupyternaut-status', {
                item: statusItem,
                align: 'right',
                rank: 100,
                isActive: () => {
                    return statusItem.hasItems();
                }
            });
        }
        return statusItem;
    }
};


/***/ }),

/***/ "./lib/theme-provider.js":
/*!*******************************!*\
  !*** ./lib/theme-provider.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getJupyterLabTheme: () => (/* binding */ getJupyterLabTheme),
/* harmony export */   pollUntilReady: () => (/* binding */ pollUntilReady)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/material/styles */ "../../node_modules/@mui/material/styles/createTheme.js");

function getCSSVariable(name) {
    return getComputedStyle(document.body).getPropertyValue(name).trim();
}
async function pollUntilReady() {
    while (!document.body.hasAttribute('data-jp-theme-light')) {
        await new Promise(resolve => setTimeout(resolve, 100)); // Wait 100ms
    }
}
async function getJupyterLabTheme() {
    await pollUntilReady();
    const light = document.body.getAttribute('data-jp-theme-light');
    return (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__["default"])({
        spacing: 4,
        components: {
            MuiButton: {
                defaultProps: {
                    size: 'small'
                }
            },
            MuiFilledInput: {
                defaultProps: {
                    margin: 'dense'
                }
            },
            MuiFormControl: {
                defaultProps: {
                    margin: 'dense',
                    size: 'small'
                }
            },
            MuiFormHelperText: {
                defaultProps: {
                    margin: 'dense'
                }
            },
            MuiIconButton: {
                defaultProps: {
                    size: 'small'
                }
            },
            MuiInputBase: {
                defaultProps: {
                    margin: 'dense',
                    size: 'small'
                }
            },
            MuiInputLabel: {
                defaultProps: {
                    margin: 'dense'
                }
            },
            MuiListItem: {
                defaultProps: {
                    dense: true
                }
            },
            MuiOutlinedInput: {
                defaultProps: {
                    margin: 'dense'
                }
            },
            MuiFab: {
                defaultProps: {
                    size: 'small'
                }
            },
            MuiTable: {
                defaultProps: {
                    size: 'small'
                }
            },
            MuiTextField: {
                defaultProps: {
                    margin: 'dense',
                    size: 'small'
                }
            },
            MuiToolbar: {
                defaultProps: {
                    variant: 'dense'
                }
            }
        },
        palette: {
            background: {
                paper: getCSSVariable('--jp-layout-color1'),
                default: getCSSVariable('--jp-layout-color1')
            },
            mode: light === 'true' ? 'light' : 'dark',
            primary: {
                main: getCSSVariable('--jp-brand-color1'),
                light: getCSSVariable('--jp-brand-color2'),
                dark: getCSSVariable('--jp-brand-color0')
            },
            error: {
                main: getCSSVariable('--jp-error-color1'),
                light: getCSSVariable('--jp-error-color2'),
                dark: getCSSVariable('--jp-error-color0')
            },
            warning: {
                main: getCSSVariable('--jp-warn-color1'),
                light: getCSSVariable('--jp-warn-color2'),
                dark: getCSSVariable('--jp-warn-color0')
            },
            success: {
                main: getCSSVariable('--jp-success-color1'),
                light: getCSSVariable('--jp-success-color2'),
                dark: getCSSVariable('--jp-success-color0')
            },
            text: {
                primary: getCSSVariable('--jp-ui-font-color1'),
                secondary: getCSSVariable('--jp-ui-font-color2'),
                disabled: getCSSVariable('--jp-ui-font-color3')
            }
        },
        shape: {
            borderRadius: 2
        },
        typography: {
            fontFamily: getCSSVariable('--jp-ui-font-family'),
            fontSize: 12,
            htmlFontSize: 16,
            button: {
                textTransform: 'capitalize'
            }
        }
    });
}


/***/ }),

/***/ "./lib/tokens.js":
/*!***********************!*\
  !*** ./lib/tokens.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IJaiCompletionProvider: () => (/* binding */ IJaiCompletionProvider),
/* harmony export */   IJaiCore: () => (/* binding */ IJaiCore),
/* harmony export */   IJaiMessageFooter: () => (/* binding */ IJaiMessageFooter),
/* harmony export */   IJaiStatusItem: () => (/* binding */ IJaiStatusItem),
/* harmony export */   IJaiTelemetryHandler: () => (/* binding */ IJaiTelemetryHandler)
/* harmony export */ });
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__);

/**
 * The Jupyternaut status token.
 */
const IJaiStatusItem = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.Token('jupyter_ai:IJupyternautStatus', 'Status indicator displayed in the statusbar');
/**
 * The inline completion provider token.
 */
const IJaiCompletionProvider = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.Token('jupyter_ai:IJaiCompletionProvider', 'The jupyter-ai inline completion provider API');
/**
 * The message footer provider token. Another extension should provide this
 * token to add a footer to each message.
 */
const IJaiMessageFooter = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.Token('jupyter_ai:IJaiMessageFooter', 'Optional component that is used to render a footer on each Jupyter AI chat message, when provided.');
/**
 * The Jupyter AI core provider token. Frontend plugins that want to extend the
 * Jupyter AI frontend by adding features which send messages or observe the
 * current text selection & active cell should require this plugin.
 */
const IJaiCore = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.Token('jupyter_ai:core', 'The core implementation of the frontend.');
/**
 * An optional plugin that handles telemetry events emitted via user
 * interactions, when provided by a separate labextension. Not provided by
 * default.
 */
const IJaiTelemetryHandler = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.Token('jupyter_ai:telemetry', 'An optional plugin that handles telemetry events emitted via interactions on agent messages, when provided by a separate labextension. Not provided by default.');


/***/ }),

/***/ "./lib/utils.js":
/*!**********************!*\
  !*** ./lib/utils.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getCellIndex: () => (/* binding */ getCellIndex),
/* harmony export */   getEditor: () => (/* binding */ getEditor),
/* harmony export */   getModelLocalId: () => (/* binding */ getModelLocalId),
/* harmony export */   getProviderId: () => (/* binding */ getProviderId),
/* harmony export */   getTextSelection: () => (/* binding */ getTextSelection)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/fileeditor */ "webpack/sharing/consume/default/@jupyterlab/fileeditor");
/* harmony import */ var _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__);
/**
 * Contains various utility functions shared throughout the project.
 */


/**
 * Get text selection from an editor widget (DocumentWidget#content).
 */
function getTextSelection(widget) {
    const editor = getEditor(widget);
    if (!editor) {
        return '';
    }
    const selectionObj = editor.getSelection();
    const start = editor.getOffsetAt(selectionObj.start);
    const end = editor.getOffsetAt(selectionObj.end);
    const text = editor.model.sharedModel.getSource().substring(start, end);
    return text;
}
/**
 * Get editor instance from an editor widget (i.e. `DocumentWidget#content`).
 */
function getEditor(widget) {
    var _a;
    let editor;
    if (widget instanceof _jupyterlab_fileeditor__WEBPACK_IMPORTED_MODULE_1__.FileEditor) {
        editor = widget.editor;
    }
    else if (widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.Notebook) {
        editor = (_a = widget.activeCell) === null || _a === void 0 ? void 0 : _a.editor;
    }
    return editor;
}
/**
 * Gets the index of the cell associated with `cellId`.
 */
function getCellIndex(notebook, cellId) {
    var _a;
    const idx = (_a = notebook.model) === null || _a === void 0 ? void 0 : _a.sharedModel.cells.findIndex(cell => cell.getId() === cellId);
    return idx === undefined ? -1 : idx;
}
/**
 * Obtain the provider ID component from a model ID.
 */
function getProviderId(globalModelId) {
    if (!globalModelId) {
        return null;
    }
    return globalModelId.split(':')[0];
}
/**
 * Obtain the model name component from a model ID.
 */
function getModelLocalId(globalModelId) {
    if (!globalModelId) {
        return null;
    }
    const components = globalModelId.split(':').slice(1);
    return components.join(':');
}


/***/ }),

/***/ "./lib/widgets/chat-error.js":
/*!***********************************!*\
  !*** ./lib/widgets/chat-error.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildErrorWidget: () => (/* binding */ buildErrorWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icons */ "./lib/icons.js");
/* harmony import */ var _components_jl_theme_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/jl-theme-provider */ "./lib/components/jl-theme-provider.js");





function buildErrorWidget(themeManager) {
    const ErrorWidget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_jl_theme_provider__WEBPACK_IMPORTED_MODULE_3__.JlThemeProvider, { themeManager: themeManager },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, { sx: {
                width: '100%',
                height: '100%',
                boxSizing: 'border-box',
                background: 'var(--jp-layout-color0)',
                display: 'flex',
                flexDirection: 'column'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, { sx: { padding: 4 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Alert, { severity: "error" }, "There seems to be a problem with the Chat backend, please look at the JupyterLab server logs or contact your administrator to correct this problem.")))));
    ErrorWidget.id = 'jupyter-ai::chat';
    ErrorWidget.title.icon = _icons__WEBPACK_IMPORTED_MODULE_4__.chatIcon;
    ErrorWidget.title.caption = 'Jupyter AI Chat'; // TODO: i18n
    return ErrorWidget;
}


/***/ }),

/***/ "./lib/widgets/chat-sidebar.js":
/*!*************************************!*\
  !*** ./lib/widgets/chat-sidebar.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildChatSidebar: () => (/* binding */ buildChatSidebar)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_chat__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/chat */ "./lib/components/chat.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../icons */ "./lib/icons.js");




function buildChatSidebar(selectionWatcher, notebookWatcher, chatHandler, globalAwareness, themeManager, rmRegistry, completionProvider, openInlineCompleterSettings, activeCellManager, focusInputSignal, messageFooter, telemetryHandler, userManager) {
    const ChatWidget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_chat__WEBPACK_IMPORTED_MODULE_2__.Chat, { selectionWatcher: selectionWatcher, notebookWatcher: notebookWatcher, chatHandler: chatHandler, globalAwareness: globalAwareness, themeManager: themeManager, rmRegistry: rmRegistry, completionProvider: completionProvider, openInlineCompleterSettings: openInlineCompleterSettings, activeCellManager: activeCellManager, focusInputSignal: focusInputSignal, messageFooter: messageFooter, telemetryHandler: telemetryHandler, userManager: userManager }));
    ChatWidget.id = 'jupyter-ai::chat';
    ChatWidget.title.icon = _icons__WEBPACK_IMPORTED_MODULE_3__.chatIcon;
    ChatWidget.title.caption = 'Jupyter AI Chat'; // TODO: i18n
    return ChatWidget;
}


/***/ }),

/***/ "./style/icons/chat.svg":
/*!******************************!*\
  !*** ./style/icons/chat.svg ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 0 24 24\" width=\"24px\">\n  <g class=\"jp-icon3\" fill=\"#616161\">\n    <path d=\"M0 0h24v24H0V0z\" fill=\"none\"/>\n    <path d=\"M15 4v7H5.17L4 12.17V4h11m1-2H3c-.55 0-1 .45-1 1v14l4-4h10c.55 0 1-.45 1-1V3c0-.55-.45-1-1-1zm5 4h-2v9H6v2c0 .55.45 1 1 1h11l4 4V7c0-.55-.45-1-1-1z\"/>\n  </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/include-selection.svg":
/*!*******************************************!*\
  !*** ./style/icons/include-selection.svg ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = "<svg width=\"18\" height=\"9\" viewBox=\"0 0 18 9\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\"\n        d=\"M-0.0018417 1.33824L0.837379 0.499023L1.35717 1.01871C1.35741 1.01862 1.35764 1.01853 1.35787 1.01845L3.411 3.07158H3.41049L4.83909 4.49987L3.41011 5.92872H3.41075L1.35769 7.98178C1.35749 7.98171 1.35729 7.98164 1.35709 7.98156L0.837023 8.50158L-0.00219727 7.66236L3.1547 4.49987L-0.0018417 1.33824ZM2.6821 8.07158H16.143C16.932 8.07158 17.5716 7.43201 17.5716 6.64301V2.35729C17.5716 1.56832 16.932 0.928721 16.143 0.928721H2.68236L4.82522 3.07158H15.4287V5.92872H4.82496L2.6821 8.07158ZM1.74238 4.50002L0.428719 5.81655V3.18349L1.74238 4.50002Z\"\n        fill=\"#757575\" />\n</svg>\n";

/***/ }),

/***/ "./style/icons/jupyternaut.svg":
/*!*************************************!*\
  !*** ./style/icons/jupyternaut.svg ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = "<svg viewBox=\"0 0 38 38\" fill=\"none\"\n    xmlns=\"http://www.w3.org/2000/svg\">\n    <g>\n        <circle cx=\"19\" cy=\"19\" r=\"19\" fill=\"#F37726\" />\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\"\n            d=\"M19.9483 6.83653C20.5827 6.6205 21.0391 6.0196 21.0391 5.31212C21.0391 4.42296 20.3183 3.70215 19.4291 3.70215C18.5399 3.70215 17.8191 4.42296 17.8191 5.31212C17.8191 6.01951 18.2753 6.62033 18.9096 6.83644V8.00387H18.3702C12.0844 8.00387 6.97151 13.1171 6.97151 19.4026C6.97151 25.6885 12.0848 30.8013 18.3702 30.8013H19.7682C26.0541 30.8013 31.167 25.6881 31.167 19.4026C31.167 13.1773 26.1511 8.10183 19.9483 8.00527V6.83653ZM18.3702 29H19.7682C25.1351 29 29.4985 24.0213 29.4985 20.6545C29.4985 15.2876 25.1351 10.9242 19.7682 10.9242H18.3702C13.0034 10.9242 8.64 15.2876 8.64 20.6545C8.64 24.0213 13.0034 29 18.3702 29ZM32.8926 23.997C33.6267 23.997 33.6301 23.4847 33.6348 22.7562V22.7562V22.7562V22.7561C33.636 22.5714 33.6373 22.3728 33.6506 22.1651C33.7079 21.3027 33.7245 20.4643 33.7079 19.6759L33.7046 19.5569C33.6673 18.2251 33.661 17.999 32.3999 17.7511L32.252 17.7265L32.2535 17.776C32.2611 18.0225 32.2686 18.269 32.2686 18.515C32.2686 20.3168 31.9974 22.0628 31.4956 23.704C31.3593 24.1499 31.8389 24.5669 32.249 24.3451L32.8926 23.997ZM5.28037 23.997C4.54628 23.997 4.54296 23.4847 4.53822 22.7563C4.53702 22.5715 4.53573 22.3729 4.52241 22.1651C4.46511 21.3027 4.44849 20.4644 4.4651 19.6759L4.46846 19.557C4.50567 18.2251 4.51198 17.9991 5.77316 17.7512L5.921 17.7265L5.91949 17.776L5.91949 17.776C5.91193 18.0225 5.90438 18.269 5.90438 18.515C5.90438 20.3169 6.17557 22.0628 6.67738 23.704C6.81372 24.1499 6.33412 24.5669 5.92398 24.3451L5.28037 23.997ZM19.5225 11.9922C14.8928 11.9922 11.0449 14.9283 10.0641 18.7499C9.93031 19.2711 10.6154 19.4434 10.9411 19.0152C12.324 17.1972 14.0829 16.8622 15.6479 16.5641C17.7622 16.1614 19.5225 15.8262 19.5225 11.9922Z\"\n            fill=\"white\" />\n    </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/replace-cell.svg":
/*!**************************************!*\
  !*** ./style/icons/replace-cell.svg ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = "<svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\"\n        d=\"M12 4.71429V7H1.71429V4.71429H12ZM12.5714 3C13.2026 3 13.7143 3.51168 13.7143 4.14286V7.57143C13.7143 8.20263 13.2026 8.71429 12.5714 8.71429H1.14286C0.51168 8.71429 0 8.20263 0 7.57143V4.14286C0 3.51168 0.511669 3 1.14286 3H12.5714Z\"\n        fill=\"#565656\" />\n    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\"\n        d=\"M14 8.71429V11H3.71429V8.71429H14ZM14.5714 7C15.2026 7 15.7143 7.51168 15.7143 8.14286V11.5714C15.7143 12.2026 15.2026 12.7143 14.5714 12.7143H3.14286C2.51168 12.7143 2 12.2026 2 11.5714V8.14286C2 7.51168 2.51167 7 3.14286 7H14.5714Z\"\n        fill=\"#565656\" />\n</svg>\n";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.ff3ac0d321a087712815.js.map