# expose ai_data_scientist_magics ipython extension
# DO NOT REMOVE.
from ai_data_scientist_magics import load_ipython_extension, unload_ipython_extension

# expose ai_data_scientist_magics providers
# DO NOT REMOVE.
from ai_data_scientist_magics.providers import *

from ._version import __version__
from .extension import AiExtension


def _jupyter_labextension_paths():
    return [{"src": "labextension", "dest": "@ai-data-scientist/core"}]


def _jupyter_server_extension_points():
    return [{"module": "ai_data_scientist", "app": AiExtension}]
