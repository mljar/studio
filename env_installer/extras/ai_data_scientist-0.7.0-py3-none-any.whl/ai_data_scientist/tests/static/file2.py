import os

print("Hello World")
