import os
import time
import httpx
from typing import Any, Iterator, List, Optional, AsyncIterator

from langchain_core.callbacks.manager import CallbackManagerForLLMRun, AsyncCallbackManagerForLLMRun
from langchain_core.language_models.llms import LLM
from langchain_core.outputs.generation import GenerationChunk


from .utils import MLJAR_COMPLETION_API, MLJAR_AUTH_KEY


class MLJARStreaming(LLM):
    model_id: str = "test"

    @property
    def _llm_type(self) -> str:
        return "custom"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        time.sleep(3)
        return f"Hello! This is a dummy response from a test LLM."


    async def _astream(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> AsyncIterator[GenerationChunk]:
        
        #yield GenerationChunk(text=prompt)

        if os.getenv(MLJAR_AUTH_KEY) is None:
            yield GenerationChunk(text=f"Sorry, authentication problem")
        else:
            payload = {
                "prompt": prompt,
                #"dry_run": "true"
            }
            headers = {"AUTHORIZATION": "Token " + os.getenv(MLJAR_AUTH_KEY)}
            async with httpx.AsyncClient() as client:
                async with client.stream('POST', MLJAR_COMPLETION_API, data=payload, headers=headers) as response:
                    if response.status_code == 200:
                        async for chunk in response.aiter_text():
                            print(chunk, end="")
                            yield GenerationChunk(text=chunk)
                    elif response.status_code == 401:
                        yield GenerationChunk(text="Problem with AI Assistant authentication, please check your credentials.")
                    elif response.status_code == 429:
                        yield GenerationChunk(text="You reached prompts limit, please contact us for more.")
                    else:
                        yield GenerationChunk(text=f"Problem with AI Assistant response, error {response.status_code}.")
                