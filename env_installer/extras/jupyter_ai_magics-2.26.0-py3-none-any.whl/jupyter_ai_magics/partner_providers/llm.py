import os
import json
import time
import httpx
import base64
from typing import Any, Iterator, List, Optional, AsyncIterator

from langchain_core.callbacks.manager import CallbackManagerForLLMRun, AsyncCallbackManagerForLLMRun
from langchain_core.language_models.llms import LLM
from langchain_core.outputs.generation import GenerationChunk


from .utils import MLJAR_COMPLETION_API, MLJAR_AUTH_KEY


class MLJARStreaming(LLM):
    model_id: str = "test"

    @property
    def _llm_type(self) -> str:
        return "custom"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        time.sleep(1)
        return f"Hello! This is a dummy response from a test LLM."


    async def _astream(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> AsyncIterator[GenerationChunk]:

        # need to parse prompt, I don't get the langchain
        def encode(s):
            return base64.b64encode(s.strip().encode("utf-8")).decode("utf-8")

        parts = prompt.split("-----")
        msgs = []
        input_prompt = ""
        history_total_length = 0
        for p in parts:
            history_total_length += len(p)
            if p.startswith("@@human@@"):
                msgs += [{"role": "user", "content": encode(p[9:])}]
            if p.startswith("@@ai@@"):
                msgs += [{"role": "assistant", "content": encode(p[6:])}]
            if p.startswith("@@input@@"):
                input_prompt = p[9:].strip()
        
        if history_total_length > 1000:
            msgs = msgs[-2:]

        if os.getenv(MLJAR_AUTH_KEY) is None:
            yield GenerationChunk(text=f"Sorry, authentication problem")
        else:
            payload = {
                "prompt": input_prompt,
                "history": json.dumps(msgs),
                #"dry_run": "true" # only need for testing 
            }
            headers = {"AUTHORIZATION": "Token " + os.getenv(MLJAR_AUTH_KEY)}
            async with httpx.AsyncClient() as client:
                async with client.stream('POST', MLJAR_COMPLETION_API, data=payload, headers=headers) as response:
                    if response.status_code == 200:
                        async for chunk in response.aiter_text():
                            yield GenerationChunk(text=chunk)
                    elif response.status_code == 401:
                        yield GenerationChunk(text="Problem with AI Assistant authentication, please check your credentials.")
                    elif response.status_code == 429:
                        yield GenerationChunk(text="You reached prompts limit, please contact us for more.")
                    else:
                        yield GenerationChunk(text=f"Problem with AI Assistant response, error {response.status_code}.")
                