import base64
import json
import os
import time
import asyncio
from typing import Any, AsyncIterator, List, Optional

import httpx
from langchain_core.callbacks.manager import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.language_models.llms import LLM
from langchain_core.outputs.generation import GenerationChunk

from .utils import MLJAR_AUTH_KEY, MLJAR_COMPLETION_API


class MLJARStreaming(LLM):
    model_id: str = "test"

    @property
    def _llm_type(self) -> str:
        return "custom"

    def encode(self, s: str) -> str:
        """Encodes a string using Base64 encoding."""
        return base64.b64encode(s.strip().encode("utf-8")).decode("utf-8")

    def get_auth_headers(self) -> Optional[dict]:
        """
        Retrieves the authorization headers required for API requests.
        Returns None if the authentication key is not set.
        """
        auth_key = os.getenv(MLJAR_AUTH_KEY)
        if not auth_key:
            return None
        return {"AUTHORIZATION": f"Token {auth_key}"}

    def prepare_payload(self, prompt: str, history: List[dict]) -> dict:
        """
        Prepares the payload for the API request.
        """
        return {
            "prompt": prompt,
            "history": json.dumps(history),
        }

    def handle_response(self, response: httpx.Response) -> str:
        """
        Processes the API response and returns the appropriate message.
        """
        if response.status_code == 200:
            return response.text
        elif response.status_code == 401:
            return "Problem with AI Assistant authentication, please check your credentials."
        elif response.status_code == 429:
            return "You reached prompts limit, please contact us for more."
        else:
            return f"Problem with AI Assistant response, error {response.status_code}."

    async def handle_async_response(self, response: httpx.Response) -> AsyncIterator[GenerationChunk]:
        """
        Processes the asynchronous API response and yields GenerationChunks.
        """
        if response.status_code == 200:
            async for chunk in response.aiter_text():
                yield GenerationChunk(text=chunk)
        elif response.status_code == 401:
            yield GenerationChunk(
                text="Problem with AI Assistant authentication, please check your credentials."
            )
        elif response.status_code == 429:
            yield GenerationChunk(
                text="You reached prompts limit, please contact us for more."
            )
        else:
            yield GenerationChunk(
                text=f"Problem with AI Assistant response, error {response.status_code}."
            )

    def split_msgs(self, prompt: str) -> (List[dict], int, str):
        """
        Splits the prompt into messages and input prompt.
        Returns a tuple of (messages, total history length, input prompt).
        """
        parts = prompt.split("-----")
        msgs = []
        input_prompt = ""
        history_total_length = 0

        for p in parts:
            history_total_length += len(p)
            if p.startswith("@@human@@"):
                m = p[10:]
                cut_on = "Use below context in response ONLY if needed"
                cut_index = m.find(cut_on)
                if cut_index != -1:
                    m = m[:cut_index]
                msgs.append({"role": "user", "content": m.strip()})
            elif p.startswith("@@ai@@"):
                msgs.append({"role": "assistant", "content": p[7:].strip()})
            elif p.startswith("@@input@@"):
                input_prompt = p[10:].strip()

        # Encode messages
        encoded_msgs = [
            {"role": msg["role"], "content": self.encode(msg["content"])}
            for msg in msgs
        ]

        return encoded_msgs, history_total_length, input_prompt

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """Synchronous call to the MLJAR API."""
        headers = self.get_auth_headers()
        if headers is None:
            return "Sorry, authentication problem"
    
    
        payload = self.prepare_payload(prompt, [])
    
        try:
            with httpx.Client() as client:
                response = client.post(
                    MLJAR_COMPLETION_API, data=payload, headers=headers
                )
            return self.handle_response(response)
        except httpx.RequestError as e:
            return f"An error occurred while requesting the AI Assistant: {str(e)}"


    async def _astream(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> AsyncIterator[GenerationChunk]:
        print('-----------START')
        print(prompt)
        print('-------------END')
        """Asynchronous streaming call to the MLJAR API."""
        headers = self.get_auth_headers()
        if headers is None:
            yield GenerationChunk(text="Sorry, authentication problem")
            return
    
        msgs, history_total_length, input_prompt = self.split_msgs(prompt)
    
        if history_total_length > 10000:
            msgs = msgs[-4:]
    
        payload = self.prepare_payload(input_prompt, msgs)
    
        try:
            async with httpx.AsyncClient() as client:
                async with client.stream(
                    "POST", MLJAR_COMPLETION_API, data=payload, headers=headers
                ) as response:
                    async for chunk in self.handle_async_response(response):
                        yield chunk
        except httpx.RequestError as e:
            yield GenerationChunk(text=f"An error occurred while requesting the AI Assistant: {str(e)}")


#     async def _astream(
#     self,
#     prompt: str,
#     stop: Optional[List[str]] = None,
#     run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
#     **kwargs: Any,
# ) -> AsyncIterator[GenerationChunk]:
#         """Test method"""
#         await asyncio.sleep(4)
#         for i in range(1, 11):
#             if i % 7 == 0:
#                 raise ValueError("lolxd")
#             await asyncio.sleep(0.5)
#             yield GenerationChunk(text=str(i))
#
#     def _call(
#         self,
#         prompt: str,
#         stop: Optional[List[str]] = None,
#         run_manager: Optional[CallbackManagerForLLMRun] = None,
#         **kwargs: Any,
#     ) -> str:
#         """Test method"""
#         time.sleep(10)
#         return "testing fix Call method"
