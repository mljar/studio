"use strict";
(self["webpackChunk_jlab_enhanced_launcher"] = self["webpackChunk_jlab_enhanced_launcher"] || []).push([["lib_index_js"],{

/***/ "./lib/ChatButton.js":
/*!***************************!*\
  !*** ./lib/ChatButton.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatButtonWidget: () => (/* binding */ ChatButtonWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


class ChatButtonWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(props) {
        super();
        this.props = props;
        this.update();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: { paddingTop: '10px', paddingBottom: '10px' } },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { className: "mljarAskAIButton", onClick: () => {
                    this.props.stateDB.save('promptToAI', this.props.prompt);
                    this.props.commands.execute('ai-data-scientist:focus-chat-input');
                } },
                "Ask AI: ",
                this.props.prompt)));
    }
}


/***/ }),

/***/ "./lib/ChatButtonReadFile.js":
/*!***********************************!*\
  !*** ./lib/ChatButtonReadFile.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatButtonReadFileWidget: () => (/* binding */ ChatButtonReadFileWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


class ChatButtonReadFileWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(props) {
        super();
        this.props = props;
        this.update();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: { paddingTop: '10px', paddingBottom: '10px' } },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { className: "mljarAskAIButton", onClick: async () => {
                    let isElectron = false;
                    if (typeof window !== 'undefined') {
                        if (window.electronAPI !== undefined &&
                            window.electronAPI !== null) {
                            isElectron = true;
                        }
                    }
                    if (isElectron) {
                        const filePath = await window.electronAPI.recipeOpenFile();
                        this.props.stateDB.save('promptToAI', `Read file ${filePath}`);
                        this.props.commands.execute('ai-data-scientist:focus-chat-input');
                    }
                    else {
                        console.log('Cant read data file path, not in electron!');
                    }
                } }, "AI Read File")));
    }
}


/***/ }),

/***/ "./lib/PoCButton.js":
/*!**************************!*\
  !*** ./lib/PoCButton.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PoCButtonWidget: () => (/* binding */ PoCButtonWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


class PoCButtonWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(props) {
        super();
        this.props = props;
        this.update();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: { paddingTop: '10px', paddingBottom: '10px' } },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { className: "mljarPoCButton", onClick: () => {
                    this.props.commands.execute('mljar-piece-of-code:focus', {
                        recipeSet: this.props.recipeSet,
                        recipe: this.props.recipe
                    });
                } },
                "Recipe: ",
                this.props.buttonLabel)));
    }
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/statedb */ "webpack/sharing/consume/default/@jupyterlab/statedb");
/* harmony import */ var _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @jupyterlab/rendermime */ "webpack/sharing/consume/default/@jupyterlab/rendermime");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _launcher__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./launcher */ "./lib/launcher.js");
/* harmony import */ var _ChatButton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ChatButton */ "./lib/ChatButton.js");
/* harmony import */ var _starters_sampleData__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./starters/sampleData */ "./lib/starters/sampleData.js");
/* harmony import */ var _starters_readData__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./starters/readData */ "./lib/starters/readData.js");
/* harmony import */ var _PoCButton__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./PoCButton */ "./lib/PoCButton.js");
/* harmony import */ var _ChatButtonReadFile__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ChatButtonReadFile */ "./lib/ChatButtonReadFile.js");
/* harmony import */ var _starters_trainAutoml__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./starters/trainAutoml */ "./lib/starters/trainAutoml.js");
/* harmony import */ var _starters_exploreData__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./starters/exploreData */ "./lib/starters/exploreData.js");
/* harmony import */ var _starters_dataVisualization__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./starters/dataVisualization */ "./lib/starters/dataVisualization.js");
/* harmony import */ var _starters_chatWitData__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./starters/chatWitData */ "./lib/starters/chatWitData.js");
/* harmony import */ var _starters_mercuryWebApp__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./starters/mercuryWebApp */ "./lib/starters/mercuryWebApp.js");
/* harmony import */ var _starters_visualizeDecisionTree__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./starters/visualizeDecisionTree */ "./lib/starters/visualizeDecisionTree.js");
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.






















class CustomTextRenderer extends _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__.RenderedText {
    constructor(options, stateDB, commands) {
        super(options);
        this._stateDB = stateDB;
        this._commands = commands;
    }
    async renderModel(model) {
        const txt = (model.data['text/plain'] ||
            model.data['application/vnd.jupyter.stdout']);
        const matchAI = txt.match(/Ask AI:\s*(.*)/);
        const matchAIReadFile = txt.match(/AI Read File\s*(.*)/);
        const matchPoC = txt.includes('🍰 Recipe:');
        if (matchAI || matchAIReadFile || matchPoC) {
            const btnContainer = document.createElement('div');
            btnContainer.style.display = 'flex';
            btnContainer.style.flexDirection = 'row';
            btnContainer.style.alignItems = 'center';
            btnContainer.style.gap = '6px'; // space between buttons
            this.node.appendChild(btnContainer);
            this.node.style.paddingLeft = '0px';
            /* add Piece of Code button */
            if (matchPoC) {
                const matchPoC = txt.match(/Recipe:\s*(.*)/);
                const valueAfter = matchPoC[1];
                let recipeSet = '';
                let recipe = '';
                let buttonLabel = '';
                if (valueAfter.includes('::')) {
                    const parts = valueAfter.split('::');
                    recipeSet = parts[0];
                    recipe = parts[1];
                    buttonLabel = parts[1];
                }
                else if (valueAfter.includes('Load sample dataset')) {
                    recipeSet = 'Read data';
                    recipe = 'Sample datasets';
                    buttonLabel = 'Load sample dataset';
                }
                else if (valueAfter.includes('Exploratory data')) {
                    recipeSet = 'Explore data';
                    recipe = 'Skrub';
                    buttonLabel = 'Exploratory analysis';
                }
                else if (valueAfter.includes('Read CSV')) {
                    recipeSet = 'Read data';
                    recipe = 'Read CSV';
                    buttonLabel = 'Read CSV';
                }
                else if (valueAfter.includes('Read Excel')) {
                    recipeSet = 'Read data';
                    recipe = 'Read Excel';
                    buttonLabel = 'Read Excel';
                }
                else if (valueAfter.includes('Select X, y')) {
                    recipeSet = 'Data wrangling';
                    recipe = 'Select X,y';
                    buttonLabel = 'Select X, y';
                }
                else if (valueAfter.includes('Train AutoML')) {
                    recipeSet = 'MLJAR AutoML';
                    recipe = 'Train AutoML';
                    buttonLabel = 'Train AutoML';
                }
                else if (valueAfter.includes('AutoML Report')) {
                    recipeSet = 'MLJAR AutoML';
                    recipe = 'AutoML report';
                    buttonLabel = 'Display AutoML Report';
                }
                const helperButton = new _PoCButton__WEBPACK_IMPORTED_MODULE_10__.PoCButtonWidget({
                    recipeSet,
                    recipe,
                    buttonLabel,
                    commands: this._commands
                });
                btnContainer.appendChild(helperButton.node);
            }
            /* add Ask AI button with prompt */
            if (matchAI) {
                const valueAfter = matchAI[1];
                const helperButton = new _ChatButton__WEBPACK_IMPORTED_MODULE_11__.ChatButtonWidget({
                    prompt: valueAfter,
                    stateDB: this._stateDB,
                    commands: this._commands
                });
                btnContainer.appendChild(helperButton.node);
            }
            /* add AI read file button */
            if (matchAIReadFile) {
                const readButton = new _ChatButtonReadFile__WEBPACK_IMPORTED_MODULE_12__.ChatButtonReadFileWidget({
                    stateDB: this._stateDB,
                    commands: this._commands
                });
                btnContainer.appendChild(readButton.node);
            }
        }
        else {
            await super.renderModel(model);
        }
    }
}
/**
 * The command IDs used by the launcher plugin.
 */
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.create = 'launcher:create';
})(CommandIDs || (CommandIDs = {}));
/**
 * A service providing an interface to the the launcher.
 */
const plugin = {
    activate,
    id: _launcher__WEBPACK_IMPORTED_MODULE_13__.EXTENSION_ID,
    requires: [_jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5__.IStateDB, _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__.IRenderMimeRegistry],
    optional: [
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILabShell,
        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette,
        _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__.IDefaultFileBrowser,
        _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_4__.ISettingRegistry,
        _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_5__.IStateDB
    ],
    provides: _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_3__.ILauncher,
    autoStart: true
};
/**
 * Export the plugin as default.
 */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);
/**
 * Activate the launcher.
 */
async function activate(app, stateDB, rmRegistry, labShell, palette, defaultBrowser, settingRegistry, state) {
    const { commands, shell, serviceManager } = app;
    let settings = null;
    if (settingRegistry) {
        try {
            settings = await settingRegistry.load(_launcher__WEBPACK_IMPORTED_MODULE_13__.EXTENSION_ID);
        }
        catch (reason) {
            console.log(`Failed to load settings for ${_launcher__WEBPACK_IMPORTED_MODULE_13__.EXTENSION_ID}.`, reason);
        }
    }
    const templateRendererFactory = {
        safe: true,
        mimeTypes: ['text/plain', 'application/vnd.jupyter.stdout'],
        defaultRank: 1000,
        createRenderer: options => {
            return new CustomTextRenderer(options, stateDB, commands);
        }
    };
    rmRegistry.addFactory(templateRendererFactory, 1000);
    const model = new _launcher__WEBPACK_IMPORTED_MODULE_13__.LauncherModel(settings, state);
    if (state) {
        Promise.all([
            state.fetch(`${_launcher__WEBPACK_IMPORTED_MODULE_13__.EXTENSION_ID}:usageData`),
            state.fetch(`${_launcher__WEBPACK_IMPORTED_MODULE_13__.EXTENSION_ID}:viewMode`),
            app.restored
        ])
            .then(([usage, mode]) => {
            model.viewMode = mode || 'cards';
            for (const key in usage) {
                model.usage[key] = usage[key];
            }
        })
            .catch(reason => {
            console.error('Fail to restore launcher usage data', reason);
        });
    }
    const commandID = 'launcher:create-hello-notebook';
    commands.addCommand(commandID, {
        label: 'New Hello Notebook',
        caption: 'Create a notebook with a Markdown cell and a hello world code cell',
        execute: async (args) => {
            const notebook = args.notebook;
            console.log('Start notebook', notebook);
            let cells = _starters_sampleData__WEBPACK_IMPORTED_MODULE_14__.loadSampleData;
            if (notebook === 'ai-read-data') {
                cells = _starters_readData__WEBPACK_IMPORTED_MODULE_15__.aiReadDataNotebook;
            }
            else if (notebook === 'chat-with-data') {
                cells = _starters_chatWitData__WEBPACK_IMPORTED_MODULE_16__.chatWithDataNotebook;
            }
            else if (notebook === 'data-visualization') {
                cells = _starters_dataVisualization__WEBPACK_IMPORTED_MODULE_17__.dataVisualizationNotebook;
            }
            else if (notebook === 'explore-data') {
                cells = _starters_exploreData__WEBPACK_IMPORTED_MODULE_18__.exploreDataNotebook;
            }
            else if (notebook === 'train-automl') {
                cells = _starters_trainAutoml__WEBPACK_IMPORTED_MODULE_19__.mljarAutoMLNotebook;
            }
            else if (notebook === 'mercury-web-app') {
                cells = _starters_mercuryWebApp__WEBPACK_IMPORTED_MODULE_20__.mercuryWebAppNotebook;
            }
            else if (notebook === 'visualize-decision-tree') {
                cells = _starters_visualizeDecisionTree__WEBPACK_IMPORTED_MODULE_21__.visualizeDecisionTreeNotebook;
            }
            // 1. Create a blank notebook on disk
            const untitled = await serviceManager.contents.newUntitled({
                type: 'notebook'
            });
            // 2. Open it in the UI
            const panel = (await commands.execute('docmanager:open', {
                path: untitled.path,
                factory: 'Notebook',
                kernel: { name: 'python3' },
                activate: true
            }));
            await panel.context.ready;
            // 3. Grab the model (cast to the concrete class so TS knows about fromJSON/toJSON)
            const model = panel.context.model;
            const base = model.toJSON();
            // 4. Compose a new JSON payload with exactly two cells
            const newNb = {
                ...base,
                cells
            };
            // 5. Overwrite the model’s contents and save
            model.fromJSON(newNb);
            await panel.context.save();
            // await commands.execute('notebook:hide-all-cell-code');
            // 6. Show it
            app.shell.activateById(panel.id);
            await panel.sessionContext.ready;
            await _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__.NotebookActions.runAll(panel.content, panel.sessionContext);
            const firstCell = panel.content.widgets[0];
            if (firstCell) {
                // scroll to the first cell
                firstCell.node.scrollIntoView({ block: 'start', behavior: 'auto' });
                // select first cell with blue border
                panel.content.activeCellIndex = 0;
                panel.content.mode = 'command';
                panel.content.node.focus();
            }
        }
    });
    commands.addCommand(CommandIDs.create, {
        label: 'New Launcher',
        icon: args => (args.toolbar ? _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__.addIcon : undefined),
        execute: (args) => {
            var _a, _b;
            const cwd = (_b = (_a = args['cwd']) !== null && _a !== void 0 ? _a : defaultBrowser === null || defaultBrowser === void 0 ? void 0 : defaultBrowser.model.path) !== null && _b !== void 0 ? _b : '';
            const id = `launcher-${Private.id++}`;
            const callback = (item) => {
                // If widget is attached to the main area replace the launcher
                if ((0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_9__.find)(shell.widgets('main'), w => w === item)) {
                    shell.add(item, 'main', { ref: id });
                    launcher.dispose();
                }
            };
            const launcher = new _launcher__WEBPACK_IMPORTED_MODULE_13__.Launcher({
                model,
                cwd,
                callback,
                commands
            });
            launcher.model = model;
            launcher.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__.launcherIcon;
            launcher.title.label = 'Get started';
            launcher.stateDB = stateDB;
            const main = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content: launcher });
            // If there are any other widgets open, remove the launcher close icon.
            main.title.closable = !!Array.from(shell.widgets('main')).length;
            main.id = id;
            shell.add(main, 'main', {
                activate: args['activate'],
                ref: args['ref']
            });
            if (labShell) {
                labShell.layoutModified.connect(() => {
                    // If there is only a launcher open, remove the close icon.
                    main.title.closable = Array.from(labShell.widgets('main')).length > 1;
                }, main);
            }
            if (defaultBrowser) {
                const onPathChanged = (model) => {
                    launcher.cwd = model.path;
                };
                defaultBrowser.model.pathChanged.connect(onPathChanged);
                launcher.disposed.connect(() => {
                    defaultBrowser.model.pathChanged.disconnect(onPathChanged);
                });
            }
            return main;
        }
    });
    if (labShell) {
        void Promise.all([app.restored, defaultBrowser === null || defaultBrowser === void 0 ? void 0 : defaultBrowser.model.restored]).then(() => {
            function maybeCreate() {
                // Create a launcher if there are no open items.
                if (labShell.isEmpty('main')) {
                    void commands.execute(CommandIDs.create);
                }
            }
            // When layout is modified, create a launcher if there are no open items.
            labShell.layoutModified.connect(() => {
                maybeCreate();
            });
        });
    }
    if (palette) {
        palette.addItem({
            command: CommandIDs.create,
            category: 'Launcher'
        });
    }
    if (labShell) {
        labShell.addButtonEnabled = true;
        labShell.addRequested.connect((sender, arg) => {
            var _a;
            // Get the ref for the current tab of the tabbar which the add button was clicked
            const ref = ((_a = arg.currentTitle) === null || _a === void 0 ? void 0 : _a.owner.id) ||
                arg.titles[arg.titles.length - 1].owner.id;
            return commands.execute(CommandIDs.create, { ref });
        });
    }
    return model;
}
/**
 * The namespace for module private data.
 */
var Private;
(function (Private) {
    /**
     * The incrementing id used for launcher widgets.
     */
    // eslint-disable-next-line prefer-const
    Private.id = 0;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/launcher.js":
/*!*************************!*\
  !*** ./lib/launcher.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EXTENSION_ID: () => (/* binding */ EXTENSION_ID),
/* harmony export */   Launcher: () => (/* binding */ Launcher),
/* harmony export */   LauncherModel: () => (/* binding */ LauncherModel)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_properties__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/properties */ "webpack/sharing/consume/default/@lumino/properties");
/* harmony import */ var _lumino_properties__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_properties__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* eslint-disable no-inner-declarations */
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.







// import { mostUsedIcon } from './icons';
/**
 * Extension identifier
 */
const EXTENSION_ID = '@jlab-enhanced/launcher:plugin';
/**
 * The class name added to Launcher instances.
 */
const LAUNCHER_CLASS = 'jp-NewLauncher';
/**
 * LauncherModel keeps track of the path to working directory and has a list of
 * LauncherItems, which the Launcher will render.
 */
class LauncherModel extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.VDomModel {
    constructor(settings, state) {
        super();
        this._items = [];
        this._settings = null;
        this._state = null;
        this._usageData = {};
        this._viewMode = 'cards';
        this._showMore = false;
        this._prompt = '';
        this._settings = settings || null;
        this._state = state || null;
        this.dispose();
    }
    /**
     * Generate an unique identifier for a launcher item
     *
     * @param item Launcher item
     */
    static getItemUID(item) {
        return `${item.command}${JSON.stringify(item.args || {})}`;
    }
    /**
     * The known categories of launcher items and their default ordering.
     */
    get categories() {
        return ['Other', 'Kernels'];
        // if (this._settings) {
        //   return this._settings.composite['categories'] as string[];
        // } else {
        //   return ['Other', 'Kernels'];
        // }
    }
    /**
     * The maximum number of cards showed in recent section
     */
    get nRecentCards() {
        if (this._settings) {
            return this._settings.composite['nRecentCards'];
        }
        else {
            return 4;
        }
    }
    /**
     * Time (in milliseconds) after which the usage is considered to old
     */
    get maxUsageAge() {
        let age = 30;
        if (this._settings) {
            age = this._settings.composite['maxUsageAge'];
        }
        return age * 24 * 3600 * 1000;
    }
    /**
     * Card usage data
     */
    get usage() {
        return this._usageData;
    }
    /**
     * Launcher view mode
     */
    get viewMode() {
        return this._viewMode;
    }
    set viewMode(mode) {
        const hasChanged = this._viewMode !== mode;
        this._viewMode = mode;
        if (this._state && hasChanged) {
            this._state.save(`${EXTENSION_ID}:viewMode`, mode).catch(reason => {
                console.error('Fail to save view mode', reason);
            });
        }
    }
    /**
     * Launcher show more
     */
    get showMore() {
        return this._showMore;
    }
    set showMore(show) {
        this._showMore = show;
    }
    /**
     * Launcher prompt
     */
    get prompt() {
        return this._prompt;
    }
    set prompt(p) {
        this._prompt = p;
    }
    /**
     * Add a command item to the launcher, and trigger re-render event for parent
     * widget.
     *
     * @param options - The specification options for a launcher item.
     *
     * @returns A disposable that will remove the item from Launcher, and trigger
     * re-render event for parent widget.
     *
     */
    add(options) {
        // Create a copy of the options to circumvent mutations to the original.
        const item = Private.createItem(options);
        this._items.push(item);
        this.stateChanged.emit(void 0);
        return new _lumino_disposable__WEBPACK_IMPORTED_MODULE_3__.DisposableDelegate(() => {
            _lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.ArrayExt.removeFirstOf(this._items, item);
            this.stateChanged.emit(void 0);
        });
    }
    /**
     * Return an iterator of copied launcher items.
     */
    items() {
        return this._items
            .map(item => {
            const key = LauncherModel.getItemUID(item);
            const usage = this._usageData[key] || { count: 0, mostRecent: 0 };
            return { ...item, ...usage };
        })[Symbol.iterator]();
    }
    /**
     * Handle card usage data when used.
     *
     * @param item Launcher item
     */
    useCard(item) {
        const id = LauncherModel.getItemUID(item);
        const usage = this._usageData[id];
        const now = Date.now();
        let currentCount = 0;
        if (usage && now - usage.mostRecent < this.maxUsageAge) {
            currentCount = usage.count;
        }
        this._usageData[id] = {
            count: currentCount + 1,
            mostRecent: now
        };
        if (this._state) {
            this._state
                .save(`${EXTENSION_ID}:usageData`, this._usageData)
                .catch((reason) => {
                console.error(`Failed to save ${EXTENSION_ID}:usageData - ${reason.message}`, reason);
            });
        }
    }
}
/**
 * A virtual-DOM-based widget for the Launcher.
 */
class Launcher extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.VDomRenderer {
    /**
     * Construct a new launcher widget.
     */
    constructor(options) {
        super(options.model);
        this._cwd = '';
        this._pending = false;
        this._searchInput = '';
        this._cwd = options.cwd;
        this._callback = options.callback;
        this._commands = options.commands;
        this.addClass(LAUNCHER_CLASS);
    }
    set stateDB(db) {
        this._stateDB = db;
        this.update();
    }
    /**
     * The cwd of the launcher.
     */
    get cwd() {
        return this._cwd;
    }
    set cwd(value) {
        this._cwd = value;
        this.update();
    }
    /**
     * Whether there is a pending item being launched.
     */
    get pending() {
        return this._pending;
    }
    set pending(value) {
        this._pending = value;
    }
    /**
     * Render the launcher to virtual DOM nodes.
     */
    render() {
        // Bail if there is no model.
        if (!this.model) {
            return null;
        }
        const mode = this.model.viewMode === 'cards' ? '' : '-Table';
        // First group-by categories
        const categories = Object.create(null);
        const itemsArray = [...this.model.items()];
        itemsArray.forEach((item) => {
            const cat = item.category || 'Other';
            if (!(cat in categories)) {
                categories[cat] = [];
            }
            categories[cat].push([item]);
        });
        // Merge kernel items
        const notebooks = categories['Notebook'];
        if (notebooks) {
            delete categories['Notebook'];
        }
        const consoles = categories['Console'];
        if (consoles) {
            delete categories['Console'];
        }
        const kernels = notebooks;
        consoles.forEach(console_ => {
            const consoleName = (console_[0].args['kernelPreference'] &&
                console_[0].args['kernelPreference']['name']) ||
                '';
            const consoleLabel = this._commands.label(console_[0].command, console_[0].args);
            const kernel = kernels.find(kernel => {
                // kernel comes from notebook
                const kernelName = kernel[0].args['kernelName'] || '';
                const kernelLabel = this._commands.label(kernel[0].command, kernel[0].args);
                return kernelLabel === consoleLabel && kernelName === consoleName;
            });
            if (kernel) {
                kernel.push(console_[0]);
            }
            else {
                kernels.push(console_);
            }
        });
        categories['Kernels'] = kernels;
        // Within each category sort by rank
        for (const cat in categories) {
            categories[cat] = categories[cat].sort((a, b) => {
                return Private.sortCmp(a[0], b[0], this._cwd, this._commands);
            });
        }
        // Variable to help create sections
        const sections = [];
        // Assemble the final ordered list of categories, beginning with
        // model.categories.
        const orderedCategories = [];
        this.model.categories.forEach(cat => {
            if (cat in categories) {
                orderedCategories.push(cat);
            }
        });
        for (const cat in categories) {
            if (this.model.categories.indexOf(cat) === -1) {
                orderedCategories.push(cat);
            }
        }
        /*const mostUsedItems = Array.from(this.model.items()).sort(
          (a: INewLauncher.IItemOptions, b: INewLauncher.IItemOptions) => {
            return Private.sortByUsage(
              a,
              b,
              this.model.maxUsageAge,
              this._cwd,
              this._commands
            );
          }
        );*/
        // Render the most used items
        /*if (this._searchInput === '') {
          const mostUsedSection = (
            <div className="jp-NewLauncher-section" key="most-used">
              <div className="jp-NewLauncher-sectionHeader">
                <mostUsedIcon.react stylesheet="launcherSection" />
                <h2 className="jp-NewLauncher-sectionTitle">
                  {this._trans.__('Most Used')}
                </h2>
              </div>
              <div className={`jp-NewLauncher${mode}-cardContainer`}>
                {Array.from(
                  map(
                    mostUsedItems.slice(0, this.model.nRecentCards),
                    (item: INewLauncher.IItemOptions) => {
                      return Card(
                        KERNEL_CATEGORIES.indexOf(item.category || 'Other') > -1,
                        [item],
                        this,
                        this._commands,
                        this._trans,
                        this._callback
                      );
                    }
                  )
                )}
              </div>
            </div>
          );
          sections.push(mostUsedSection);
        }*/
        // Now create the sections for each category
        orderedCategories.forEach(cat => {
            if (categories[cat].length === 0) {
                return;
            }
            const item = categories[cat][0][0];
            const args = { ...item.args, cwd: this.cwd };
            const kernel = cat === 'Kernels';
            const iconClass = this._commands.iconClass(item.command, args);
            const icon = this._commands.icon(item.command, args);
            const section = (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-section", key: cat },
                react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-sectionHeader" },
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon.resolveReact, { icon: icon, iconClass: (0,_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.classes)(iconClass, 'jp-Icon-cover'), stylesheet: "launcherSection" }),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("h2", { className: "jp-NewLauncher-sectionTitle", style: { fontSize: '24px', fontWeight: 600 } },
                        cat === 'Other' && 'Start with',
                        cat === 'Kernels' && 'Open notebook with custom kernel')),
                react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: `jp-NewLauncher${mode}-cardContainer` }, Array.from((0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.map)(categories[cat], (items) => {
                    const item = items[0];
                    const command = item.command;
                    const args = { ...item.args, cwd: this.cwd };
                    const label = this._commands.label(command, args);
                    // Apply search filter
                    if (label
                        .toLocaleLowerCase()
                        .indexOf(this._searchInput.toLocaleLowerCase()) === -1) {
                        return null;
                    }
                    return Card(kernel, items, this, this._commands, this._callback);
                })))));
            sections.push(section);
        });
        //  'ai-data-scientist:focus-chat-input';
        const createNewNotebook = () => {
            if (this.pending === true) {
                return;
            }
            this.pending = true;
            this._commands
                .execute('notebook:create-new', {
                isLauncher: true,
                kernelName: 'python3',
                cwd: this.cwd
            })
                .then(value => {
                this.pending = false;
                if (value instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget) {
                    this._callback(value);
                    this.dispose();
                }
            })
                .catch(err => {
                this.pending = false;
                void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('Error', 'Launcher Error', err);
            });
        };
        // Build the onclick handler.
        const createHelloNotebook = (notebook = 'starter') => {
            if (this.pending === true) {
                return;
            }
            this.pending = true;
            this._commands
                .execute('launcher:create-hello-notebook', { notebook })
                .then(value => {
                this.pending = false;
                if (value instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget) {
                    this._callback(value);
                    this.dispose();
                }
            })
                .catch(err => {
                this.pending = false;
                void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('Error', 'Launcher Error', err);
            });
        };
        // Wrap the sections in body and content divs.
        return (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-body" },
            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-content" },
                react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "mljar-launcher-container" },
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("h1", { className: "mljar-launcher-header" }, "What do you want to analyze?"),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "mljar-launcher-input-container" },
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("input", { type: "text", className: "mljar-launcher-input-field", placeholder: "Start a conversation with AI data analyst ...", onChange: e => {
                                this.model.prompt = e.target.value;
                            }, onKeyDown: e => {
                                if (e.key === 'Enter') {
                                    if (this._stateDB) {
                                        createNewNotebook();
                                        this._stateDB.save('promptToAI', this.model.prompt);
                                        this._commands.execute('ai-data-scientist:focus-chat-input');
                                    }
                                }
                            } }),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-send-button", style: { borderRadius: '50px' }, onClick: () => {
                                if (this._stateDB) {
                                    createNewNotebook();
                                    this._stateDB.save('promptToAI', this.model.prompt);
                                    this._commands.execute('ai-data-scientist:focus-chat-input');
                                }
                            } },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M22 2L11 13", stroke: "white", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M22 2L15 22L11 13L2 9L22 2Z", stroke: "white", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" })))),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "mljar-launcher-controls" },
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-control-button", onClick: createNewNotebook },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 2v20M2 12h20", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" })),
                            "New Notebook"),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-control-button", onClick: () => createHelloNotebook('ai-read-data') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M14 2v6h6M16 13H8M16 17H8M10 9H8", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" })),
                            "AI Read Data File"),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-control-button", onClick: () => createHelloNotebook('sample-data') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M14 2v6h6", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 11v6", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }),
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M9 14l3 3 3-3", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" })),
                            "Use Sample Data"),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("button", { className: "mljar-launcher-control-button", onClick: () => {
                                this.model.showMore = !this.model.showMore;
                                this.update();
                            } },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 13a1 1 0 100-2 1 1 0 000 2zM19 13a1 1 0 100-2 1 1 0 000 2zM5 13a1 1 0 100-2 1 1 0 000 2z", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" })),
                            !this.model.showMore && 'Show more',
                            this.model.showMore && 'Hide options')),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("h2", { className: "mljar-launcher-subheader" }, "Or start from ready workflows and examples"),
                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflows" },
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('chat-with-data') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", style: { color: '#0288D1', backgroundColor: '#E1F5FE' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M4 5a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H9l-5 4V5z", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M8 9h10", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M8 13h6", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Chat with Data"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Read your data file and ask AI data analyst questions")),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('data-visualization') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", 
                                // style={{ color: '#43c61f', backgroundColor: '#eaf6e7' }}
                                style: { color: '#FFA000', backgroundColor: '#FFF8E1' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M18 20V10", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 20V4", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M6 20V14", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Data Visualization"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Quickly create visualizations for your data")),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('explore-data') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", style: { color: '#6A1B9A', backgroundColor: '#F3E5F5' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "11", cy: "11", r: "8", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M21 21l-4.35-4.35", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Data Exploration"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Create exploratory data analysis on your data file")),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('train-automl') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", style: { color: '#004666', backgroundColor: '#ccdae0' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("rect", { x: "4", y: "6", width: "16", height: "12", rx: "2", stroke: "currentColor", "stroke-width": "2", "stroke-linejoin": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "9", cy: "11", r: "1.5", fill: "currentColor" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "15", cy: "11", r: "1.5", fill: "currentColor" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M9 15c1.333 1 2.667 1 4 0", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("line", { x1: "8", y1: "6", x2: "8", y2: "4", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("line", { x1: "16", y1: "6", x2: "16", y2: "4", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "8", cy: "4", r: "1", fill: "currentColor" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("circle", { cx: "16", cy: "4", r: "1", fill: "currentColor" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Train AutoML"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Train Machine Learning model with MLJAR AutoML")),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('mercury-web-app') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", 
                                // style={{ color: '#0288D1', backgroundColor: '#E1F5FE' }}
                                style: { color: '#D32F2F', backgroundColor: '#FCE4EC' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM11.9851 4.00291C11.9933 4.00046 11.9982 4.00006 11.9996 4C12.001 4.00006 12.0067 4.00046 12.0149 4.00291C12.0256 4.00615 12.047 4.01416 12.079 4.03356C12.2092 4.11248 12.4258 4.32444 12.675 4.77696C12.9161 5.21453 13.1479 5.8046 13.3486 6.53263C13.6852 7.75315 13.9156 9.29169 13.981 11H10.019C10.0844 9.29169 10.3148 7.75315 10.6514 6.53263C10.8521 5.8046 11.0839 5.21453 11.325 4.77696C11.5742 4.32444 11.7908 4.11248 11.921 4.03356C11.953 4.01416 11.9744 4.00615 11.9851 4.00291ZM8.01766 11C8.08396 9.13314 8.33431 7.41167 8.72334 6.00094C8.87366 5.45584 9.04762 4.94639 9.24523 4.48694C6.48462 5.49946 4.43722 7.9901 4.06189 11H8.01766ZM4.06189 13H8.01766C8.09487 15.1737 8.42177 17.1555 8.93 18.6802C9.02641 18.9694 9.13134 19.2483 9.24522 19.5131C6.48461 18.5005 4.43722 16.0099 4.06189 13ZM10.019 13H13.981C13.9045 14.9972 13.6027 16.7574 13.1726 18.0477C12.9206 18.8038 12.6425 19.3436 12.3823 19.6737C12.2545 19.8359 12.1506 19.9225 12.0814 19.9649C12.0485 19.9852 12.0264 19.9935 12.0153 19.9969C12.0049 20.0001 11.9999 20 11.9999 20C11.9999 20 11.9948 20 11.9847 19.9969C11.9736 19.9935 11.9515 19.9852 11.9186 19.9649C11.8494 19.9225 11.7455 19.8359 11.6177 19.6737C11.3575 19.3436 11.0794 18.8038 10.8274 18.0477C10.3973 16.7574 10.0955 14.9972 10.019 13ZM15.9823 13C15.9051 15.1737 15.5782 17.1555 15.07 18.6802C14.9736 18.9694 14.8687 19.2483 14.7548 19.5131C17.5154 18.5005 19.5628 16.0099 19.9381 13H15.9823ZM19.9381 11C19.5628 7.99009 17.5154 5.49946 14.7548 4.48694C14.9524 4.94639 15.1263 5.45584 15.2767 6.00094C15.6657 7.41167 15.916 9.13314 15.9823 11H19.9381Z", fill: "currentColor" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Build Web App"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Create interactive web app from Python notebook")),
                        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-card", onClick: () => createHelloNotebook('visualize-decision-tree') },
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "workflow-icon", style: { color: '#43c61f', backgroundColor: '#eaf6e7' } },
                                react__WEBPACK_IMPORTED_MODULE_6__.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", "stroke-width": "2", stroke: "currentColor", fill: "none", "stroke-linecap": "round", "stroke-linejoin": "round" },
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 13l-2 -2" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 12l2 -2" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M12 21v-13" }),
                                    react__WEBPACK_IMPORTED_MODULE_6__.createElement("path", { d: "M9.824 16a3 3 0 0 1 -2.743 -3.69a3 3 0 0 1 .304 -4.833a3 3 0 0 1 4.615 -3.707a3 3 0 0 1 4.614 3.707a3 3 0 0 1 .305 4.833a3 3 0 0 1 -2.919 3.695h-4z" }))),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("h3", { className: "workflow-title" }, "Decision Tree"),
                            react__WEBPACK_IMPORTED_MODULE_6__.createElement("p", { className: "workflow-description" }, "Build and visualize decision tree classifier"))),
                    this.model.showMore && (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncher-content-main" }, sections))))));
    }
}
/**
 * A pure tsx component for a launcher card.
 *
 * @param kernel - whether the item takes uses a kernel.
 *
 * @param item - the launcher item to render.
 *
 * @param launcher - the Launcher instance to which this is added.
 *
 * @param launcherCallback - a callback to call after an item has been launched.
 *
 * @returns a vdom `VirtualElement` for the launcher card.
 */
function Card(kernel, items, launcher, commands, launcherCallback) {
    const mode = launcher.model.viewMode === 'cards' ? '' : '-Table';
    // Get some properties of the first command
    const item = items[0];
    const command = item.command;
    const args = { ...item.args, cwd: launcher.cwd };
    const caption = commands.caption(command, args);
    const label = commands.label(command, args);
    const title = kernel ? label : caption || label;
    // Build the onclick handler.
    const onClickFactory = (item) => {
        const onClick = (event) => {
            event.stopPropagation();
            // If an item has already been launched,
            // don't try to launch another.
            if (launcher.pending === true) {
                return;
            }
            launcher.pending = true;
            void commands
                .execute(item.command, {
                ...item.args,
                cwd: launcher.cwd
            })
                .then(value => {
                launcher.model.useCard(item);
                launcher.pending = false;
                if (value instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget) {
                    launcherCallback(value);
                    launcher.dispose();
                }
            })
                .catch(err => {
                launcher.pending = false;
                void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)('Error', 'Launcher Error', err);
            });
        };
        return onClick;
    };
    const mainOnClick = onClickFactory(item);
    // const getOptions = (items: INewLauncher.IItemOptions[]): JSX.Element[] => {
    //   return items.map(item => {
    //     let label = 'Open';
    //     if (
    //       item.category &&
    //       (items.length > 1 || KERNEL_CATEGORIES.indexOf(item.category) > -1)
    //     ) {
    //       label = item.category;
    //     }
    //     return (
    //       <div
    //         className="jp-NewLauncher-option-button"
    //         key={label.toLowerCase()}
    //         onClick={onClickFactory(item)}
    //       >
    //         <span className="jp-NewLauncher-option-button-text">
    //           {label.toUpperCase()}
    //         </span>
    //       </div>
    //     );
    //   });
    // };
    // With tabindex working, you can now pick a kernel by tabbing around and
    // pressing Enter.
    const onkeypress = (event) => {
        if (event.key === 'Enter') {
            mainOnClick(event);
        }
    };
    const iconClass = commands.iconClass(command, args);
    const icon = commands.icon(command, args);
    // Return the VDOM element.
    return (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: `jp-NewLauncher-item${mode}`, title: title, onClick: mainOnClick, onKeyPress: onkeypress, tabIndex: 100, "data-category": item.category || 'Other', key: Private.keyProperty.get(item) },
        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: `jp-NewLauncherCard-icon jp-NewLauncher${mode}-Cell` }, kernel ? (item.kernelIconUrl ? (react__WEBPACK_IMPORTED_MODULE_6__.createElement("img", { src: item.kernelIconUrl, className: "jp-NewLauncher-kernelIcon" })) : (react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: "jp-NewLauncherCard-noKernelIcon" }, label[0].toUpperCase()))) : (react__WEBPACK_IMPORTED_MODULE_6__.createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon.resolveReact, { icon: icon, iconClass: (0,_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.classes)(iconClass, 'jp-Icon-cover'), stylesheet: "launcherCard" }))),
        react__WEBPACK_IMPORTED_MODULE_6__.createElement("div", { className: `jp-NewLauncher-label jp-NewLauncher${mode}-Cell`, title: label }, label)));
}
/**
 * The namespace for module private data.
 */
var Private;
(function (Private) {
    /**
     * An incrementing counter for keys.
     */
    let id = 0;
    /**
     * An attached property for an item's key.
     */
    Private.keyProperty = new _lumino_properties__WEBPACK_IMPORTED_MODULE_4__.AttachedProperty({
        name: 'key',
        create: () => id++
    });
    /**
     * Create a fully specified item given item options.
     */
    function createItem(options) {
        return {
            ...options,
            category: options.category || '',
            rank: options.rank !== undefined ? options.rank : Infinity
        };
    }
    Private.createItem = createItem;
    /**
     * A sort comparison function for a launcher item.
     */
    function sortCmp(a, b, cwd, commands) {
        // First, compare by rank.
        const r1 = a.rank;
        const r2 = b.rank;
        if (r1 !== r2 && r1 !== undefined && r2 !== undefined) {
            return r1 < r2 ? -1 : 1; // Infinity safe
        }
        // Finally, compare by display name.
        const aLabel = commands.label(a.command, { ...a.args, cwd });
        const bLabel = commands.label(b.command, { ...b.args, cwd });
        return aLabel.localeCompare(bLabel);
    }
    Private.sortCmp = sortCmp;
    function sortByUsage(a, b, maxUsageAge, cwd, commands) {
        const now = Date.now();
        const aCount = now - a.mostRecent < maxUsageAge ? a.count : 0;
        const bCount = now - b.mostRecent < maxUsageAge ? b.count : 0;
        if (aCount === bCount) {
            const mostRecent = b.mostRecent - a.mostRecent;
            return mostRecent === 0 ? sortCmp(a, b, cwd, commands) : mostRecent;
        }
        return bCount - aCount;
    }
    Private.sortByUsage = sortByUsage;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/starters/chatWitData.js":
/*!*************************************!*\
  !*** ./lib/starters/chatWitData.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   chatWithDataNotebook: () => (/* binding */ chatWithDataNotebook)
/* harmony export */ });
const chatWithDataNotebook = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# Chat with Your Data Using AI

Welcome! This notebook lets you have a friendly conversation with your dataset. Simply select file in your PC, then ask questions in natural language to uncover insights and patterns.`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 1 – Load Your Data

Choose how you’d like to bring your data into the notebook:

- **Recipe: Read Excel** — Click to use Code Recipe with UI for Excel file reading.
- **AI Read File** — Let the AI automatically detect data type and load your file into a pandas DataFrame called \`df\`.

After loading, you’ll see the first few rows to make sure everything looks good.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Read Excel or 🤖 AI Read File''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 2 – Ask AI About Your Data

Now that your data is ready, talk to it! Click the button below to use a ready prompt: __Get insigts about my dataset__ or type your question in the chat on the left. The AI will provide the code and execute it to get insights.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🤖 Ask AI: Get insights about my dataset''')"
    }
];


/***/ }),

/***/ "./lib/starters/dataVisualization.js":
/*!*******************************************!*\
  !*** ./lib/starters/dataVisualization.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dataVisualizationNotebook: () => (/* binding */ dataVisualizationNotebook)
/* harmony export */ });
const dataVisualizationNotebook = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# Data Visualization with AI

In this notebook, you’ll effortlessly transform your dataset into beautiful visuals. `
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 1 – Load Your Data

Choose how you’d like to bring your data into the notebook:

- **Recipe: Read Excel** — Click to use Code Recipe with UI for Excel file reading.
- **AI Read File** — Let the AI automatically detect data type and load your file into a pandas DataFrame called \`df\`.

After loading, you’ll see the first few rows to make sure everything looks good.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Read Excel   or   🤖 AI Read File''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 3 - Interactive Visualizations with AI

Build interactive charts with Plotly. Click __Ask AI: Create interactive visualization__, it will send a ready prompt to AI, wait a few seconds, and you will get beautiful, interactive plots.

Feel free to follow up with more questions in the chat panel.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🤖 Ask AI: Create interactive visualization''')"
    }
];


/***/ }),

/***/ "./lib/starters/exploreData.js":
/*!*************************************!*\
  !*** ./lib/starters/exploreData.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   exploreDataNotebook: () => (/* binding */ exploreDataNotebook)
/* harmony export */ });
const exploreDataNotebook = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# Exploratory Data Analysis with AI 🔍📊

In this notebook, you’ll transform raw data into insights in three easy steps:

1. **Load** your dataset
2. **Analyze** with automated EDA
3. **Discover** deeper insights via AI chat
`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 1 – Load Your Dataset 📥

Choose how you’d like to bring your data into the notebook:

- **Recipe: Read Excel** — Click to use Code Recipe with UI for Excel file reading.
- **AI Read File** — Let the AI automatically detect data type and load your file into a pandas DataFrame called \`df\`.

After loading, you’ll see the first few rows to make sure everything looks good.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Read Excel   or   🤖 AI Read File''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 2 – Automated EDA ⚙️

Run a one-click EDA report to:

- View summary statistics (mean, median, quartiles)
- Visualize distributions and correlations
- Detect missing values and outliers

Just the button below, wait a second and explore the interactive report!`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Exploratory data analysis''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 3 – Ask AI About Your Data 💬

Click the button below to use a ready prompt: __What are the key insights from this dataset?__ or type your question in the chat on the left. The AI will provide the code and execute it to get insights.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🤖 Ask AI: What are the key insights from this dataset?''')"
    }
];


/***/ }),

/***/ "./lib/starters/mercuryWebApp.js":
/*!***************************************!*\
  !*** ./lib/starters/mercuryWebApp.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   mercuryWebAppNotebook: () => (/* binding */ mercuryWebAppNotebook)
/* harmony export */ });
const mercuryWebAppNotebook = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# Share Your Notebook as a Web App 🚀

Welcome to this notebook😊 In just a few simple steps, you’ll learn how to add interactive widgets and turn your notebook into a web app using the open-source **Mercury** framework.

Mercury makes it easy to serve Python notebook as a web application (with your code hidden).  

### What is in this notebook?
- Install \`mercury\` package,
- Import \`mercury\` library,
- Create \`Text\` widget, that asks for name,
- Display widget value in the \`print\` statement.

### Quick start

Run below command in your terminal to launch the app locally:  
\`\`\`bash
mercury run
\`\`\`

Upload your notebook to https://cloud.runmercury.com and get a live URL instantly! ☁️
`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: 'pip install -q mercury'
    },
    {
        cell_type: 'code',
        metadata: {},
        source: `# import mercury library
import mercury as mr`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: `# text input
name = mr.Text(label="What is your name?", value="Aleksandra")`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: 'print(f"Hello {name.value}👋")'
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Next steps
    
With Mercury, whenever someone interacts with a widget, it automatically re-runs the cells below - no extra work needed! There are many widgets to explore: \`Slider\`, \`Select\`, \`Range\`, \`NumberBox\`, \`OutputDir\` and more. 

And don’t forget—you can spice up your app with beautiful visualizations using Python libraries like \`Matplotlib\`, \`Altair\`, \`Plotly\`. Let’s make your data shine! ✨

**Mercury docs 📖**  
  - GitHub: https://github.com/mljar/mercury  
  - Docs: https://runmercury.com/docs/ 
    `
    }
];


/***/ }),

/***/ "./lib/starters/readData.js":
/*!**********************************!*\
  !*** ./lib/starters/readData.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   aiReadDataNotebook: () => (/* binding */ aiReadDataNotebook)
/* harmony export */ });
const aiReadDataNotebook = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# AI Read Data and Get Insights

Just two simple steps: **Load** your data and **Discover** insights with AI assistant.

1. AI read data file.
2. Ask AI for insights
`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 1 - Provide Your Dataset to AI

Click the button below, choose your CSV, Excel, JSON, or other file format, and watch AI loads it into a DataFrame. You'll see the first few rows to confirm everything looks right.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🤖 AI Read File''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 2 - Ask AI for Insights

Now that your data is loaded you can ask the AI anything in plain language to find patterns, connections, or oddities. Click the blue button below for a ready prompt, or just type any question about your data in the chat on the left. The AI will generate and run analysis code and then show you the results. You can keep talking with the AI to get even more insights!`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🤖 Ask AI: What are the key insights from this dataset?''')"
    }
];


/***/ }),

/***/ "./lib/starters/sampleData.js":
/*!************************************!*\
  !*** ./lib/starters/sampleData.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   loadSampleData: () => (/* binding */ loadSampleData)
/* harmony export */ });
const loadSampleData = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# Load Sample Dataset for Analysis

This notebook will help you to get familiar with basic steps for data analysis. You can use one of many sample datasets that are available in code recipes.

You'll learn how to:

1. **Load** a sample dataset.  
2. **Explore** it with an easy report.  
3. **Make** interactive charts. 

`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 1 - Load a Sample Dataset

Pick one of our ready-to-go datasets to get started. Just click yellow **Recipe** button. The **Iris dataset** is a great choice to start with:

- 150 samples of three iris species (setosa, versicolor, virginica)
- 4 features: sepal length, sepal width, petal length, petal width  

Or, simply click **Ask AI**, it will use ready prompt __Load sample dataset__ to fetch data using  \`scikit-learn\` package.
`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Load sample dataset or 🤖 Ask AI: Load sample dataset''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 2 - Automated Exploratory Data Analysis (EDA)

Run a full EDA report in one click to:

- See summary statistics (mean, median, quartiles)  
- Visualize distributions and correlations  
- Spot missing values and outliers  

You'll get an interactive report right here—just click the yellow button below and explore the tabs in the report.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Exploratory data analysis''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 3 - Interactive Visualizations with AI

Build interactive charts with Plotly. Click __Ask AI: Create interactive visualization__, it will send a ready prompt to AI, wait a few seconds, and you will get beautiful, interactive plots.

Feel free to follow up with more questions in the chat panel.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🤖 Ask AI: Create interactive visualization''')"
    }
];


/***/ }),

/***/ "./lib/starters/trainAutoml.js":
/*!*************************************!*\
  !*** ./lib/starters/trainAutoml.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   mljarAutoMLNotebook: () => (/* binding */ mljarAutoMLNotebook)
/* harmony export */ });
const mljarAutoMLNotebook = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# AutoML Model Training with MLJAR 🚀🤖

In this notebook, you’ll navigate four key steps to take your data from raw file to trained Meachine Learning models. MLJAR's AutoML engine will automatically test multiple algorithms, optimize hyperparameters, and generate interactive report for you.

**Steps in this notebook:**
1. **Load** your dataset
2. **Define** features and target
3. **Train** with MLJAR AutoML
4. **Review** the comprehensive report

Let’s get started!`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 1 – Load Your Dataset 📥

Bring your data into the notebook easily:

- 🍰 **Recipe: Read CSV** — Read a CSV file with UI Code Recipe.
- 🤖 **AI Read File** — AI auto-detects file type and loads your file into a DataFrame named \`df\`.

After loading, you’ll see the first few rows to verify everything loaded correctly.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Read CSV   or   🤖 AI Read File''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 2 – Define Features (X) & Target (y) 🎯

Prepare your modeling data:

- 🔧 **Select X, y** — Use Code Recipe UI to select X and y.
- 🤖 **Ask AI: Split into X and y** — Ask AI to choose columns for training with ready prompt, just click blue button.

Once done, you’ll have \`X\` (predictors) and \`y\` (outcome) ready for training.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Select X, y   or   🤖 Ask AI: Split df into X and y''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 3 – Train with MLJAR AutoML 🤖⚙️

Launch automated model training:

- Select **Features (X)** and **Target (y)** in the AutoML UI.
- Execute code to start MLJAR AutoML training.
- Wait a while ☕ and watch logs as multiple models are trained and validated under the hood.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Train AutoML''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 4 – Review AutoML Report 📑✨

Explore a rich, interactive report. Use the built-in report viewer. You can click on models in the leadorboard table to get details for each of them.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: View AutoML Report''')"
    }
];


/***/ }),

/***/ "./lib/starters/visualizeDecisionTree.js":
/*!***********************************************!*\
  !*** ./lib/starters/visualizeDecisionTree.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   visualizeDecisionTreeNotebook: () => (/* binding */ visualizeDecisionTreeNotebook)
/* harmony export */ });
const visualizeDecisionTreeNotebook = [
    {
        cell_type: 'markdown',
        metadata: {},
        source: `# Train & Visualize Decision  Tree 🌳

This notebook walks through loading the Iris dataset, training a decision tree classifier, and visualizing the resulting model.
`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 1 - Load Iris Dataset

We will use the classic Iris dataset, which contains measurements for three species of iris flowers.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: `
# load example Iris dataset
import pandas as pd
df = pd.read_csv("https://raw.githubusercontent.com/pplonski/datasets-for-start/master/iris/data.csv", skipinitialspace=True)
# display DataFrame shape
print(f"👍 Successfully loaded dataset to DataFrame df. It has shape {df.shape}.")
# create X and y
X = df.drop(columns=['class'])
y = df['class']
`
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 2 - Construct Decision Tree Classifier

Construct empty model of Decision Tree classifier. `
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Scikit-learn::Decision Tree''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 3 - Fit Decision Tree Classifier

We will train a Decision Tree classifier. This simple model splits the data based on feature thresholds to classify the species.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Scikit-learn::Train Model''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Step 4 - Visualize the Decision Tree

We'll visualize the trained decision tree structure to understand how the model makes decisions.`
    },
    {
        cell_type: 'code',
        metadata: {},
        source: "print('''🍰 Recipe: Scikit-learn::Visualize Decision Tree''')"
    },
    {
        cell_type: 'markdown',
        metadata: {},
        source: `## Next Steps - Apply to Your Own Dataset

Now it’s your turn! Build a similar notebook with your own data by:

1. **Loading Your Data**: Replace the Iris loading code with your dataset (e.g., local CSV, database, or API).
2. **Training the Model**: Train a Decision Tree with your data.
3. **Visualizing the Tree**: Plot the decision tree structure for interpretability.

Copy this template notebook and customize the data loading section to get started on your dataset!`
    }
];


/***/ })

}]);
//# sourceMappingURL=lib_index_js.3971cae9da9914f36890.js.map