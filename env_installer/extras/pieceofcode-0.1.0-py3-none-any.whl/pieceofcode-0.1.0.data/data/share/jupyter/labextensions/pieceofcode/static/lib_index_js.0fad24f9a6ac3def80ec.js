"use strict";
(self["webpackChunkpieceofcode"] = self["webpackChunkpieceofcode"] || []).push([["lib_index_js"],{

/***/ "./lib/commands/index.js":
/*!*******************************!*\
  !*** ./lib/commands/index.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   commandsPlugin: () => (/* binding */ commandsPlugin),
/* harmony export */   runCell: () => (/* binding */ runCell)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../icons */ "./lib/icons.js");
/* harmony import */ var _flags__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../flags */ "./lib/flags.js");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);



const CommandIds = {
    openPieceOfCode: '@mljar/pieceofcode:open',
    hidePieceOfCode: '@mljar/pieceofcode:hide',
    runFirstCell: '@mljar/pieceofcode:runfirstcell',
    runCurrentCell: '@mljar/pieceofcode:runcurrentcell',
};
const showButton = (title = 'open') => {
    const elements = document.querySelectorAll(`[data-command="@mljar/pieceofcode:${title}"]`);
    elements.forEach((e) => {
        e.classList.remove('lm-mod-hidden');
    });
};
const hideButton = (title = 'open') => {
    const elements = document.querySelectorAll(`[data-command="@mljar/pieceofcode:${title}"]`);
    elements.forEach((e) => {
        e.classList.add('lm-mod-hidden');
    });
};
const commandsPlugin = {
    id: '@mljar/pieceofcode:commands',
    description: 'Commands used in Piece of Code',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, tracker) => {
        const { commands } = app;
        commands.addCommand(CommandIds.openPieceOfCode, {
            icon: _icons__WEBPACK_IMPORTED_MODULE_1__.cakeIcon,
            caption: 'Open Piece of Code',
            execute: () => {
                (0,_flags__WEBPACK_IMPORTED_MODULE_2__.setAlwaysOpen)(true);
                showButton('hide');
                hideButton('open');
            },
            isVisible: () => !(0,_flags__WEBPACK_IMPORTED_MODULE_2__.getAlwaysOpen)()
        });
        commands.addCommand(CommandIds.hidePieceOfCode, {
            icon: _icons__WEBPACK_IMPORTED_MODULE_1__.cakeOffIcon,
            caption: 'Hide Piece of Code',
            execute: () => {
                (0,_flags__WEBPACK_IMPORTED_MODULE_2__.setAlwaysOpen)(false);
                showButton('open');
                hideButton('hide');
            },
            isVisible: () => (0,_flags__WEBPACK_IMPORTED_MODULE_2__.getAlwaysOpen)()
        });
        app.commands.addCommand(CommandIds.runFirstCell, {
            label: 'Execute first cell',
            execute: () => {
                const nb = tracker.currentWidget;
                if (nb) {
                    return runCell(nb.content, nb.context.sessionContext, 0);
                }
            }
        });
        app.commands.addCommand(CommandIds.runCurrentCell, {
            label: 'Execute current cell',
            execute: () => {
                const nb = tracker.currentWidget;
                if (nb) {
                    return runCell(nb.content, nb.context.sessionContext);
                }
            }
        });
    }
};
function runCell(notebook, sessionContext, cellIndex, sessionDialogs, translator) {
    if (!notebook.model || !notebook.activeCell) {
        return Promise.resolve(false);
    }
    if (cellIndex === undefined) {
        cellIndex = notebook.activeCellIndex;
    }
    const cells = [notebook.widgets[cellIndex]];
    const promise = _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookActions.runCells(notebook, cells, sessionContext, sessionDialogs, translator);
    return promise;
}


/***/ }),

/***/ "./lib/extendedcell/factory.js":
/*!*************************************!*\
  !*** ./lib/extendedcell/factory.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExtendedCellFactory: () => (/* binding */ ExtendedCellFactory)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header */ "./lib/extendedcell/header.js");
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./footer */ "./lib/extendedcell/footer.js");



class ExtendedCellFactory extends _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel.ContentFactory {
    constructor(options) {
        super(options);
    }
    createCellHeader() {
        return new _header__WEBPACK_IMPORTED_MODULE_1__.ExtendedCellHeader();
    }
    createCellFooter() {
        return new _footer__WEBPACK_IMPORTED_MODULE_2__.ExtendedCellFooter();
    }
}


/***/ }),

/***/ "./lib/extendedcell/footer.js":
/*!************************************!*\
  !*** ./lib/extendedcell/footer.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExtendedCellFooter: () => (/* binding */ ExtendedCellFooter)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

class ExtendedCellFooter extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    // private a: Widget | undefined;
    constructor() {
        super();
        // console.log('cell footer');
        // this.layout = new PanelLayout();
        // if (this.layout instanceof PanelLayout) {
        //   const t = document.createElement('div');
        //   t.textContent = 'Ola koduje2';
        //   this.a = new Widget({ node: t });
        //   this.layout.addWidget(this.a);
        //   this.a.hide();
        // }
    }
    onAfterAttach(msg) {
        const cell = this.parent;
        // console.log('get cell', cell);
        if (cell) {
            // console.log('try add focus');
            // cell.inputArea?.node.addEventListener('focusout', () => {
            //   console.log('focusin is here2', cell);
            //   this.a?.hide();
            // });
            // cell.inputArea?.node.addEventListener('focusin', () => {
            //   console.log('focusin is here2', cell);
            //   this.a?.show();
            // });
            //cell.displayChanged.connect(() => console.log('change'));
        }
    }
}


/***/ }),

/***/ "./lib/extendedcell/header.js":
/*!************************************!*\
  !*** ./lib/extendedcell/header.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExtendedCellHeader: () => (/* binding */ ExtendedCellHeader),
/* harmony export */   RecipeWidgetsRegistry: () => (/* binding */ RecipeWidgetsRegistry)
/* harmony export */ });
/* harmony import */ var _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/cells */ "webpack/sharing/consume/default/@jupyterlab/cells");
/* harmony import */ var _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_cells__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _recipes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./recipes */ "./lib/extendedcell/recipes.js");
/* harmony import */ var _flags__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../flags */ "./lib/flags.js");
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mljar/recipes */ "webpack/sharing/consume/default/@mljar/recipes/@mljar/recipes");
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mljar_recipes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _variableinspector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./variableinspector */ "./lib/extendedcell/variableinspector.js");







// import { NotebookActions } from '@jupyterlab/notebook';
// import { nbformat } from '@jupyterlab/coreutils';
class RecipeWidgetsRegistry {
    constructor() {
        this._widgets = {};
        this._lastSelectedCellId = '';
    }
    static getInstance() {
        if (!RecipeWidgetsRegistry._instance) {
            RecipeWidgetsRegistry._instance = new RecipeWidgetsRegistry();
        }
        return RecipeWidgetsRegistry._instance;
    }
    setCommandRegistry(commands) {
        this._commands = commands;
    }
    deleteCell() {
        if (this._commands) {
            this._commands.execute('notebook:delete-cell');
        }
    }
    addCell() {
        if (this._commands) {
            const promise = this._commands.execute('notebook:insert-cell-below');
            promise.then(() => {
                var _a;
                (_a = this._commands) === null || _a === void 0 ? void 0 : _a.execute('notebook:enter-edit-mode');
            });
        }
    }
    addCellAbove() {
        if (this._commands) {
            const promise = this._commands.execute('notebook:insert-cell-above');
            promise.then(() => {
                var _a;
                (_a = this._commands) === null || _a === void 0 ? void 0 : _a.execute('notebook:enter-edit-mode');
            });
        }
    }
    runCell(addStep, checkOutput) {
        if (this._commands) {
            addStep('Run code', _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Wait);
            const promise = this._commands.execute('@mljar/pieceofcode:runcurrentcell');
            promise.then(() => {
                checkOutput();
            });
        }
    }
    runFirstCell() {
        if (this._commands) {
            const promise = this._commands.execute('@mljar/pieceofcode:runfirstcell');
            return promise;
        }
        return undefined;
    }
    addWidget(cellId, widget) {
        this._widgets[cellId] = widget;
    }
    removeWidget(cellId) {
        delete this._widgets[cellId];
    }
    hideAll() {
        Object.values(this._widgets).forEach(w => w.hide());
    }
    setSelectedCellId(cellId) {
        this._lastSelectedCellId = cellId;
    }
    showLastSelectedCellId() {
        if (this._lastSelectedCellId in this._widgets) {
            this._widgets[this._lastSelectedCellId].show();
        }
    }
}
// export const run = 'notebook:run-cell';
// export const runAndAdvance = 'notebook:run-cell-and-select-next';
// export const runAndInsert = 'notebook:run-cell-and-insert-below';
class ExtendedCellHeader extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget {
    constructor() {
        super();
        this._packages = [];
        this._executionSteps = [];
        this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout();
        if (this.layout instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout) {
            this.removeClass('lm-Widget');
            this.removeClass('jp-Cell-header');
            this.addClass('recipe-panel-layout');
        }
    }
    dispose() {
        if (this._cellId) {
            RecipeWidgetsRegistry.getInstance().removeWidget(this._cellId);
        }
        super.dispose();
    }
    setCode(src) {
        const cell = this.parent;
        cell.model.sharedModel.setSource(src);
    }
    setPackages(packages) {
        console.log('setPackages', packages);
        this._packages = packages;
    }
    clearExecutionSteps() {
        var _a;
        this._executionSteps = [];
        (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setExecutionSteps(this._executionSteps);
    }
    addExecutionStep(label, status) {
        var _a;
        let found = false;
        this._executionSteps = this._executionSteps.map((step) => {
            if (step[0] == label) {
                found = true;
                return [step[0], status];
            }
            return [step[0], step[1]];
        });
        if (!found) {
            this._executionSteps.push([label, status]);
        }
        (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setExecutionSteps(this._executionSteps);
    }
    runCell() {
        var _a;
        (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setPreviousError('', '');
        this.clearExecutionSteps();
        this.insertCellAtTop();
        this.supplementPackages();
        if (this._packages.length) {
            console.log('runCell', this._packages);
            //
            // import packages and run code
            //
            this.addExecutionStep('Import packages', _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Wait);
            const promise = RecipeWidgetsRegistry.getInstance().runFirstCell();
            promise === null || promise === void 0 ? void 0 : promise.then(() => {
                const errorName = this.checkFirstCellOutput();
                console.log('check first cell', errorName);
                if (errorName === '') {
                    // no error with package import let's run code
                    RecipeWidgetsRegistry.getInstance().runCell(this.addExecutionStep.bind(this), this.checkOutput.bind(this));
                }
                else {
                    this.addExecutionStep('Code not executed', _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Warning);
                }
            });
            // clear packages
            this._packages = [];
        }
        else {
            //
            // just run current cell
            //
            RecipeWidgetsRegistry.getInstance().runCell(this.addExecutionStep.bind(this), this.checkOutput.bind(this));
        }
    }
    checkOutput() {
        if (this.cell) {
            return this.checkCellOutput(this.cell.model.sharedModel.toJSON(), 'Run code');
        }
        return '';
    }
    checkFirstCellOutput() {
        var _a;
        const nb = this.notebook;
        if (nb) {
            const cells = (_a = nb === null || nb === void 0 ? void 0 : nb.model) === null || _a === void 0 ? void 0 : _a.cells;
            if (cells) {
                return this.checkCellOutput(cells.get(0).sharedModel.toJSON(), 'Import packages');
            }
        }
        return '';
    }
    checkCellOutput(output, stepName) {
        var _a, _b;
        if (output) {
            const [errorName, errorValue] = this.getErrorNameAndValue(output);
            (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setPreviousError(errorName, errorValue);
            (_b = this.selectRecipe) === null || _b === void 0 ? void 0 : _b.updateWidget();
            if (errorName === '') {
                setTimeout(() => this.addExecutionStep(stepName, _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Success), 500);
            }
            else {
                setTimeout(() => this.addExecutionStep(stepName, _mljar_recipes__WEBPACK_IMPORTED_MODULE_3__.ExecutionStatus.Error), 500);
            }
            return errorName;
        }
        return '';
    }
    deleteCell() {
        RecipeWidgetsRegistry.getInstance().deleteCell();
    }
    addCell() {
        RecipeWidgetsRegistry.getInstance().addCell();
    }
    insertCellAtTop() {
        var _a, _b;
        console.log('insert cell at top', this._packages);
        // insert cell at the top of the notebook
        // if there is only one cell in the notebook
        if (!this._packages) {
            return;
        }
        const nb = this.notebook;
        if (nb) {
            const cells = (_a = nb === null || nb === void 0 ? void 0 : nb.model) === null || _a === void 0 ? void 0 : _a.cells;
            if (cells) {
                if (cells.length == 1) {
                    (_b = nb === null || nb === void 0 ? void 0 : nb.model) === null || _b === void 0 ? void 0 : _b.sharedModel.insertCell(0, { cell_type: 'code', source: '' });
                }
            }
        }
    }
    supplementPackages() {
        var _a;
        console.log('supplement packages', this._packages);
        if (!this._packages) {
            return;
        }
        const nb = this.notebook;
        if (nb) {
            const cells = (_a = nb === null || nb === void 0 ? void 0 : nb.model) === null || _a === void 0 ? void 0 : _a.cells;
            if (cells) {
                let firstCellSrc = cells.get(0).sharedModel.getSource();
                this._packages.forEach((packageImport) => {
                    const packageImported = firstCellSrc.includes(packageImport);
                    if (!packageImported) {
                        if (firstCellSrc.length > 0) {
                            firstCellSrc += '\n';
                        }
                        firstCellSrc += `${packageImport}`;
                    }
                });
                cells.get(0).sharedModel.setSource(firstCellSrc);
            }
        }
    }
    // private _onIOPub = (msg: KernelMessage.IIOPubMessage): void => {
    //   const msgType = msg.header.msg_type;
    //   // console.log(msg);
    //   switch (msgType) {
    //     case 'execute_result':
    //     case 'display_data':
    //     case 'update_display_data':
    //       // console.log(msg.content);
    //       break;
    //     default:
    //       break;
    //   }
    //   return;
    // };
    getErrorNameAndValue(output) {
        // const output: nbformat.IBaseCell = cell.model.sharedModel.toJSON();
        if (output) {
            if (output.cell_type === 'code') {
                let outputs = output.outputs;
                //console.log(outputs);
                if (outputs !== null && outputs !== undefined) {
                    //let s = outputs?.toString();
                    //console.log('string', s);
                    if (outputs.length) {
                        const { output_type, ename, evalue } = outputs[0];
                        //console.log(outputs[0], output_type, ename, evalue);
                        if (output_type === 'error') {
                            return [ename, evalue];
                        }
                    }
                }
            }
        }
        return ['', ''];
    }
    getExecutionCount(cell) {
        const output = cell.model.sharedModel.toJSON();
        if (output) {
            if (output.cell_type === 'code') {
                const execution_count = output.execution_count;
                if (execution_count) {
                    return execution_count;
                }
            }
        }
        return 0;
    }
    onAfterAttach(msg) {
        var _a, _b;
        const cell = this.parent;
        //console.log('get cell', cell);
        if (cell) {
            if (this.selectRecipe === undefined) {
                const executionCount = this.getExecutionCount(cell);
                this.selectRecipe = new _recipes__WEBPACK_IMPORTED_MODULE_4__.SelectRecipeWidget(cell, this.setCode.bind(this), this.setPackages.bind(this), this.runCell.bind(this), this.deleteCell.bind(this), this.addCell.bind(this), executionCount);
                this.selectRecipe.hide();
                if (this.layout instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout) {
                    (_a = this.layout) === null || _a === void 0 ? void 0 : _a.addWidget(this.selectRecipe);
                }
            }
            if (this._variableInspector === undefined && this.selectRecipe !== undefined) {
                this._variableInspector = new _variableinspector__WEBPACK_IMPORTED_MODULE_5__.VariableInspector(this.notebook, this.selectRecipe.setVariablesStatus.bind(this.selectRecipe), this.selectRecipe.setVariables.bind(this.selectRecipe), this.selectRecipe.setCheckedPackages.bind(this.selectRecipe));
                this.selectRecipe.setCheckPackage(this._variableInspector.checkPackage.bind(this._variableInspector));
                this.selectRecipe.setInstallPackage(this._variableInspector.installPackage.bind(this._variableInspector));
                this.selectRecipe.updateWidget();
            }
            //console.log('try add focus');
            // cell.inputArea?.node.addEventListener('focusout', () => {
            //   console.log('focusin is here2', cell);
            //   this.a?.hide();
            // });
            this._cellId = cell.model.id;
            if (this.selectRecipe) {
                RecipeWidgetsRegistry.getInstance().addWidget(this._cellId, this.selectRecipe);
            }
            // cell.model.contentChanged.connect(() => {
            //   console.log('content changed');
            // }, cell);
            // cell.model.metadataChanged.connect(() => {
            //   console.log('metadata changed');
            // }, cell);
            cell.model.stateChanged.connect((model, args) => {
                // console.log('state changed', args, model);
                // if (args.name === 'executionCount' && args.newValue) {
                //   console.log('go for it');
                //   const [errorName, errorValue] = this.getErrorNameAndValue(cell.model.sharedModel.toJSON());
                //   this.selectRecipe?.setPreviousError(errorName, errorValue);
                //   const executionCount = this.getExecutionCount(cell);
                //   this.selectRecipe?.setPreviousExecutionCount(executionCount);
                //   this.selectRecipe?.updateWidget();
                // }
            }, cell);
            // cell.node.addEventListener('focusin', () => {
            //   console.log('cell node focusin');
            // });
            // cell.node.addEventListener('focusout', () => {
            //   console.log('cell node focus-out');
            //   // this.selectRecipe?.setExecutionSteps([]);
            // });
            (_b = cell.inputArea) === null || _b === void 0 ? void 0 : _b.node.addEventListener('focusin', () => {
                var _a, _b, _c, _d, _e, _f, _g;
                if (this._cellId) {
                    RecipeWidgetsRegistry.getInstance().setSelectedCellId(this._cellId);
                }
                RecipeWidgetsRegistry.getInstance().hideAll();
                console.log('focus in clear packages');
                this._packages = [];
                if ((0,_flags__WEBPACK_IMPORTED_MODULE_6__.getAlwaysOpen)()) {
                    (_a = this.selectRecipe) === null || _a === void 0 ? void 0 : _a.setPreviousCode(cell.model.sharedModel.getSource());
                    const [errorName, errorValue] = this.getErrorNameAndValue(cell.model.sharedModel.toJSON());
                    (_b = this.selectRecipe) === null || _b === void 0 ? void 0 : _b.setPreviousError(errorName, errorValue);
                    const executionCount = this.getExecutionCount(cell);
                    (_c = this.selectRecipe) === null || _c === void 0 ? void 0 : _c.setPreviousExecutionCount(executionCount);
                    (_d = this.selectRecipe) === null || _d === void 0 ? void 0 : _d.updateWidget();
                    //this.selectRecipe?.update();
                    (_e = this._variableInspector) === null || _e === void 0 ? void 0 : _e.getVariables();
                    (_f = this.selectRecipe) === null || _f === void 0 ? void 0 : _f.show();
                }
                // console.log(cell.model.sharedModel.toJSON());
                // this.setCode("hejka");
                const nb = this.notebook;
                // let future = nb?.sessionContext.session?.kernel?.requestExecute({
                //   code: "2+2",
                //   store_history: false,
                // });
                // if (future) {
                //   future.onIOPub = this._onIOPub;
                // }
                //nb?.sessionContext.
                const cells = (_g = nb === null || nb === void 0 ? void 0 : nb.model) === null || _g === void 0 ? void 0 : _g.cells;
                // const sharedModel = nb?.model?.sharedModel;
                // sharedModel?.insertCell(0, {
                //   cell_type: "code",
                //   source: "hejka"
                // });
                if (cells) {
                    // cells.get(0).sharedModel.setSource("hejka");
                    for (let i = 0; i < (cells === null || cells === void 0 ? void 0 : cells.length); i++) {
                        // console.log(cells.get(i).sharedModel.source)
                        //console.log(cells.get(i).id);
                        //console.log(cells.get(i).sharedModel.getMetadata());
                        //let m = cells.get(i).sharedModel.getMetadata();
                        //m['showPoC'] = true;
                        //cells.get(i).sharedModel.setMetadata(m);
                    }
                }
            });
        }
    }
    //https://github.com/jupyterlab/extension-examples/tree/main/signals
    //private _stateChanged = new Signal<ButtonWidget, ICount>(this);
    get cell() {
        // console.log('parent', this.parent);
        return this.parent instanceof _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_0__.Cell ? this.parent : null;
    }
    get notebook() {
        var _a, _b;
        return ((_b = (_a = this.cell) === null || _a === void 0 ? void 0 : _a.parent) === null || _b === void 0 ? void 0 : _b.parent) instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.NotebookPanel
            ? this.cell.parent.parent
            : null;
    }
}


/***/ }),

/***/ "./lib/extendedcell/index.js":
/*!***********************************!*\
  !*** ./lib/extendedcell/index.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extendedCellFactory: () => (/* binding */ extendedCellFactory)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/codeeditor */ "webpack/sharing/consume/default/@jupyterlab/codeeditor");
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _factory__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./factory */ "./lib/extendedcell/factory.js");
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./header */ "./lib/extendedcell/header.js");




const extendedCellFactory = {
    id: '@mljar/piece-of-code-cell-factory',
    provides: _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookPanel.IContentFactory,
    requires: [_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__.IEditorServices],
    autoStart: true,
    activate: (app, editorServices) => {
        console.log('POC content factory is activated!');
        const { commands } = app;
        _header__WEBPACK_IMPORTED_MODULE_2__.RecipeWidgetsRegistry.getInstance().setCommandRegistry(commands);
        const editorFactory = editorServices.factoryService.newInlineEditor;
        return new _factory__WEBPACK_IMPORTED_MODULE_3__.ExtendedCellFactory({ editorFactory });
    }
};


/***/ }),

/***/ "./lib/extendedcell/recipes.js":
/*!*************************************!*\
  !*** ./lib/extendedcell/recipes.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExecutionStatus: () => (/* binding */ ExecutionStatus),
/* harmony export */   SelectRecipeWidget: () => (/* binding */ SelectRecipeWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mljar/recipes */ "webpack/sharing/consume/default/@mljar/recipes/@mljar/recipes");
/* harmony import */ var _mljar_recipes__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mljar_recipes__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_3__);




var ExecutionStatus;
(function (ExecutionStatus) {
    ExecutionStatus["Wait"] = "Wait";
    ExecutionStatus["Success"] = "Success";
    ExecutionStatus["Error"] = "Error";
    ExecutionStatus["Warning"] = "Warning";
})(ExecutionStatus || (ExecutionStatus = {}));
const SelectRecipeComponent = ({ previousCode, previousErrorName, previousErrorValue, previousExecutionCount, cell, setCode, setPackages, runCell, executionSteps, deleteCell, addCell, variablesStatus, variables, checkPackage, checkedPackages, installPackage, clearExecutionSteps }) => {
    // useEffect(() => {
    //   console.log('cell changed');
    // }, [cell]);
    // cell.model.contentChanged.connect(() => {
    //   setPreviousCode(cell.model.sharedModel.getSource());
    // }, cell);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mljar_recipes__WEBPACK_IMPORTED_MODULE_1__.SelectRecipe, { previousCode: previousCode, previousErroValue: previousErrorName, previousErrorName: previousErrorValue, previousExecutionCount: previousExecutionCount, setCode: setCode, setPackages: setPackages, runCell: runCell, executionSteps: executionSteps, deleteCell: deleteCell, addCell: addCell, variablesStatus: variablesStatus, variables: variables, checkPackage: checkPackage, checkedPackages: checkedPackages, installPackage: installPackage, clearExecutionSteps: clearExecutionSteps })));
};
class SelectRecipeWidget extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.ReactWidget {
    constructor(cell, setCode, setPackages, runCell, deleteCell, addCell, executionCount) {
        super();
        this._signal = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this._previousCode = '';
        this._previousErrorName = '';
        this._previousErrorValue = '';
        this._previousExecutionCount = 0;
        this._executionSteps = [];
        this._variablesStatus = 'unknown';
        this._variables = [];
        this.addClass('jp-react-widget');
        this._cell = cell;
        this._setCodeCallback = setCode;
        this._setPackagesCallback = setPackages;
        this._runCellCallback = runCell;
        this._deleteCell = deleteCell;
        this._addCell = addCell;
        this._previousExecutionCount = executionCount;
        this._checkPackage = (pkg) => { };
        this._checkedPackages = {};
        this._installPackage = (installationName, importName) => { };
    }
    setExecutionSteps(steps) {
        this._executionSteps = steps;
        this.updateWidget();
    }
    setPreviousCode(src) {
        this._previousCode = src;
    }
    setPreviousExecutionCount(cnt) {
        this._previousExecutionCount = cnt;
    }
    setPreviousError(name, value) {
        this._previousErrorName = name;
        this._previousErrorValue = value;
    }
    updateWidget() {
        this._signal.emit();
    }
    setVariablesStatus(status) {
        this._variablesStatus = status;
    }
    setVariables(variables) {
        this._variables = variables;
        this.updateWidget();
    }
    setCheckPackage(checkPackage) {
        this._checkPackage = checkPackage;
    }
    setCheckedPackages(pkgs) {
        console.log('set checked packages');
        console.log({ pkgs });
        this._checkedPackages = pkgs;
        this.updateWidget();
    }
    setInstallPackage(installPackage) {
        this._installPackage = installPackage;
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.UseSignal, { signal: this._signal }, () => {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SelectRecipeComponent, { previousCode: this._previousCode, previousErrorName: this._previousErrorName, previousErrorValue: this._previousErrorValue, previousExecutionCount: this._previousExecutionCount, cell: this._cell, setCode: this._setCodeCallback, setPackages: this._setPackagesCallback, runCell: this._runCellCallback, executionSteps: this._executionSteps, deleteCell: this._deleteCell, addCell: this._addCell, variablesStatus: this._variablesStatus, variables: this._variables, checkPackage: this._checkPackage, checkedPackages: this._checkedPackages, installPackage: this._installPackage, clearExecutionSteps: () => this.setExecutionSteps([]) }));
        }));
    }
}


/***/ }),

/***/ "./lib/extendedcell/variableinspector.js":
/*!***********************************************!*\
  !*** ./lib/extendedcell/variableinspector.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VariableInspector: () => (/* binding */ VariableInspector)
/* harmony export */ });
var notebooksInitialized = [];
const initCode = `import json
import sys
from importlib import __import__
from IPython import get_ipython
from IPython.core.magics.namespace import NamespaceMagics


_jupyterlab_variableinspector_nms = NamespaceMagics()
_jupyterlab_variableinspector_Jupyter = get_ipython()
_jupyterlab_variableinspector_nms.shell = _jupyterlab_variableinspector_Jupyter.kernel.shell

__np = None
__pd = None
__pyspark = None
__tf = None
__K = None
__torch = None
__ipywidgets = None
__xr = None


def _attempt_import(module):
    try:
        return __import__(module)
    except ImportError:
        return None


def _check_imported():
    global __np, __pd, __pyspark, __tf, __K, __torch, __ipywidgets, __xr

    __np = _attempt_import('numpy')
    __pd = _attempt_import('pandas')
    __pyspark = _attempt_import('pyspark')
    __tf = _attempt_import('tensorflow')
    __K = _attempt_import('keras.backend') or _attempt_import('tensorflow.keras.backend')
    __torch = _attempt_import('torch')
    __ipywidgets = _attempt_import('ipywidgets')
    __xr = _attempt_import('xarray')


def _jupyterlab_variableinspector_getsizeof(x):
    if type(x).__name__ in ['ndarray', 'Series']:
        return x.nbytes
    elif __pyspark and isinstance(x, __pyspark.sql.DataFrame):
        return "?"
    elif __tf and isinstance(x, __tf.Variable):
        return "?"
    elif __torch and isinstance(x, __torch.Tensor):
        return x.element_size() * x.nelement()
    elif __pd and type(x).__name__ == 'DataFrame':
        return x.memory_usage().sum()
    else:
        return sys.getsizeof(x)


def _jupyterlab_variableinspector_getshapeof(x):
    if __pd and isinstance(x, __pd.DataFrame):
        return "%d rows x %d cols" % x.shape
    if __pd and isinstance(x, __pd.Series):
        return "%d rows" % x.shape
    if __np and isinstance(x, __np.ndarray):
        shape = " x ".join([str(i) for i in x.shape])
        return "%s" % shape
    if __pyspark and isinstance(x, __pyspark.sql.DataFrame):
        return "? rows x %d cols" % len(x.columns)
    if __tf and isinstance(x, __tf.Variable):
        shape = " x ".join([str(int(i)) for i in x.shape])
        return "%s" % shape
    if __tf and isinstance(x, __tf.Tensor):
        shape = " x ".join([str(int(i)) for i in x.shape])
        return "%s" % shape
    if __torch and isinstance(x, __torch.Tensor):
        shape = " x ".join([str(int(i)) for i in x.shape])
        return "%s" % shape
    if __xr and isinstance(x, __xr.DataArray):
        shape = " x ".join([str(int(i)) for i in x.shape])
        return "%s" % shape
    if isinstance(x, list):
        return "%s" % len(x)
    if isinstance(x, dict):
        return "%s keys" % len(x)
    return None

def _jupyterlab_variableinspector_getcolumnsof(x):
    if __pd and isinstance(x, __pd.DataFrame):
        return list(x.columns)
    return []

def _jupyterlab_variableinspector_getcontentof(x):
    # returns content in a friendly way for python variables
    # pandas and numpy
    if __pd and isinstance(x, __pd.DataFrame):
        colnames = ', '.join(x.columns.map(str))
        content = "Columns: %s" % colnames
    elif __pd and isinstance(x, __pd.Series):
        content = str(x.values).replace(" ", ", ")[1:-1]
        content = content.replace("\\n", "")
    elif __np and isinstance(x, __np.ndarray):
        content = x.__repr__()
    elif __xr and isinstance(x, __xr.DataArray):
        content = x.values.__repr__()
    else:
        content = str(x)

    if len(content) > 150:
        return content[:150] + " ..."
    else:
        return content


def _jupyterlab_variableinspector_is_matrix(x):
    # True if type(x).__name__ in ["DataFrame", "ndarray", "Series"] else False
    if __pd and isinstance(x, __pd.DataFrame):
        return True
    if __pd and isinstance(x, __pd.Series):
        return True
    if __np and isinstance(x, __np.ndarray) and len(x.shape) <= 2:
        return True
    if __pyspark and isinstance(x, __pyspark.sql.DataFrame):
        return True
    if __tf and isinstance(x, __tf.Variable) and len(x.shape) <= 2:
        return True
    if __tf and isinstance(x, __tf.Tensor) and len(x.shape) <= 2:
        return True
    if __torch and isinstance(x, __torch.Tensor) and len(x.shape) <= 2:
        return True
    if __xr and isinstance(x, __xr.DataArray) and len(x.shape) <= 2:
        return True
    if isinstance(x, list):
        return True
    return False


def _jupyterlab_variableinspector_is_widget(x):
    return __ipywidgets and issubclass(x, __ipywidgets.DOMWidget)


def _jupyterlab_variableinspector_dict_list():
    _check_imported()
    def keep_cond(v):
        try:
            obj = eval(v)
            if isinstance(obj, str):
                return True
            if __tf and isinstance(obj, __tf.Variable):
                return True
            if __pd and __pd is not None and (
                isinstance(obj, __pd.core.frame.DataFrame)
                or isinstance(obj, __pd.core.series.Series)):
                return True
            if __xr and __xr is not None and isinstance(obj, __xr.DataArray):
                return True
            if str(obj)[0] == "<":
                return False
            if  v in ['__np', '__pd', '__pyspark', '__tf', '__K', '__torch', '__ipywidgets', '__xr']:
                return obj is not None
            if str(obj).startswith("_Feature"):
                # removes tf/keras objects
                return False
            return True
        except:
            return False
    values = _jupyterlab_variableinspector_nms.who_ls()
    vardic = [
        {
            'varName': _v,
            'varType': type(eval(_v)).__name__, 
            'varSize': str(_jupyterlab_variableinspector_getsizeof(eval(_v))), 
            'varShape': str(_jupyterlab_variableinspector_getshapeof(eval(_v))) if _jupyterlab_variableinspector_getshapeof(eval(_v)) else '', 
            'varContent': str(_jupyterlab_variableinspector_getcontentof(eval(_v))), 
            'isMatrix': _jupyterlab_variableinspector_is_matrix(eval(_v)),
            'isWidget': _jupyterlab_variableinspector_is_widget(type(eval(_v))),
            'varColumns': _jupyterlab_variableinspector_getcolumnsof(eval(_v)),
        }
        for _v in values if keep_cond(_v)
    ]
    return json.dumps(vardic, ensure_ascii=False)


def _jupyterlab_variableinspector_getmatrixcontent(x, max_rows=10000):
    # to do: add something to handle this in the future
    threshold = max_rows

    if __pd and __pyspark and isinstance(x, __pyspark.sql.DataFrame):
        df = x.limit(threshold).toPandas()
        return _jupyterlab_variableinspector_getmatrixcontent(df.copy())
    elif __np and __pd and type(x).__name__ == "DataFrame":
        if threshold is not None:
            x = x.head(threshold)
        x.columns = x.columns.map(str)
        return x.to_json(orient="table", default_handler=_jupyterlab_variableinspector_default, force_ascii=False)
    elif __np and __pd and type(x).__name__ == "Series":
        if threshold is not None:
            x = x.head(threshold)
        return x.to_json(orient="table", default_handler=_jupyterlab_variableinspector_default, force_ascii=False)
    elif __np and __pd and type(x).__name__ == "ndarray":
        df = __pd.DataFrame(x)
        return _jupyterlab_variableinspector_getmatrixcontent(df)
    elif __tf and (isinstance(x, __tf.Variable) or isinstance(x, __tf.Tensor)):
        df = __K.get_value(x)
        return _jupyterlab_variableinspector_getmatrixcontent(df)
    elif __torch and isinstance(x, __torch.Tensor):
        df = x.cpu().numpy()
        return _jupyterlab_variableinspector_getmatrixcontent(df)
    elif __xr and isinstance(x, __xr.DataArray):
        df = x.to_numpy()
        return _jupyterlab_variableinspector_getmatrixcontent(df)
    elif isinstance(x, list):
        s = __pd.Series(x)
        return _jupyterlab_variableinspector_getmatrixcontent(s)


def _jupyterlab_variableinspector_displaywidget(widget):
    display(widget)


def _jupyterlab_variableinspector_default(o):
    if isinstance(o, __np.number): return int(o)  
    raise TypeError


def _jupyterlab_variableinspector_deletevariable(x):
    exec("del %s" % x, globals())`;
const getVars = `_jupyterlab_variableinspector_dict_list()`;
var checkedPackages = {};
const checkPackageCode = (pkg) => `
from importlib import __import__
try:
    print('{' + f'"package": "${pkg}", "version": "{__import__("${pkg}").__version__}"' + '}')
except ImportError:
  print('{"package": "${pkg}", "version": "error"}')`;
const installPackageConda = (pkg) => `import sys
!conda install --yes --prefix {sys.prefix} ${pkg}`;
const installPackagePip = (pkg) => `import sys
!{sys.executable} -m pip install ${pkg}`;
const checkIfConda = `import sys
!conda list --prefix {sys.prefix}`;
var notebookPackageManager = {};
class VariableInspector {
    constructor(nb, setVariablesStatus, setVariables, setInstalledPackages) {
        var _a;
        this._onIOPub = (msg) => {
            console.log(msg);
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    const content = msg.content;
                    console.log(content);
                    try {
                        let contentDisplay = content.data["text/plain"];
                        contentDisplay = contentDisplay.slice(1, -1);
                        contentDisplay = contentDisplay
                            .replace(/\\"/g, '"')
                            .replace(/\\'/g, "'");
                        console.log('get variables', contentDisplay);
                        const variables = JSON.parse(contentDisplay);
                        console.log(variables);
                        this._setVariables(variables);
                        this._setVariablesStatus("loaded");
                        if (this._notebookId && !notebooksInitialized.includes(this._notebookId)) {
                            notebooksInitialized.push(this._notebookId);
                        }
                    }
                    catch (e) {
                        console.log(e);
                        this._setVariables([]);
                        this._setVariablesStatus("error");
                    }
                    break;
                default:
                    break;
            }
            return;
        };
        this._onCheckPackage = (msg) => {
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'stream':
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    const content = msg.content;
                    try {
                        console.log('check package', content.text);
                        const p = JSON.parse(content.text);
                        if (this._notebookId) {
                            if (!(this._notebookId in checkedPackages)) {
                                checkedPackages[this._notebookId] = { [p.package]: p.version };
                            }
                            else {
                                checkedPackages[this._notebookId][p.package] = p.version;
                            }
                            this._setInstalledPackages(checkedPackages[this._notebookId]);
                        }
                    }
                    catch (e) {
                        console.log(e);
                    }
                    break;
                default:
                    break;
            }
            return;
        };
        this._onCheckPackageManager = (msg) => {
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'stream':
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    const content = msg.content;
                    if (this._notebookId) {
                        //                     n(N)ot a conda environment
                        if (content.text.includes('ot a conda environment')) {
                            notebookPackageManager[this._notebookId] = 'pip';
                        }
                        else {
                            notebookPackageManager[this._notebookId] = 'conda';
                        }
                    }
                    break;
                default:
                    break;
            }
            return;
        };
        this._notebook = nb;
        this._notebookId = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.id;
        this._setVariablesStatus = setVariablesStatus;
        this._setVariables = setVariables;
        this._setInstalledPackages = setInstalledPackages;
    }
    getVariables() {
        var _a, _b, _c;
        console.log('get variables');
        try {
            this.checkPackageManager();
            this._setVariablesStatus("loading");
            this._setVariables([]);
            let code = '';
            console.log(this._notebookId);
            console.log(notebooksInitialized);
            if (this._notebookId && !notebooksInitialized.includes(this._notebookId)) {
                console.log('init getVariables');
                code += initCode + '\n\n';
            }
            code += getVars;
            let future = (_c = (_b = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.session) === null || _b === void 0 ? void 0 : _b.kernel) === null || _c === void 0 ? void 0 : _c.requestExecute({
                code,
                store_history: false,
            });
            if (future) {
                future.onIOPub = this._onIOPub;
            }
        }
        catch (e) {
            console.log(e);
        }
    }
    checkPackage(pkg) {
        var _a, _b, _c;
        this.checkPackageManager();
        if (this._notebookId) {
            if (this._notebookId in checkedPackages && pkg in checkedPackages[this._notebookId]) {
                // const version = checkedPackages[this._notebookId][pkg];
                this._setInstalledPackages(checkedPackages[this._notebookId]);
            }
            else {
                let future = (_c = (_b = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.session) === null || _b === void 0 ? void 0 : _b.kernel) === null || _c === void 0 ? void 0 : _c.requestExecute({
                    code: checkPackageCode(pkg),
                    store_history: false,
                });
                if (future) {
                    future.onIOPub = this._onCheckPackage;
                }
            }
        }
    }
    installPackage(installationName, importName) {
        let packageManager = 'conda';
        if (this._notebookId && this._notebookId in notebookPackageManager) {
            packageManager = notebookPackageManager[this._notebookId];
        }
        this._installPackagePackageManager(installationName, importName, packageManager);
    }
    _installPackagePackageManager(installationName, importName, packageManager) {
        var _a, _b, _c;
        console.log('Install', importName, 'with', packageManager);
        if (this._notebookId) {
            if (!(this._notebookId in checkedPackages)) {
                checkedPackages[this._notebookId] = { [importName]: 'install' };
            }
            else {
                checkedPackages[this._notebookId][importName] = 'install';
            }
            this._setInstalledPackages(checkedPackages[this._notebookId]);
        }
        let future = (_c = (_b = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.session) === null || _b === void 0 ? void 0 : _b.kernel) === null || _c === void 0 ? void 0 : _c.requestExecute({
            code: packageManager === 'conda' ? installPackageConda(installationName) : installPackagePip(installationName),
            store_history: false,
        });
        if (future) {
            // will be needed to collect logs from installation
            // future.onIOPub = this._onInstallPackage;
            future.done.then(() => {
                if (this._notebookId && this._notebookId in checkedPackages) {
                    // delete all packages, we need to re-check all packages again
                    // there might be dependencies
                    delete checkedPackages[this._notebookId]; //[importName];
                    this.checkPackage(importName);
                }
            });
        }
    }
    // private _onInstallPackage = (msg: KernelMessage.IIOPubMessage): void => {
    //   const msgType = msg.header.msg_type;
    //   switch (msgType) {
    //     case 'stream':
    //     case 'execute_result':
    //     case 'display_data':
    //     case 'update_display_data':
    //       interface ContentData {
    //         name: string;
    //         text: string;
    //       }
    //       const content = msg.content as ContentData;
    //       //console.log(content);
    //       break;
    //     default:
    //       break;
    //   }
    //   return;
    // };
    checkPackageManager() {
        var _a, _b, _c;
        // if already checked, then skip this step
        if (this._notebookId && this._notebookId in notebookPackageManager) {
            return;
        }
        console.log('Check package manager');
        let future = (_c = (_b = (_a = this._notebook) === null || _a === void 0 ? void 0 : _a.sessionContext.session) === null || _b === void 0 ? void 0 : _b.kernel) === null || _c === void 0 ? void 0 : _c.requestExecute({
            code: checkIfConda,
            store_history: false,
        });
        if (future) {
            future.onIOPub = this._onCheckPackageManager;
        }
    }
}


/***/ }),

/***/ "./lib/flags.js":
/*!**********************!*\
  !*** ./lib/flags.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getAlwaysOpen: () => (/* binding */ getAlwaysOpen),
/* harmony export */   setAlwaysOpen: () => (/* binding */ setAlwaysOpen)
/* harmony export */ });
/* harmony import */ var _extendedcell_header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./extendedcell/header */ "./lib/extendedcell/header.js");

const ALWAYS_OPEN_FLAG = 'alwaysOpenPieceOfCode';
const setFlag = (key, value) => {
    localStorage.setItem(key, value);
};
const getFlag = (key) => {
    return localStorage.getItem(key);
};
const setAlwaysOpen = (value) => {
    setFlag(ALWAYS_OPEN_FLAG, value.toString());
    if (value) {
        _extendedcell_header__WEBPACK_IMPORTED_MODULE_0__.RecipeWidgetsRegistry.getInstance().showLastSelectedCellId();
    }
    else {
        _extendedcell_header__WEBPACK_IMPORTED_MODULE_0__.RecipeWidgetsRegistry.getInstance().hideAll();
    }
};
const getAlwaysOpen = () => {
    const f = getFlag(ALWAYS_OPEN_FLAG);
    if (f === null) {
        return true;
    }
    return f === 'true';
};


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cakeIcon: () => (/* binding */ cakeIcon),
/* harmony export */   cakeOffIcon: () => (/* binding */ cakeOffIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_cake_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../style/icons/cake.svg */ "./style/icons/cake.svg");
/* harmony import */ var _style_icons_cakeoff_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../style/icons/cakeoff.svg */ "./style/icons/cakeoff.svg");



const cakeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'cake-icon',
    svgstr: _style_icons_cake_svg__WEBPACK_IMPORTED_MODULE_1__
});
const cakeOffIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'cake-off-icon',
    svgstr: _style_icons_cakeoff_svg__WEBPACK_IMPORTED_MODULE_2__
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _commands__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./commands */ "./lib/commands/index.js");
/* harmony import */ var _extendedcell__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./extendedcell */ "./lib/extendedcell/index.js");
/* harmony import */ var _flags__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./flags */ "./lib/flags.js");




/**
 * Initialization data for the pieceofcode extension.
 */
const plugin = {
    id: 'pieceofcode:plugin',
    description: 'Write code with UI.',
    autoStart: true,
    optional: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__.ISettingRegistry],
    activate: (app, settingRegistry) => {
        console.log('JupyterLab extension pieceofcode is activated!');
        if (settingRegistry) {
            settingRegistry
                .load(plugin.id)
                .then(settings => {
                const updateSettings = () => {
                    const alwaysOpen = settings.get('alwaysOpenPieceOfCode')
                        .composite;
                    if (alwaysOpen !== undefined) {
                        (0,_flags__WEBPACK_IMPORTED_MODULE_1__.setAlwaysOpen)(alwaysOpen);
                    }
                };
                updateSettings();
                settings.changed.connect(updateSettings);
                console.log('pieceofcode settings loaded:', settings.composite);
            })
                .catch(reason => {
                console.error('Failed to load settings for pieceofcode.', reason);
            });
        }
    }
};
const plugins = [plugin, _commands__WEBPACK_IMPORTED_MODULE_2__.commandsPlugin, _extendedcell__WEBPACK_IMPORTED_MODULE_3__.extendedCellFactory];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugins);


/***/ }),

/***/ "./style/icons/cake.svg":
/*!******************************!*\
  !*** ./style/icons/cake.svg ***!
  \******************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" class=\"icon icon-tabler icon-tabler-cake-off\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke=\"currentColor\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path stroke=\"none\" d=\"M0 0h24v24H0z\" fill=\"none\"/><path d=\"M3 20h18v-8a3 3 0 0 0 -3 -3h-12a3 3 0 0 0 -3 3v8z\" /><path d=\"M3 14.803c.312 .135 .654 .204 1 .197a2.4 2.4 0 0 0 2 -1a2.4 2.4 0 0 1 2 -1a2.4 2.4 0 0 1 2 1a2.4 2.4 0 0 0 2 1a2.4 2.4 0 0 0 2 -1a2.4 2.4 0 0 1 2 -1a2.4 2.4 0 0 1 2 1a2.4 2.4 0 0 0 2 1c.35 .007 .692 -.062 1 -.197\" /><path d=\"M12 4l1.465 1.638a2 2 0 1 1 -3.015 .099l1.55 -1.737z\" /></svg>";

/***/ }),

/***/ "./style/icons/cakeoff.svg":
/*!*********************************!*\
  !*** ./style/icons/cakeoff.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" class=\"icon icon-tabler icon-tabler-cake-off\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke=\"currentColor\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path stroke=\"none\" d=\"M0 0h24v24H0z\" fill=\"none\"/><path d=\"M21 17v-5a3 3 0 0 0 -3 -3h-5m-4 0h-3a3 3 0 0 0 -3 3v8h17\" /><path d=\"M3 14.803c.312 .135 .654 .204 1 .197a2.4 2.4 0 0 0 2 -1a2.4 2.4 0 0 1 2 -1a2.4 2.4 0 0 1 2 1a2.4 2.4 0 0 0 2 1a2.4 2.4 0 0 0 2 -1m4 0a2.4 2.4 0 0 0 2 1c.35 .007 .692 -.062 1 -.197\" /><path d=\"M10.172 6.188c.07 -.158 .163 -.31 .278 -.451l1.55 -1.737l1.465 1.638a2 2 0 0 1 -.65 3.19\" /><path d=\"M3 3l18 18\" /></svg>";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.0fad24f9a6ac3def80ec.js.map